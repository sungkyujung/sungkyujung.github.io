function output=mod_minscrot_mean(sample,initial_guess)
%Function for computing location estimator using the Procrustes type
%alignment estimation procedure.  The input dataset should be an nx1 cell
%containing SPD matrices.

%Pre-processing%
[nrow1,ncol1]=size(sample{1});

if nrow1~=ncol1
    disp('Input matrices must be square.');
    return;
end

if nrow1>3
    disp('Only p=2 or p=3 is allowed.');
    return;
end
n=length(sample);
p=nrow1;
Adj=eye(p);
Adj(p,p)=-1;

%Obtain initial eigen-decompositions of the sample SPD matrices.%
eigen_decomps=cell(n,2);
for i=1:n
    [eigen_decomps{i,1},eigen_decomps{i,2}]=eig(sample{i});
    if det(eigen_decomps{i,1})<0
        eigen_decomps{i,1}=eigen_decomps{i,1}*Adj;
    end
end

%Create a cell containing all possible eigen-decompositions of each sample
%SPD matrix.%
Perms=perm_mats(p);
Sign_changes=sign_change_mats(p);
num_versions=length(Perms)*length(Sign_changes);

sample_versions=cell(n,2,num_versions);
for i=1:n
    count=0;
    for j=1:length(Perms)
        for k=1:length(Sign_changes)
            count=count+1;
            sample_versions{i,1,count}=eigen_decomps{i,1}*Sign_changes{k}*Perms{j}';
            sample_versions{i,2,count}=Perms{j}*eigen_decomps{i,2}*Perms{j}';
        end
    end
end

%Set initial eigen-decompositions of sample SPD matrices to be closest to
%the initial guess.
[initial_sol{1,1},initial_sol{1,2}]=eig(initial_guess);
if det(initial_sol{1,1})<0
    initial_sol{1,1}=initial_sol{1,1}*Adj;
end

old_SPD=initial_sol{1,1}*initial_sol{1,2}*initial_sol{1,1}';

%Create initial set of aligned eigen-decompositions that are aligned with
%the initial solution eigen-decomposition.
aligned_eigen_decomps=cell(n,2);
initial_MSR_variance=0;
for i=1:n
    dists=zeros(num_versions,1);
    for j=1:num_versions
        dists(j)=scale_rot_dist(sample_versions{i,1,j},sample_versions{i,2,j},initial_sol{1,1},initial_sol{1,2},1);
    end
    [MSR_dist,ind]=min(dists);
    aligned_eigen_decomps{i,1}=sample_versions{i,1,ind};
    aligned_eigen_decomps{i,2}=sample_versions{i,2,ind};
    initial_MSR_variance=initial_MSR_variance+(1/n)*MSR_dist^2;
end

old_sol=cell(1,2);
old_sol{1,1}=initial_sol{1,1};
old_sol{1,2}=initial_sol{1,2};
old_SPD=old_sol{1,1}*old_sol{1,2}*old_sol{1,1}';

new_sol=cell(1,2);
new_sol{1,1}=old_sol{1,1};
new_sol{1,2}=old_sol{1,2};
new_SPD=old_SPD;

diff=1;
tol=10^-15;

while diff>tol
    old_sol{1,1}=new_sol{1,1};
    old_sol{1,2}=new_sol{1,2};
    old_SPD=new_SPD;
    
    %Create set of aligned eigen-decompositions that are aligned with
    %the old solution's eigen-decomposition.
    aligned_eigen_decomps=cell(n,2);
    for i=1:n
        dists=zeros(num_versions,1);
        for j=1:num_versions
            dists(j)=scale_rot_dist(sample_versions{i,1,j},sample_versions{i,2,j},old_sol{1,1},old_sol{1,2},1);
        end
        [~,ind]=min(dists);
        aligned_eigen_decomps{i,1}=sample_versions{i,1,ind};
        aligned_eigen_decomps{i,2}=sample_versions{i,2,ind};
    end
    %Compute the intrinsic sample means for the eigenvalues and rotation
    %matrix.
    
    new_sol=cell(1,2);
    %Mean rotation%
    new_sol{1,1}=rot_sample_mean(aligned_eigen_decomps(:,1));
    %Mean eigenvalues%
    log_eval_mean=zeros(p,p);
    for i=1:n
        log_eval_mean=log_eval_mean+(1/n)*logm(aligned_eigen_decomps{i,2});
    end
    new_sol{1,2}=expm(log_eval_mean);
    new_SPD=new_sol{1,1}*new_sol{1,2}*new_sol{1,1}';
    
    diff=2*sqrt(initial_MSR_variance)*min_scale_rot_dist(new_SPD,old_SPD,1)+(min_scale_rot_dist(new_SPD,old_SPD,1))^2;
end
output=new_SPD;
end