function output=quatmult(p,q)
%Computes the quaternion product of input quaternions p and q.
output=[p(1)*q(1)-dot(p(2:4),q(2:4)) p(1)*q(2:4)+q(1)*p(2:4)+cross(p(2:4),q(2:4))];
end
