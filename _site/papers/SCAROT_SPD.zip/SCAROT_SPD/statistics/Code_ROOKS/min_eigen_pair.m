function [Ux,Dx,Uy,Dy,MSR_dist]=min_eigen_pair(X,Y)
%Find minimal pair of eigen-decompositions for SPD matrices X and Y, that
%is the pair of eigen-decompositions that are closest in terms of
%scaling-rotation distance.  This version of the function only works when X
%and Y both have all distinct eigenvalues.
p=length(X);
Adj=eye(p);
Adj(p,p)=-1;

%Ensure that rotation matrix for X has determinant equal to 1.
[Ux,Dx]=eig(X);
if det(Ux)<0
    Ux=Ux*Adj;
end

[U,D]=eig(Y);
if det(U)<0
    U=U*Adj;
end

%Generate all possible eigen-decompositions of Y.
all_perms=perm_mats(p);
all_sign_changes=sign_change_mats(p);
count=0;

eig_decompsY=cell(length(all_perms)*length(all_sign_changes),2);
for i=1:length(all_perms)
    for j=1:length(all_sign_changes)
        count=count+1;
        eig_decompsY{count,1}=U*all_sign_changes{j,1}*all_perms{i,1}';
        eig_decompsY{count,2}=all_perms{i,1}*D*all_perms{i,1}';
    end
end

%All scaling rotation distances.
num_versions=factorial(p)*(2^(p-1));
XY_dists=zeros(num_versions,1);
for i=1:num_versions
    XY_dists(i)=scale_rot_dist(Ux,Dx,eig_decompsY{i,1},eig_decompsY{i,2},1);
end

[MSR_dist,ind]=min(XY_dists);

Uy=eig_decompsY{ind,1};
Dy=eig_decompsY{ind,2};
end
    
        