function output=procrustesSS_mean(sample,initial_guess)
%Computes sample Frechet mean of a sample of SPD matrices using the
%Procrustes Size-and-Shape distance function.  Assuming that the sample is
%a cell containing all observations.
n=length(sample);
old_guess=initial_guess;
new_guess=old_guess;
p=length(old_guess);
diff=1;
tol=10^-10;

while diff>tol
    mod_sample=cell(n,1);
    old_guess=new_guess;
    old_root=old_guess^0.5;
    old_procrustes_sample_var=0;
    new_guess_root=zeros(p,p);
    for i=1:n
        [W,~,U]=svd(old_root*(sample{i}^0.5)');
        mod_sample{i}=(sample{i}^0.5)*U*W';
        new_guess_root=new_guess_root+(1/n)*mod_sample{i};
        old_procrustes_sample_var=old_procrustes_sample_var+(1/n)*trace((old_root-mod_sample{i})*(old_root-mod_sample{i})');
    end
    new_guess=new_guess_root*new_guess_root';
    
    new_mod_sample=cell(n,1);
    new_procrustes_sample_var=0;
    for i=1:n
        [W,~,U]=svd(new_guess_root*(sample{i}^0.5)');
        new_mod_sample{i}=(sample{i}^0.5)*U*W';
        new_procrustes_sample_var=new_procrustes_sample_var+(1/n)*trace((new_guess_root-new_mod_sample{i})*(new_guess_root-new_mod_sample{i})');
    end
    diff=abs(new_procrustes_sample_var-old_procrustes_sample_var);
end
output=new_guess;
end