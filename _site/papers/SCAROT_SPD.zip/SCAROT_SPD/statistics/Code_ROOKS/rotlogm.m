function output=rotlogm(input)
%Compute the matrix logarithm for rotation matrices.
p=length(input);

J=[0 -1; 1 0];

if p==2
    if trace(input)==-2
        output=pi*J;
    else
        output=atan2(input(2,1),input(1,1))*J;
    end
elseif p==3
    %Determine axis of rotation.
    [U,D]=eig(eye(p)-input);
    check=any(diag(D),2);
    ind=ones(p,1)-double(check);
    axis=real(U*ind);
    
    %Determine angle.
    if trace(input)==-1
        output=pi*[0 -axis(3) axis(2); axis(3) 0 -axis(1);
            -axis(2) axis(1) 0];
    else
        angle=acos(0.5*(trace(input)-1));
        output=angle*[0 -axis(3) axis(2); axis(3) 0 -axis(1);
            -axis(2) axis(1) 0];
    end
    
else
    output=logm(input);
end
end