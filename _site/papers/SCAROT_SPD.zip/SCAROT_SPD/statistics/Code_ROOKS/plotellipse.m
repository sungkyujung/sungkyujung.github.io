function plotellipse(X,c)
%Function for plotting the ellipse corresponding to a 2x2 symmetric
%positive-definite matrix.
[U,D]=eig(X);
theta=linspace(0,2*pi,10000);
circle_coords=[cos(theta)' sin(theta)'];
ellipse_coords=(U*(D^0.5)*circle_coords')';
if nargin==1
    plot(ellipse_coords(:,1),ellipse_coords(:,2));
else
    plot(ellipse_coords(:,1),ellipse_coords(:,2),'Color',c);
end
axis equal
end