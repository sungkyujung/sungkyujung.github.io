function output=AImean(sample,initial_guess)
%Computes sample Frechet mean of a sample of SPD matrices using the
%Riemannian Affine-Invariant distance function.  Assuming that sample is a
%cell containing all observations.
n=length(sample);
tau=1; %step size%
old_guess=initial_guess;
new_guess=old_guess;
p=length(old_guess);
norm=1;
tol=10^-10;

while norm>tol
    norm_old=norm;
    A=zeros(p,p);
    old_guess=new_guess;
    for i=1:n
        A=A+(1/n)*(old_guess^0.5)*logm((old_guess^-0.5)*sample{i}*(old_guess^-0.5)')*(old_guess^0.5)';
    end
    new_guess=(old_guess^0.5)*expm(tau*(old_guess^-0.5)*A*(old_guess^-0.5)')*(old_guess^0.5)';
    norm=sqrt(trace(A*A'));
    if norm>norm_old
            tau=tau/2;
    end
end
output=new_guess;
end