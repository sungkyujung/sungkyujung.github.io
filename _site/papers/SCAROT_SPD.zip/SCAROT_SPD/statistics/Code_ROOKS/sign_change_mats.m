function output=sign_change_mats(p)
%Generate all sign change matrices of dimesion pxp with positive
%determinant.
nums=linspace(1,p,p);
even_nums=nums(mod(nums,2)==0);
num_sign_changes=2^(p-1);
count=1;
output=repmat({eye(p)},num_sign_changes,1);

for i=1:length(even_nums)
    subsets=nchoosek(nums,even_nums(i));
    [nrows,ncols]=size(subsets);
    for j=1:nrows
        count=count+1;
        for k=1:ncols
            output{count,1}(subsets(j,k),subsets(j,k))=-1;
        end
    end
end