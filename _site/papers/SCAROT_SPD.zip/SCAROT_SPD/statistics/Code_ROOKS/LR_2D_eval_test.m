cd 'C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials';

%Assuming that rotation and scaling components are independent.
%Log-eigenvalues follow an isotropic bivariate normal distribution. Angle
%follows a geodesic normal distribution (truncated normal distribution).
p=2;
n=[30 50 100];
evals_conc_parms=[1/0.5 1/1 1/2];
angle_conc_parms=[1/(0.1^2) 1/(0.25^2) 1/(0.5^2)];

evals_mean=5*eye(p);
rot_mean=rot2Dmat(pi/6);

num_sim=500;

LR_test_stats=zeros(length(n),length(evals_conc_parms),num_sim);

K=1;
A=[1 0; 0 -1];

perms=perm_mats(p);
sign_changes=sign_change_mats(p);
size=2^(p-1)*factorial(p);

signed_perms=cell(size,1);
ind=0;

for i=1:length(perms)
    for j=1:length(sign_changes)
        ind=ind+1;
        signed_perms{ind}=perms{i}*sign_changes{j};
    end
end

%num_sim=10;

rng(123)
count=0;
for a=1%:length(n)
    for b=3%1:length(evals_conc_parms)
        pd=makedist('Normal','mu',0,'sigma',sqrt(1/angle_conc_parms(b)));
        t=truncate(pd,-pi,pi);
        for c=1:num_sim
            count=count+1
            log_evals=mvnrnd([0 0],(1/evals_conc_parms(b))*eye(p),n(a));
            angles=random(t,n(a),1);
            SPD_mats=cell(n(a),1);
            for i=1:n(a)
                SPD_mats{i}=(rot2Dmat(angles(i))*rot_mean)*(expm(diag(log_evals(i,:)))*evals_mean)*(rot2Dmat(angles(i))*rot_mean)';
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Maximize log-likelihood under alternative hypothesis
            %observed_eigen_decomps=cell(n(a),2);
            %for i=1:n(a)
            %   [observed_eigen_decomps{i,2},observed_eigen_decomps{i,1}]=eig(SPD_mats{i});
             %   if det(observed_eigen_decomps{i,2})<0
              %      observed_eigen_decomps{i,2}=observed_eigen_decomps{i,2}*A;
               % end
            %end

            %ind=0;
            %shifted_rot_mats=cell(n(a)*size,1);
            %for i=1:n(a)
            %    for j=1:size
            %        ind=ind+1;
            %        shifted_rot_mats{ind}=observed_eigen_decomps{i,2}*signed_perms{j};
            %    end
            %end
            
            %Set initial values for model parameters.
            old_probs=ones(size,1)/size;
            new_probs=old_probs;

            old_evals_conc_parm=evals_conc_parms(b);
            new_evals_conc_parm=old_evals_conc_parm;

            old_angle_conc_parm=angle_conc_parms(b);
            new_angle_conc_parm=old_angle_conc_parm;
            
            [~,old_evals_mean]=eig(log_euclidean_mean(SPD_mats));

            new_evals_mean=old_evals_mean;

            %if det(old_rot_mean)<0
                %old_rot_mean=old_rot_mean*A;
            %end
            old_rot_mean=rot_mean;
            new_rot_mean=old_rot_mean;

            diff=1;
            tol=10^-10;
            
            %Obtain observed eigen-decompositions.
            observed_eigen_decomps=cell(n(a),2);
            unif=rand(n(a),1);
            version_num=ceil(size*unif);
            for i=1:n(a)
                [observed_eigen_decomps{i,1},observed_eigen_decomps{i,2}]=rho_min_eigen_decomp(SPD_mats{i},old_evals_mean,old_rot_mean,K);
                observed_eigen_decomps{i,1}=signed_perms{version_num(i)}*observed_eigen_decomps{i,1}*signed_perms{version_num(i)}';
                observed_eigen_decomps{i,2}=observed_eigen_decomps{i,2}*signed_perms{version_num(i)}';
            end
            
            %for i=1:n(a)
            %    [observed_eigen_decomps{i,2},observed_eigen_decomps{i,1}]=eig(SPD_mats{i});
            %    if det(observed_eigen_decomps{i,2})<0
            %        observed_eigen_decomps{i,2}=observed_eigen_decomps{i,2}*A;
            %    end
            %end
            
            ind=0;
            shifted_rot_mats=cell(n(a)*size,1);
            for i=1:n(a)
                for j=1:size
                    ind=ind+1;
                    shifted_rot_mats{ind}=observed_eigen_decomps{i,2}*signed_perms{j};
                end
            end
            
            %Initialize densities for first expectation step.
            densities=zeros(n(a),size);
            for i=1:n(a)
                for j=1:size
                    densities(i,j)=((old_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(old_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*old_evals_mean*signed_perms{j}'))^2)) ...
                        *((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
                end
            end
            
            %Compute log-likelihood using old parameter estimates.
            old_log_lik=ones(n(a),1)'*log(densities*old_probs);
            new_log_lik=old_log_lik;
            
            num_loops=0;
            while diff>tol && num_loops<100
                num_loops=num_loops+1;
                old_probs=new_probs;
                %old_evals_conc_parm=new_evals_conc_parm;
                %old_angle_conc_parm=new_angle_conc_parm;
                %old_evals_mean=new_evals_mean;
                %old_rot_mean=new_rot_mean;
                old_log_lik=new_log_lik;
    
                %Expectation Step
                %densities=zeros(n(a),size);
                %for i=1:n(a)
                    %for j=1:size
                        %densities(i,j)=((old_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(old_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*old_evals_mean*signed_perms{j}'))^2)) ...
                            %*((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
                    %end
                %end
    
                %Compute log-likelihood using old parameter estimates.
                %old_log_lik=ones(n(a),1)'*log(densities*old_probs);
    
                version_indicators=diag(densities*old_probs)\densities*diag(old_probs);
    
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %Maximization Step
                %Mixture probability estimates
                %new_probs=((1/n(a))*ones(n(a),1)'*version_indicators)';
    
                %Weighted Eigenvalue Matrix Mean
                new_evals_mean=zeros(p,p);
                for i=1:n(a)
                    for j=1:size
                        new_evals_mean=new_evals_mean+(version_indicators(i,j)/n(a))*logm(signed_perms{j}'*observed_eigen_decomps{i,1}*signed_perms{j});
                    end
                end
                new_evals_mean=expm(new_evals_mean);
    
                %MLE for evals concentration parameter.
                weighted_evals_var=0;
                for i=1:n(a)
                    for j=1:size
                        weighted_evals_var=weighted_evals_var+(version_indicators(i,j)/n(a))*(diagplus_dist(signed_perms{j}'*observed_eigen_decomps{i,1}*signed_perms{j},new_evals_mean))^2;
                    end
                end
    
                new_evals_conc_parm=p/weighted_evals_var;
    
                %Weighted Eigenvector Matrix Mean
                weights=zeros(n(a)*size,1);
                ind=0;
                for i=1:n(a)
                    for j=1:size
                        ind=ind+1;
                        weights(ind)=version_indicators(i,j)/n(a);
                    end
                end
                
                extrinsic_weighted_mean=zeros(p,p);
                for i=1:length(weights)
                    extrinsic_weighted_mean=extrinsic_weighted_mean+weights(i)*shifted_rot_mats{i};
                end
                
                [U,~,V]=svd(extrinsic_weighted_mean);
                initial_weighted_rot_mean=U*V';
    
                new_rot_mean=weighted_rot_sample_mean(shifted_rot_mats,weights,initial_weighted_rot_mean);
    
                %MLE for angle concentration parameter.
                weighted_angle_var=0;
                for i=1:n(a)
                    for j=1:size
                        weighted_angle_var=weighted_angle_var+(version_indicators(i,j)/n(a))*(rot_dist(observed_eigen_decomps{i,2}*signed_perms{j},new_rot_mean))^2;
                    end
                end
    
                new_angle_conc_parm=invmodV_fun(K*weighted_angle_var,K);
    
                %Compute density functions using updated parameter estimates.
                densities=zeros(n(a),size);
                for i=1:n(a)
                    for j=1:size
                        densities(i,j)=((new_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(new_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*new_evals_mean*signed_perms{j}'))^2)) ...
                            *((sqrt(K*new_angle_conc_parm)/erf(pi*sqrt(K*new_angle_conc_parm/2)))*exp(-(new_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},new_rot_mean*signed_perms{j}'))^2));
                    end
                end
    
                %Compute log-likelihood using updated parameter estimates.
                new_log_lik=ones(n(a),1)'*log(densities*new_probs);
    
                diff=abs(new_log_lik-old_log_lik);
            end
            alt_log_lik=new_log_lik;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Compute maximized log-likelihood under null hypothesis that
            %eigenvalue mean is a scaled identity matrix.
            %Set initial values for model parameters.
            old_probs=ones(size,1)/size;
            new_probs=old_probs;

            old_angle_conc_parm=angle_conc_parms(b);
            new_angle_conc_parm=old_angle_conc_parm;
            
            old_evals_mean=zeros(p,p);
            for i=1:n(a)
                old_evals_mean=old_evals_mean+(1/(n(a)*p))*trace(logm(observed_eigen_decomps{i,1}))*eye(p);
            end
            old_evals_mean=expm(old_evals_mean);
            new_evals_mean=old_evals_mean;
            
            evals_var=0;
            for i=1:n(a)
                evals_var=evals_var+(1/n(a))*(diagplus_dist(observed_eigen_decomps{i,1},old_evals_mean))^2;
            end
            old_evals_conc_parm=p/evals_var;
            new_evals_conc_parm=old_evals_conc_parm;
            
            %[old_rot_mean,~]=eig(log_euclidean_mean(SPD_mats));

            %if det(old_rot_mean)<0
                %old_rot_mean=old_rot_mean*A;
            %end
            
            old_rot_mean=rot_mean;
            new_rot_mean=old_rot_mean;

            diff=1;
            tol=10^-10;
            
            %Initialize densitites for first expectation step.
            densities=zeros(n(a),size);
            for i=1:n(a)
                for j=1:size
                    densities(i,j)=((old_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(old_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*old_evals_mean*signed_perms{j}'))^2)) ...
                        *((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
                end
            end
            
            old_log_lik=ones(n(a),1)'*log(densities*old_probs);
            new_log_lik=old_log_lik;
            
            num_loops=0;
            while diff>tol && num_loops<100
                num_loops=num_loops+1;
                old_probs=new_probs;
                %old_evals_conc_parm=new_evals_conc_parm;
                %old_angle_conc_parm=new_angle_conc_parm;
                %old_evals_mean=new_evals_mean;
                %old_rot_mean=new_rot_mean;
                old_log_lik=new_log_lik;
    
                %Expectation Step
                %densities=zeros(n(a),size);
                %for i=1:n(a)
                    %for j=1:size
                        %densities(i,j)=((old_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(old_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*old_evals_mean*signed_perms{j}'))^2)) ...
                            %*((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
                    %end
                %end
    
                %Compute log-likelihood using old parameter estimates.
                %old_log_lik=ones(n(a),1)'*log(densities*old_probs);
    
                version_indicators=diag(densities*old_probs)\densities*diag(old_probs);
    
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %Maximization Step
                %Mixture probability estimates
                %new_probs=((1/n(a))*ones(n(a),1)'*version_indicators)';
    
                %Weighted Eigenvector Matrix Mean
                weights=zeros(n(a)*size,1);
                ind=0;
                for i=1:n(a)
                    for j=1:size
                        ind=ind+1;
                        weights(ind)=version_indicators(i,j)/n(a);
                    end
                end
    
                extrinsic_weighted_mean=zeros(p,p);
                for i=1:length(weights)
                    extrinsic_weighted_mean=extrinsic_weighted_mean+weights(i)*shifted_rot_mats{i};
                end
                
                [U,~,V]=svd(extrinsic_weighted_mean);
                initial_weighted_rot_mean=U*V';
    
                new_rot_mean=weighted_rot_sample_mean(shifted_rot_mats,weights,initial_weighted_rot_mean);
    
                %MLE for angle concentration parameter.
                weighted_angle_var=0;
                for i=1:n(a)
                    for j=1:size
                        weighted_angle_var=weighted_angle_var+(version_indicators(i,j)/n(a))*(rot_dist(observed_eigen_decomps{i,2}*signed_perms{j},new_rot_mean))^2;
                    end
                end
    
                new_angle_conc_parm=invmodV_fun(K*weighted_angle_var,K);
    
                %Compute density functions using updated parameter estimates.
                densities=zeros(n(a),size);
                for i=1:n(a)
                    for j=1:size
                        densities(i,j)=((new_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(new_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*new_evals_mean*signed_perms{j}'))^2)) ...
                            *((sqrt(K*new_angle_conc_parm)/erf(pi*sqrt(K*new_angle_conc_parm/2)))*exp(-(new_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},new_rot_mean*signed_perms{j}'))^2));
                    end
                end
    
                %Compute log-likelihood using updated parameter estimates.
                new_log_lik=ones(n(a),1)'*log(densities*new_probs);
    
                diff=abs(new_log_lik-old_log_lik);
            end
            null_log_lik=new_log_lik;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Compute likelihood ratio test statistic.
            LR_test_stats(a,b,c)=2*(alt_log_lik-null_log_lik);
            2*(alt_log_lik-null_log_lik)

        end
    end
end

%Create plots of histograms and QQ plots for all simulations.
probs=linspace(0,1,num_sim)';
chi_sq_quantiles=chi2inv(probs,p-1);

figure
count=0;
for i=1:length(evals_conc_parms)
    for j=1:length(n)
        count=count+1;
        subplot(length(evals_conc_parms),length(n),count)
        qqplot(squeeze(LR_test_stats(j,i,1:num_sim)),chi_sq_quantiles);
        title(['n = ' num2str(n(j)) ', Cov Type = ' num2str(i)])
    end
end

figure
count=0;
for i=1:length(evals_conc_parms)
    for j=1:length(n)
        count=count+1;
        subplot(length(evals_conc_parms),length(n),count)
        histogram(squeeze(LR_test_stats(j,i,1:num_sim)));
        title(['n = ' num2str(n(j)) ', Cov Type = ' num2str(i)])
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Assuming that rotation and scaling components are independent. Log
%eigenvalues follow a bivariate normal distribution with general covariance
%matrix. Rotation angle follows a geodesic normal distribution (truncated
%normal distribution).

p=2;
n=[30 50 100];
evals_conc_parms=[1/0.5 1/1 1/2];
corr_mat=(1-0.25)*eye(p)+0.25*ones(p,p);
evals_cov_mats=cell(length(evals_conc_parms),1);
for i=1:length(evals_cov_mats)
    evals_cov_mats{i}=(sqrt(1/evals_conc_parms(i))*eye(p))*corr_mat*(sqrt(1/evals_conc_parms(i))*eye(p));
end

angle_conc_parms=[1/(0.1^2) 1/(0.25^2) 1/(0.5^2)];

evals_mean=5*eye(p);
rot_mean=rot2Dmat(pi/6);

%num_sim=500;
num_sim=36;
LR_test_stats=zeros(length(n),length(evals_conc_parms),num_sim);

K=1;
A=[1 0; 0 -1];

perms=perm_mats(p);
sign_changes=sign_change_mats(p);
size=2^(p-1)*factorial(p);

signed_perms=cell(size,1);
ind=0;

for i=1:length(perms)
    for j=1:length(sign_changes)
        ind=ind+1;
        signed_perms{ind}=perms{i}*sign_changes{j};
    end
end

rng(123)
count=0;
for a=1%:length(n)
    for b=1%:length(evals_conc_parms)
        pd=makedist('Normal','mu',0,'sigma',sqrt(1/angle_conc_parms(b)));
        t=truncate(pd,-pi,pi);
        for c=1:num_sim
            count=count+1
            log_evals=mvnrnd([0 0],evals_cov_mats{b},n(a));
            angles=random(t,n(a),1);
            SPD_mats=cell(n(a),1);
            for i=1:n(a)
                SPD_mats{i}=(rot2Dmat(angles(i))*rot_mean)*(expm(diag(log_evals(i,:)))*evals_mean)*(rot2Dmat(angles(i))*rot_mean)';
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Maximize log-likelihood under alternative hypothesis
            
            %Set initial values for model parameters.
            old_probs=ones(size,1)/size;
            new_probs=old_probs;

            old_evals_cov_mat=evals_cov_mats{b};
            new_evals_cov_mat=old_evals_cov_mat;

            old_angle_conc_parm=angle_conc_parms(b);
            new_angle_conc_parm=old_angle_conc_parm;
            
            [~,old_evals_mean]=eig(log_euclidean_mean(SPD_mats));

            new_evals_mean=old_evals_mean;

            %if det(old_rot_mean)<0
                %old_rot_mean=old_rot_mean*A;
            %end
            old_rot_mean=rot_mean;
            new_rot_mean=old_rot_mean;

            diff=1;
            tol=10^-10;
            
            %Obtain observed eigen-decompositions.
            observed_eigen_decomps=cell(n(a),2);
            unif=rand(n(a),1);
            version_num=ceil(size*unif);
            for i=1:n(a)
                [observed_eigen_decomps{i,1},observed_eigen_decomps{i,2}]=rho_min_eigen_decomp(SPD_mats{i},old_evals_mean,old_rot_mean,K);
                observed_eigen_decomps{i,1}=signed_perms{version_num(i)}*observed_eigen_decomps{i,1}*signed_perms{version_num(i)}';
                observed_eigen_decomps{i,2}=observed_eigen_decomps{i,2}*signed_perms{version_num(i)}';
            end
            
            ind=0;
            shifted_rot_mats=cell(n(a)*size,1);
            for i=1:n(a)
                for j=1:size
                    ind=ind+1;
                    shifted_rot_mats{ind}=observed_eigen_decomps{i,2}*signed_perms{j};
                end
            end
            
            %Initialize densities for first expectation step.
            densities=zeros(n(a),size);
            for i=1:n(a)
                for j=1:size
                    densities(i,j)=(det(2*pi*old_evals_cov_mat))^(-1/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-0.5*trace((signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(old_evals_mean))*inv(old_evals_cov_mat)*(signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(old_evals_mean)))) ...
                        *((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
                end
            end
            
            %Compute log-likelihood using old parameter estimates.
            old_log_lik=ones(n(a),1)'*log(densities*old_probs);
            new_log_lik=old_log_lik;
            
            num_loops=0;
            while diff>tol && num_loops<100
                num_loops=num_loops+1;
                old_probs=new_probs;
                %old_evals_conc_parm=new_evals_conc_parm;
                %old_angle_conc_parm=new_angle_conc_parm;
                %old_evals_mean=new_evals_mean;
                %old_rot_mean=new_rot_mean;
                old_log_lik=new_log_lik;
    
                version_indicators=diag(densities*old_probs)\densities*diag(old_probs);
    
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %Maximization Step
                %Mixture probability estimates
                new_probs=((1/n(a))*ones(n(a),1)'*version_indicators)';
    
                %Weighted Eigenvalue Matrix Mean
                new_evals_mean=zeros(p,p);
                for i=1:n(a)
                    for j=1:size
                        new_evals_mean=new_evals_mean+(version_indicators(i,j)/n(a))*logm(signed_perms{j}'*observed_eigen_decomps{i,1}*signed_perms{j});
                    end
                end
                new_evals_mean=expm(new_evals_mean);
    
                new_evals_cov_mat=zeros(p,p);
                for i=1:n(a)
                    for j=1:size
                        new_evals_cov_mat=new_evals_cov_mat+(version_indicators(i,j)/n(a))*diag(signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(new_evals_mean))*diag(signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(new_evals_mean))';
                    end
                end
    
                %Weighted Eigenvector Matrix Mean
                weights=zeros(n(a)*size,1);
                ind=0;
                for i=1:n(a)
                    for j=1:size
                        ind=ind+1;
                        weights(ind)=version_indicators(i,j)/n(a);
                    end
                end
    
                new_rot_mean=weighted_rot_sample_mean(shifted_rot_mats,weights,old_rot_mean);
    
                %MLE for angle concentration parameter.
                weighted_angle_var=0;
                for i=1:n(a)
                    for j=1:size
                        weighted_angle_var=weighted_angle_var+(version_indicators(i,j)/n(a))*(rot_dist(observed_eigen_decomps{i,2}*signed_perms{j},new_rot_mean))^2;
                    end
                end
    
                new_angle_conc_parm=invmodV_fun(K*weighted_angle_var,K);
    
                %Compute density functions using updated parameter estimates.
                densities=zeros(n(a),size);
                for i=1:n(a)
                    for j=1:size
                        densities(i,j)=(det(2*pi*new_evals_cov_mat))^(-1/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-0.5*trace((signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(new_evals_mean))*inv(new_evals_cov_mat)*(signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(new_evals_mean)))) ...
                            *((sqrt(K*new_angle_conc_parm)/erf(pi*sqrt(K*new_angle_conc_parm/2)))*exp(-(new_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},new_rot_mean*signed_perms{j}'))^2));
                    end
                end
    
                %Compute log-likelihood using updated parameter estimates.
                new_log_lik=ones(n(a),1)'*log(densities*new_probs);
    
                diff=abs(new_log_lik-old_log_lik);
            end
            alt_log_lik=new_log_lik;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Compute maximized log-likelihood under null hypothesis that
            %eigenvalue mean is a scaled identity matrix.
            %Set initial values for model parameters.
            old_probs=ones(size,1)/size;
            new_probs=old_probs;

            old_angle_conc_parm=angle_conc_parms(b);
            new_angle_conc_parm=old_angle_conc_parm;
            
            old_evals_mean=zeros(p,p);
            for i=1:n(a)
                old_evals_mean=old_evals_mean+(1/(n(a)*p))*trace(logm(observed_eigen_decomps{i,1}))*eye(p);
            end
            old_evals_mean=expm(old_evals_mean);
            new_evals_mean=old_evals_mean;
            
            old_evals_cov_mat=zeros(p,p);
            for i=1:n(a)
                old_evals_cov_mat=old_evals_cov_mat+(1/n(a))*diag(logm(observed_eigen_decomps{i,1})-logm(old_evals_mean))*diag(logm(observed_eigen_decomps{i,1})-logm(old_evals_mean))';
            end
            
            new_evals_cov_mat=old_evals_cov_mat;
            
            old_rot_mean=rot_mean;
            new_rot_mean=old_rot_mean;

            diff=1;
            tol=10^-10;
            
            %Initialize densitites for first expectation step.
            densities=zeros(n(a),size);
            for i=1:n(a)
                for j=1:size
                    densities(i,j)=(det(2*pi*old_evals_cov_mat))^(-1/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-0.5*trace((signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(old_evals_mean))*inv(old_evals_cov_mat)*(signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(old_evals_mean)))) ...
                        *((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
                end
            end
            
            old_log_lik=ones(n(a),1)'*log(densities*old_probs);
            new_log_lik=old_log_lik;
            
            num_loops=0;
            while diff>tol && num_loops<100
                num_loops=num_loops+1;
                old_probs=new_probs;
                %old_evals_conc_parm=new_evals_conc_parm;
                %old_angle_conc_parm=new_angle_conc_parm;
                %old_evals_mean=new_evals_mean;
                %old_rot_mean=new_rot_mean;
                old_log_lik=new_log_lik;
    
                %Expectation Step
    
                version_indicators=diag(densities*old_probs)\densities*diag(old_probs);
    
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %Maximization Step
                %Mixture probability estimates
                new_probs=((1/n(a))*ones(n(a),1)'*version_indicators)';
    
                %Weighted Eigenvector Matrix Mean
                weights=zeros(n(a)*size,1);
                ind=0;
                for i=1:n(a)
                    for j=1:size
                        ind=ind+1;
                        weights(ind)=version_indicators(i,j)/n(a);
                    end
                end
    
                new_rot_mean=weighted_rot_sample_mean(shifted_rot_mats,weights,old_rot_mean);
    
                %MLE for angle concentration parameter.
                weighted_angle_var=0;
                for i=1:n(a)
                    for j=1:size
                        weighted_angle_var=weighted_angle_var+(version_indicators(i,j)/n(a))*(rot_dist(observed_eigen_decomps{i,2}*signed_perms{j},new_rot_mean))^2;
                    end
                end
    
                new_angle_conc_parm=invmodV_fun(K*weighted_angle_var,K);
    
                %Compute density functions using updated parameter estimates.
                densities=zeros(n(a),size);
                for i=1:n(a)
                    for j=1:size
                        densities(i,j)=(det(2*pi*new_evals_cov_mat))^(-1/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-0.5*trace((signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(new_evals_mean))*inv(new_evals_cov_mat)*(signed_perms{j}'*logm(observed_eigen_decomps{i,1})*signed_perms{j}-logm(new_evals_mean)))) ...
                            *((sqrt(K*new_angle_conc_parm)/erf(pi*sqrt(K*new_angle_conc_parm/2)))*exp(-(new_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},new_rot_mean*signed_perms{j}'))^2));
                    end
                end
    
                %Compute log-likelihood using updated parameter estimates.
                new_log_lik=ones(n(a),1)'*log(densities*new_probs);
    
                diff=abs(new_log_lik-old_log_lik);
            end
            null_log_lik=new_log_lik;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Compute likelihood ratio test statistic.
            LR_test_stats(a,b,c)=2*(alt_log_lik-null_log_lik);
            2*(alt_log_lik-null_log_lik)

        end
    end
end

%Create plots of histograms and QQ plots for all simulations.
probs=linspace(0,1,num_sim)';
chi_sq_quantiles=chi2inv(probs,p-1);

figure
count=0;
for i=1:length(evals_conc_parms)
    for j=1:length(n)
        count=count+1;
        subplot(length(evals_conc_parms),length(n),count)
        qqplot(squeeze(LR_test_stats(j,i,1:num_sim)),chi_sq_quantiles);
        title(['n = ' num2str(n(j)) ', Cov Type = ' num2str(i)])
    end
end

figure
count=0;
for i=1:length(evals_conc_parms)
    for j=1:length(n)
        count=count+1;
        subplot(length(evals_conc_parms),length(n),count)
        histogram(squeeze(LR_test_stats(j,i,1:num_sim)));
        title(['n = ' num2str(n(j)) ', Cov Type = ' num2str(i)])
    end
end
