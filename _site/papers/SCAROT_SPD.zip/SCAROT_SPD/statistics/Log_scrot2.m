function x = Log_scrot2(U,D,Ux,Dx,k)
% The log map from M(p) to the tangent coordinate at (U,D) of (Ux,Dx) in
% M(p).
% p = 2. 

A = rotlogm(Ux*U');
L = logm(Dx/D);

x = [sqrt(k) * A(2,1), L(1,1), L(2,2)];
end

