function output=perm_mats(p)
%Generates all permutation matrices of dimension pxp.%
num_perms=factorial(p);
output=repmat({zeros(p)},num_perms,1);
all_perms=perms([linspace(1,p,p)]);
for i=1:num_perms
    for j=1:p
        output{i,1}(j,all_perms(i,j))=1;
    end
end

A=eye(p);
A(p,p)=-1;
%Modify all permutation matrices to have positive determinant%
for i=1:num_perms
    if det(output{i,1})<0
        output{i,1}=output{i,1}*A;
    end
end
end