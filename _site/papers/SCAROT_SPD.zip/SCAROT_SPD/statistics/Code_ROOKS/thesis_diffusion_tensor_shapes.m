D1=[2 0 0; 0 2 0; 0 0 2];
D2=[10 0 0; 0 2 0; 0 0 2];
D3=[10 0 0; 0 10 0; 0 0 0.5];
D4=[10 0 0; 0 2 0; 0 0 0.5];

subplot(2,2,1)
plotellipsoid(D1,eye(3),[45,45])
axis off
title('Isotropic')

subplot(2,2,2)
plotellipsoid(D2,eye(3),[57,22])
axis off
title('Prolate')

subplot(2,2,3)
plotellipsoid(D3,eye(3),[15,33])
axis off
title('Oblate')

subplot(2,2,4)
plotellipsoid(D4,eye(3),[64,17])
axis off
title('Triaxial')