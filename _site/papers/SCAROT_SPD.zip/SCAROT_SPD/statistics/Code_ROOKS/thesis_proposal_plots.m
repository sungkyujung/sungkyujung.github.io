%Create a plot of a smooth curve in Diag-plus(2) running from the identity
%element to the matrix [exp(1) 0; 0 exp(4)]

t=linspace(0,1,1000);
path1=zeros(length(t),2);
path2=zeros(length(t),2);
path3=zeros(length(t),2);

for i=1:length(t)
    path1(i,1)=2^(t(i));
    path1(i,2)=4^(t(i));
    path2(i,1)=1+(t(i))^2;
    path2(i,2)=1+3*(t(i))^4;
    path3(i,1)=1+t(i);
    path3(i,2)=1+3*t(i);
end

plot(path1(:,1),path1(:,2),'b');
hold on
plot(path2(:,1),path2(:,2),'r');
hold on
plot(path3(:,1),path3(:,2),'k');
xlabel('$D_{11}(t)$','Interpreter','latex')
ylabel('$D_{22}(t)$','Interpreter','latex')
legend({'$c_1(t)$','$c_2(t)$','$c_3(t)$'},'Interpreter','latex','Location','northwest')
fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\diagplus2curves.pdf')

%Compute lengths of the three curves as t ranges from 0 to 1 using the
%Frobenius norm on the tangent space.
fun1=@(t) sqrt((log(2)*2.^t).^2+(log(4)*4.^t).^2);
fun2=@(t) sqrt(4*t.^2+144*t.^6);
arclength1=integral(fun1,0,1);
arclength2=integral(fun2,0,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create plot of cone of 2x2 SPD matrices.
% Create cone
[t,z] = meshgrid((0:0.05:2)*pi, (0:0.1:1));
a = z.*(1 + cos(t));
b = z.*(1 - cos(t));
c = z*sqrt(2).*sin(t);

%figure
clf
BW = 0;
%set(gcf, 'Position', [0 0 600 600]) % [0 350 800 800]
%if BW,
    %surf(a,b,c,'FaceColor',0.9*[1 1 1],'EdgeColor',0.4*[1 1 1])
%else
    %surf(a,b,c,'FaceColor','red','EdgeColor',[0.2 0.2 0.2])
%end
surf(a,b,c)
camlight; %lighting phong
axis equal, axis([0 2.35 0 2.35 -1.2 1.2])
alpha(0.7), view([135 65])

% Add axes, labels
%line([0 2.35],[0 0],[0 0],'Color','black','LineWidth',2)
%line([0 0],[0 2.35],[0 0],'Color','black','LineWidth',2)
%line([0 0],[0 0],[-1.2 1.2],'Color','black','LineWidth',2)
%h = text(f*f*Lxy,0,0,'a'); set(h, 'Fontsize', 18)
%h = text(0,f*f*Lxy,0,'b'); set(h, 'Fontsize', 18)
%h = text(0,0,f*f*Lz/2,'c'); set(h, 'Fontsize', 18)
axis off
zoom on

createconefigure(a,b,c)
line([0 2.35],[0 0],[0 0],'Color','black','LineWidth',2)
line([0 0],[0 2.35],[0 0],'Color','black','LineWidth',2)
line([0 0],[0 0],[-1.2 1.2],'Color','black','LineWidth',2)

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\cone.pdf')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create circle in the plane identifying the distance between points on a
%circle.
theta11=linspace(0,pi/4,10000);
short_arc_coords=[cos(theta11)' sin(theta11)'];
theta12=linspace(pi/4,2*pi,10000);
long_arc_coords=[cos(theta12)' sin(theta12)'];
text1='$R_1$';
text2='$R_2$';
plot(short_arc_coords(:,1),short_arc_coords(:,2),'b')
text(1+0.02,0,text1,'Interpreter','latex');
axis equal
hold on
plot(long_arc_coords(:,1),long_arc_coords(:,2),'r')
text(cos(pi/4)+sqrt(0.02^2/2),sin(pi/4)+sqrt(0.02^2/2),text2,'Interpreter','latex');
axis equal
hold on
points=[1 0; cos(pi/4) sin(pi/4)];
scatter(points(:,1),points(:,2),'filled','k','LineWidth',0.75)
axis off

%Create circle in the plane with antipodal points.
theta21=linspace(0,pi,10000);
upper_circle_coords=[cos(theta21)' sin(theta21)'];
theta22=linspace(pi,2*pi,10000);
lower_circle_coords=[cos(theta22)' sin(theta22)'];
plot(upper_circle_coords(:,1),upper_circle_coords(:,2),'b')
text(1+0.02,0,text1,'Interpreter','latex');
axis equal
hold on
plot(lower_circle_coords(:,1),lower_circle_coords(:,2),'r')
text(-1-0.02,0,text2,'Interpreter','latex');
axis equal
hold on
antipodal_pts=[1 0;-1 0];
scatter(antipodal_pts(:,1),antipodal_pts(:,2),'filled','k','LineWidth',0.75)
axis off

%Plot both circles using subplot.%
subplot(1,2,1)
plot(short_arc_coords(:,1),short_arc_coords(:,2),'b')
text(1+0.02,0,text1,'Interpreter','latex');
axis equal
hold on
plot(long_arc_coords(:,1),long_arc_coords(:,2),'r')
text(cos(pi/4)+sqrt(0.02^2/2),sin(pi/4)+sqrt(0.02^2/2),text2,'Interpreter','latex');
axis equal
hold on
points=[1 0; cos(pi/4) sin(pi/4)];
scatter(points(:,1),points(:,2),'filled','k','LineWidth',0.75)
axis off

subplot(1,2,2)
plot(upper_circle_coords(:,1),upper_circle_coords(:,2),'b')
text(1+0.02,0,text1,'Interpreter','latex');
axis equal
hold on
plot(lower_circle_coords(:,1),lower_circle_coords(:,2),'r')
text(-1.20,0,text2,'Interpreter','latex');
axis equal
hold on
antipodal_pts=[1 0;-1 0];
scatter(antipodal_pts(:,1),antipodal_pts(:,2),'filled','k','LineWidth',0.75)
axis off

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\circle.pdf')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create scaling-rotation curves for 2x2 SPD matrices.
X=diag([10 2]);
Y=cell(3,1);
Y{1}=rot2Dmat(pi/4)*diag([10 2])*rot2Dmat(pi/4)';%Pure rotation%
Y{2}=diag([10 0.2]);%Pure scaling%
Y{3}=rot2Dmat(pi/4)*diag([10 0.2])*rot2Dmat(pi/4)';%Scaling plus rotation%

plot_title=cell(3,1);
plot_title{1}='Pure Rotation';
plot_title{2}='Pure Scaling';
plot_title{3}='Rotation Plus Scaling';

t=linspace(0,1,7);
Ux=cell(3,1);
Dx=cell(3,1);
Uy=cell(3,1);
Dy=cell(3,1);
for i=1:3
    %[Ux{i},Dx{i},Uy{i},Dy{i}]=min_eigen_pair(X,Y{i});
    [~,Ux{i},Dx{i},Uy{i},Dy{i}]=minscrotdist(X,Y{i});
end

Inter=cell(3,length(t));
for i=1:3
    for j=1:length(t)
        Inter{i,j}=(expm(logm(Uy{i}*Ux{i}')*t(j))*Ux{i})*(expm(logm(Dy{i}/Dx{i})*t(j))*Dx{i})*(expm(logm(Uy{i}*Ux{i}')*t(j))*Ux{i})';
    end
end

count=0;
for i=1:3
    for j=1:length(t)
        count=count+1;
        [U,D]=eig(Inter{i,j});
        subplot(3,length(t),count)
        plotellipse(D,U)
        axis([-3.5 3.5 -3.5 3.5])
        axis off
        if mod(count,length(t))==1
            title(plot_title{i})
        end
    end
end

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\2x2ScalingRotationCurves.pdf')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create plots showing 4 different eigen-decompositions of a 2x2 SPD matrix.
D=diag([10 2]);
U=rot2Dmat(pi/4);

subplot(2,2,2)
plotellipse(D,U)
arrow([0 0],[sqrt(10)/sqrt(2) sqrt(10)/sqrt(2)],'Color','r')
arrow([0 0], [-sqrt(2)/sqrt(2) sqrt(2)/sqrt(2)])
title('$(D_1,U_1)$','Interpreter','latex')
axis off
subplot(2,2,1)
plotellipse(D,U)
arrow([0 0], [-sqrt(2)/sqrt(2) sqrt(2)/sqrt(2)],'Color','r')
arrow([0 0],[-sqrt(10)/sqrt(2) -sqrt(10)/sqrt(2)])
title('$(D_2,U_2)$','Interpreter','latex')
axis off
subplot(2,2,3)
plotellipse(D,U)
arrow([0 0],[-sqrt(10)/sqrt(2) -sqrt(10)/sqrt(2)],'Color','r')
arrow([0 0], [sqrt(2)/sqrt(2) -sqrt(2)/sqrt(2)])
title('$(D_3,U_3)$','Interpreter','latex')
axis off
subplot(2,2,4)
plotellipse(D,U)
arrow([0 0], [sqrt(2)/sqrt(2) -sqrt(2)/sqrt(2)],'Color','r')
arrow([0 0],[sqrt(10)/sqrt(2) sqrt(10)/sqrt(2)])
title('$(D_4,U_4)$','Interpreter','latex')
axis off

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\2x2EigenDecompositions.pdf')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create plots of all possible scaling rotation curves connecting two 2x2
%SPD matrices.
X=diag([10 2]);
Y=rot2Dmat(pi/4)*X*rot2Dmat(pi/4)';

%Create the 4 different versions of X%
Perms=perm_mats(2);
Sign_changes=sign_change_mats(2);

X_versions=cell(4,2);
count=0;
for i=1:2
    for j=1:2
        count=count+1;
        X_versions{count,1}=Perms{i}*X*Perms{i}';
        X_versions{count,2}=eye(2)*Sign_changes{j}*Perms{i}';
    end
end

Y_eig_decomp=cell(1,2);
[Y_eig_decomp{1,2},Y_eig_decomp{1,1}]=eig(Y);
A=[-1 0; 0 1];
if det(Y_eig_decomp{1,2})<0
    Y_eig_decomp{1,2}=Y_eig_decomp{1,2}*A;
end

t=linspace(0,1,11);
SPD_inter=cell(4,length(t));
for i=1:4
    for j=1:length(t)
        SPD_inter{i,j}=(expm(t(j)*logm(Y_eig_decomp{1,2}*X_versions{i,2}'))*X_versions{i,2})*(expm(t(j)*logm(Y_eig_decomp{1,1}/X_versions{i,1}))*X_versions{i,1})*(expm(t(j)*logm(Y_eig_decomp{1,2}*X_versions{i,2}'))*X_versions{i,2})';
    end
end

%Compute the lengths of the 4 scaling-rotation curves%
sr_length1=scale_rot_dist(X_versions{1,2},X_versions{1,1},Y_eig_decomp{1,2},Y_eig_decomp{1,1},1);
sr_length2=scale_rot_dist(X_versions{2,2},X_versions{2,1},Y_eig_decomp{1,2},Y_eig_decomp{1,1},1);
sr_length3=scale_rot_dist(X_versions{3,2},X_versions{3,1},Y_eig_decomp{1,2},Y_eig_decomp{1,1},1);
sr_length4=scale_rot_dist(X_versions{4,2},X_versions{4,1},Y_eig_decomp{1,2},Y_eig_decomp{1,1},1);

SR_curve_titles=cell(4,1);
SR_curve_titles{1,1}='SR Distance: 2.3562';
SR_curve_titles{2,1}='SR Distance: 0.7854';
SR_curve_titles{3,1}='SR Distance: 3.2760';
SR_curve_titles{4,1}='SR Distance: 2.4078';

count=0;
for i=1:4
    for j=1:length(t)
        count=count+1;
        subplot(4,length(t),count)
        [U,D]=eig(SPD_inter{i,j});
        if det(U)<0
            U=U*A;
        end
        plotellipse(D,U);
        axis([-1.1*sqrt(10),1.1*sqrt(10),-1.1*sqrt(10),1.1*sqrt(10)])
        axis off
        zoom(1.1)
        if mod(count,length(t))==1
            title(SR_curve_titles{i,1})
        end
    end
end

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\All 2x2EigenDecompositions.pdf')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plots of isotropic and anisotropic 3D ellipsoids.
D_I=diag([5 5 5]);
D_A=diag([25 5 1]);

subplot(1,2,1)
plotellipsoid(D_I,eye(3),[0 1 0]);
title('Isotropic Diffusion Tensor')
axis([-5 5 -5 5 -5 5])
axis off

subplot(1,2,2)
plotellipsoid(D_A,rot3Dmat(pi/3,[0;1;0]),[0 1 0]);
title('Anisotropic Diffusion Tensor')
axis([-5 5 -5 5 -5 5])
axis off

fig=gcf;
print(fig,'-dpng','-r600','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\DTI_Isotropic_Anisotropic.png')