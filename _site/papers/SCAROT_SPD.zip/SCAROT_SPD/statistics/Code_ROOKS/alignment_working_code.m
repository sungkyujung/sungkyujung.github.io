%Alignment algorithm for finding intrinsic sample mean using the minimal
%scaling-rotation distance function.

%Begin with random sample of 2x2 SPD matrices.%
n=100;
pop_mean=[0 1 5];
cov=diag([0.10 0.20 0.20]);

sample=mvnrnd(pop_mean,cov,n);
cross_prod_sample=zeros(n,3);
cross_prod_sample(:,1)=sample(:,1);

for i=1:n
    cross_prod_sample(i,2)=exp(sample(i,2));
    cross_prod_sample(i,3)=exp(sample(i,3));
end

SPD_mats=cell(n,1);
for i=1:n
    SPD_mats{i,1}=rot2Dmat(cross_prod_sample(i,1))*diag([cross_prod_sample(i,2) cross_prod_sample(i,3)])*rot2Dmat(cross_prod_sample(i,1))';
end

sample=SPD_mats;

Adj=[1 0; 0 -1];

p=length(SPD_mats{1});

%Obtain initial eigen-decompositions for each sample SPD matrix.%
eigen_decomps=cell(n,2);
for i=1:n
    [eigen_decomps{i,1},eigen_decomps{i,2}]=eig(SPD_mats{i});
    if det(eigen_decomps{i,1})<0
        eigen_decomps{i,1}=eigen_decomps{i,1}*Adj;
    end
end

%Create a cell containing all possible eigen-decompositions of each sample
%SPD matrix.%
Perms=perm_mats(2);
Sign_changes=sign_change_mats(2);
num_versions=length(Perms)*length(Sign_changes);

sample_versions=cell(n,2,num_versions);
for i=1:n
    count=0;
    for j=1:length(Perms)
        for k=1:length(Sign_changes)
            count=count+1;
            sample_versions{i,1,count}=eigen_decomps{i,1}*Sign_changes{k}*Perms{j}';
            sample_versions{i,2,count}=Perms{j}*eigen_decomps{i,2}*Perms{j}';
        end
    end
end

%Set initial eigen-decompositions of sample SPD matrices to be closest to
%the initial eigen-decomposition of X1.
initial_sol=cell(1,2);
initial_sol{1,1}=eigen_decomps{1,1};
initial_sol{1,2}=eigen_decomps{1,2};

initial_eigen_decomps=cell(n,2);
for i=1:n
    dists=zeros(num_versions,1);
    for j=1:num_versions
        dists(j)=(scale_rot_dist(sample_versions{i,1,j},sample_versions{i,2,j},initial_sol{1,1},initial_sol{1,2},1))^2;
    end
    [~,ind]=min(dists);
    initial_eigen_decomps{i,1}=sample_versions{i,1,ind};
    initial_eigen_decomps{i,2}=sample_versions{i,2,ind};
end

%Compute the intrinsic sample means for the eigenvalues and rotation
%matrix.
initial_rotations=initial_eigen_decomps(:,1);
initial_evals=initial_eigen_decomps(:,2);
%Mean rotation%
rot_mean=rot_sample_mean(initial_rotations);
%Mean eigenvalues%
log_eval_mean=zeros(p,p);
for i=1:n
    log_eval_mean=log_eval_mean+(1/n)*logm(initial_evals{i});
end
eval_mean=expm(log_eval_mean);

new_sol=cell(1,2);
new_sol{1,1}=rot_mean;
new_sol{1,2}=eval_mean;


        
