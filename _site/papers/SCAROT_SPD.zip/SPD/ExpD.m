function expdx = ExpD(D,Y)
% Exp_D (X)
% D \in Sym+
% Y \in Sym

B = chol(D, 'lower');

expdx = actionGL(B,expm(actionGL(B^(-1),Y)));

