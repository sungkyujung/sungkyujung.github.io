cd 'C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials';

mean=rot2Dmat(pi/4)*diag([10 2])*rot2Dmat(pi/4)';
sample_size=50;
sample=LE_normrnd(mean,0.5^2*eye(3),sample_size);

%EM Algorithm Working Code for Likelihood Ratio Test of Equal Eigenvalue
%Means.
p=2;
perms=perm_mats(p);
sign_changes=sign_change_mats(p);
size=2^(p-1)*factorial(p);

signed_perms=cell(size,1);
ind=0;
for i=1:length(perms)
    for j=1:length(sign_changes)
        ind=ind+1;
        signed_perms{ind}=perms{i}*sign_changes{j};
    end
end

n=length(sample);

%Obtain "observed" eigen-decompositions
A=eye(p);
A(p,p)=-1;

observed_eigen_decomps=cell(n,2);
for i=1:n
    [observed_eigen_decomps{i,2},observed_eigen_decomps{i,1}]=eig(sample{i});
    if det(observed_eigen_decomps{i,2})<0
        observed_eigen_decomps{i,2}=observed_eigen_decomps{i,2}*A;
    end
end

ind=0;
shifted_rot_mats=cell(n*size,1);
for i=1:n
    for j=1:size
        ind=ind+1;
        shifted_rot_mats{ind}=observed_eigen_decomps{i,2}*signed_perms{j};
    end
end

%Rotation distance multiplier from SR distance
K=1;

%Set initial values for model parameters.
old_probs=ones(size,1)/size;
new_probs=old_probs;

old_evals_conc_parm=0.5;
new_evals_conc_parm=old_evals_conc_parm;

old_angle_conc_parm=4;
new_angle_conc_parm=old_angle_conc_parm;

old_evals_mean=diag([10 2]);
new_evals_mean=old_evals_mean;

old_rot_mean=rot2Dmat(pi/4);
new_rot_mean=old_rot_mean;

diff=1;
tol=10^-10;

while diff>tol
    old_probs=new_probs;
    old_evals_conc_parm=new_evals_conc_parm;
    old_angle_conc_parm=new_angle_conc_parm;
    old_evals_mean=new_evals_mean;
    old_rot_mean=new_rot_mean;
    
    %Expectation Step
    densities=zeros(n,size);
    for i=1:n
        for j=1:size
            densities(i,j)=((old_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(old_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*old_evals_mean*signed_perms{j}'))^2)) ...
                *((sqrt(K*old_angle_conc_parm)/erf(pi*sqrt(K*old_angle_conc_parm/2)))*exp(-(old_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},old_rot_mean*signed_perms{j}'))^2));
        end
    end
    
    %Compute log-likelihood using old parameter estimates.
    old_log_lik=ones(n,1)'*log(densities*old_probs);
    
    version_indicators=diag(densities*old_probs)\densities*diag(old_probs);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Maximization Step
    %Mixture probability estimates
    new_probs=((1/n)*ones(n,1)'*version_indicators)';
    
    %Weighted Eigenvalue Matrix Mean
    new_evals_mean=zeros(p,p);
    for i=1:n
        for j=1:size
            new_evals_mean=new_evals_mean+(version_indicators(i,j)/n)*logm(signed_perms{j}'*observed_eigen_decomps{i,1}*signed_perms{j});
        end
    end
    new_evals_mean=expm(new_evals_mean);
    
    %MLE for evals concentration parameter.
    weighted_evals_var=0;
    for i=1:n
        for j=1:size
            weighted_evals_var=weighted_evals_var+(version_indicators(i,j)/n)*(diagplus_dist(signed_perms{j}'*observed_eigen_decomps{i,1}*signed_perms{j},new_evals_mean))^2;
        end
    end
    
    new_evals_conc_parm=p/weighted_evals_var;
    
    %Weighted Eigenvector Matrix Mean
    weights=zeros(n*size,1);
    ind=0;
    for i=1:n
        for j=1:size
            ind=ind+1;
            weights(ind)=version_indicators(i,j)/n;
        end
    end
    
    new_rot_mean=weighted_rot_sample_mean(shifted_rot_mats,weights,old_rot_mean);
    
    %MLE for angle concentration parameter.
    weighted_angle_var=0;
    for i=1:n
        for j=1:size
            weighted_angle_var=weighted_angle_var+(version_indicators(i,j)/n)*(rot_dist(observed_eigen_decomps{i,2}*signed_perms{j},new_rot_mean))^2;
        end
    end
    
    new_angle_conc_parm=invmodV_fun(K*weighted_angle_var,K);
    
    %Compute density functions using updated parameter estimates.
    %Expectation Step
    new_densities=zeros(n,size);
    for i=1:n
        for j=1:size
            new_densities(i,j)=((new_evals_conc_parm/(2*pi))^(p/2)*det(inv(observed_eigen_decomps{i,1}))*exp(-(new_evals_conc_parm/2)*(diagplus_dist(observed_eigen_decomps{i,1},signed_perms{j}*new_evals_mean*signed_perms{j}'))^2)) ...
                *((sqrt(K*new_angle_conc_parm)/erf(pi*sqrt(K*new_angle_conc_parm/2)))*exp(-(new_angle_conc_parm/2)*(rot_dist(observed_eigen_decomps{i,2},new_rot_mean*signed_perms{j}'))^2));
        end
    end
    
    %Compute log-likelihood using updated parameter estimates.
    new_log_lik=ones(n,1)'*log(new_densities*new_probs);
    
    diff=abs(new_log_lik-old_log_lik);
end


