## 현재 작업디렉토리 확인 ##
getwd()

## R code가 있는 디렉토리로 작업디렉토리 변경 ##
## Rstudio의 메뉴의 "Session" -> "Set Working Directory" -> "Choose Directory"

## 필요한 패키지 인스톨 및 기타 필요한 함수 정의 
source("loadme.R")

#####################################
## 1. 이미지 파일 읽기             ##
#####################################

## 모든 얼굴 그림의 파일이름을 불러온다.
ALLfilenames <- list.files(path = "./faces/", recursive = TRUE) 

## 파일 이름에서 사람의 이름과 "First name"을 추출한다. 
FigureNames <- c(); FirstNames <- c()
for(i in 1:length(ALLfilenames)){ 
  FigureNames[i] <- strsplit(ALLfilenames[i],"/")[[1]][1]
  FirstNames[i] <- strsplit(ALLfilenames[i],"_")[[1]][1]
}


## Chan Ho Park을 찾아 얼굴 이미지를 읽어보자. 
(ChanHoPark_filename <- ALLfilenames[startsWith(ALLfilenames,"Chan_Ho")])
path <- paste("./faces/", ChanHoPark_filename, sep = "") # 파일 위치 지정 후 
img <- readJPEG(source = path)   # 이미지를 읽어 "img" 객체에 저장 

## img 객체 (얼굴)의 사이즈를 확인한다. 
dim(img)

## img 객체를 그리고, 얼굴만을 확대하여 자른 imagecrop(img)을 그려 비교해본다. 
par(mfrow = c(1,2))
plotArrayAsImage(img, main = "")
plotArrayAsImage(imagecrop(img), main = "")


## 아래 N을 1부터 1000 중 하나의 숫자로 골라서, N번째 이미지를 읽고 그려본다. 
N <- 333
{
  path <- paste("./faces/", ALLfilenames[N], sep = "") # 파일 위치 지정 후 
  img <- readJPEG(source = path)   # 이미지를 읽어 "img" 객체에 저장 
  par(mfrow = c(1,2))
  plotArrayAsImage(img, main = FigureNames[N])
  plotArrayAsImage(imagecrop(img), main = "")
}
  


######################################
## 2. 이미지 파일로 자료행렬 만들기 ##
######################################

## 각 그림이 한 줄의 자료가 되도록 바꾸어주고, 여러개의 그림을 읽어 데이터 행렬 (n x p)이 되도록 해준다. 
## 자료가 너무 많으므로, 이름 중 "Co"로 시작되는 이름만을 고른다. 
filenamesC <- ALLfilenames[ startsWith(ALLfilenames,"Co") ]
FigureNamesC <- FigureNames[ startsWith(ALLfilenames,"Co") ] 

n <- length(filenamesC) # 모두 
X = c()
for(i in 1:n){
  path <- paste("./faces/", filenamesC[i], sep = "")
  img <-  matrix( imagecrop( readJPEG(source = path) ), nrow = 1 )    
  X = rbind(X,img)
}   ## 그림자료를 읽어 데이터 행렬로 만든다. 1-2분 걸린다. 

## 데이터 행렬의 메모리에서의 크기를 잠깐 확인하자.
object.size(X)

## 자료행렬 X의 행의 갯수(number of rows)와 열의 갯수(number of columns)를 확인하자 
nrow(X)
(p <- ncol(X))
 
## 자료행렬의 N번째 값은 N번째 얼굴그림이다. 
N <- 1
par(mfrow = c(1,1)); drawface(X[N,], main = FigureNamesC[N])



######################################
## 3. 자료행렬을 이용해 주성분 찾기 ##
######################################

# 1. 자료의 평균을 구한다 
Xbar <- colMeans(X) 
drawface(Xbar, main = "Co-로 시작되는 이름을 가진 얼굴사진의 평균")

# 2. 평균을 뺀 자료행렬 
Xcentered <- X - matrix(Xbar, nrow = n, ncol = p, byrow = TRUE)

# 3. 특이값 분해를 이용한 주성분분석 
xdec <- svd(Xcentered) 
# (Xcenter = xdec$u * xdec$d * t(xdec$v) 로 분해되었음) 



######################################
## 4. 주성분을 이용한 자료 탐색     ##
######################################


## 3.1. 각 주성분이 나타내는 변동은? 
par(mfrow = c(3,7))
for (j in 1:3) { 
  for( k in -3:3){
    drawface( Xbar + k * xdec$d[j]*xdec$v[,j] / sqrt(n), 
              main = paste("PC", j, ": ", k, "sd",sep = ""))
  }
}

## 3.2. 차원 K로 차원축소 
Score <- as.data.frame( xdec$u )
Score$names <- FirstnamesC
Score %>% ggplot(aes(x = V1, y = V2)) +  geom_point() # 주성분 변수 2개로 차원 축소


######################################
## 3. 주성분을 이용한 이미지 복원   ##
######################################

## 7개의 얼굴을 골라서 주성분 K개로만 이미지를 복원해보자

rid <- sample(1:n,7) # 손으로 고르려면 rid <- c(1,12,45,70,100) 와 같이 번호를 입력 
nface <- length(rid)
K = c(5, 20, 100)

{ 
  par(mfrow = c(4,nface))
  # 그림의 1열: 원 자료 
  for (i in rid) { drawface(X[i,], main = FigureNamesC[i])}
  # 그림의 2,3,5열: K개의 주성분을 이용하여 이미지 복원
  for (j in 1:3) { k <- K[j]; 
    for (i in rid) drawface(  Xbar + (xdec$u[i,1:k] * xdec$d[1:k]) %*% t(xdec$v[,1:k]) ) }
}

 









#######################################
## 4. 시간이 남으면 Serena vs Scott  ##
#######################################

## 이번에는 Serena 와 Scott이라는 first name 을 가진 얼굴만을 뽑아, 자료행렬로 만든다. 
names_with_id1 <- startsWith(ALLfilenames,"Serena")    
names_with_id2 <- startsWith(ALLfilenames,"Scott") 
filenamesC <- c( ALLfilenames[names_with_id1], ALLfilenames[names_with_id2] )
FirstnamesC <- c( FirstNames[names_with_id1], FirstNames[names_with_id2] )

n <- length(filenamesC)
X = c()
for(i in 1:n){
  path <- paste("./faces/", filenamesC[i], sep = "")
  img <-  matrix( imagecrop( readJPEG(source = path) ), nrow = 1 )    
  X = rbind(X,img)
}

## 자료행렬 X의 행의 갯수(number of rows)와 열의 갯수(number of columns)를 확인하자 
nrow(X)
(p <- ncol(X))

#####################################################
##  Serena vs Scott: 자료행렬을 이용해 주성분 찾기 ##
#####################################################

# 1. 자료의 평균을 구한다 
Xbar <- colMeans(X) 
par(mfrow = c(1,1)); drawface(Xbar, main = "얼굴사진의 평균")

# 2. 평균을 뺀 자료행렬 
Xcentered <- X - matrix(Xbar, nrow = n, ncol = p, byrow = TRUE)

# 3. 특이값 분해를 이용한 주성분분석 
xdec <- svd(Xcentered)  

# 4. 각 주성분이 나타내는 변동은? 
par(mfrow = c(3,7))
for (j in 1:3) { 
  for( k in -3:3){
    drawface( Xbar + k * xdec$d[j]*xdec$v[,j] / sqrt(n), 
              main = paste("PC", j, ": ", k, "sd",sep = ""))
  }
}

# 5. 주성분 변수 2개로 차원 축소   
Score <- as.data.frame( xdec$u )
Score$names <- FirstnamesC
Score %>% ggplot(aes(x = V1, y = V2, color = names)) +  geom_point()




 
