function A = logmJ(VU)
% LOGMJ returns the matrix principal logarithm of VU, if VU is not
% involution. 
% If VU is involution and of dimension p = 2 or 3, then returns any of two
% elements A \in so(p) satisfying exp(A) =VU and norm(A,'fro') = sqrt(2) pi
%
% June 9, 2015 Sungkyu Jung.


[p,~]=size(VU);
A = logm(VU); % rotation parameter
% If V*U' is antipodal, then replace A with any real A with norm(A) = pi
if p == 2 && (abs(VU(1) + 1) < eps)% works for p = 2 or p = 3
    A = [0 pi; -pi 0];
end
if p == 3 && ( abs(norm(A,'fro') - sqrt(2)*pi) <eps )
    a =rot2quat(VU);
    theta = pi; 
    a = a(2:4); 
    A = [0 -a(3) a(2); a(3) 0 -a(1) ; -a(2) a(1) 0] * theta; 
end