function varargout = scrotdist( varargin )
[varargout{1:nargout}] = MSRcurve( varargin{:} );
end
 


