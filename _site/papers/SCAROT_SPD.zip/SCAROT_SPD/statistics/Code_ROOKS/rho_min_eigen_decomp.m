function [Dx,Ux,rho_dist]=rho_min_eigen_decomp(X,Dy,Uy,k)
%Assuming that X is an SPD matrix with no repeated eigenvalues.  Finds the
%eigen-decomposition of X that has minimal scaling rotation distance from
%the point (Dy,Uy) from (Diag^+ x SO)(p).
p=length(X);
Adj=eye(p);
Adj(p,p)=-1;

%Ensure that rotation matrix for X has determinant equal to 1.
[Ux,Dx]=eig(X);
if det(Ux)<0
    Ux=Ux*Adj;
end

%Compute all eigen-decompositions of X.
all_perms=perm_mats(p);
all_sign_changes=sign_change_mats(p);
count=0;

eig_decompsX=cell(length(all_perms)*length(all_sign_changes),2);
for i=1:length(all_perms)
    for j=1:length(all_sign_changes)
        count=count+1;
        eig_decompsX{count,1}=Ux*all_sign_changes{j,1}*all_perms{i,1}';
        eig_decompsX{count,2}=all_perms{i,1}*Dx*all_perms{i,1}';
    end
end

%All scaling rotation distances.
num_versions=factorial(p)*(2^(p-1));
XY_dists=zeros(num_versions,1);
for i=1:num_versions
    XY_dists(i)=scale_rot_dist(Uy,Dy,eig_decompsX{i,1},eig_decompsX{i,2},k);
end

[rho_dist,ind]=min(XY_dists);

Ux=eig_decompsX{ind,1};
Dx=eig_decompsX{ind,2};
end