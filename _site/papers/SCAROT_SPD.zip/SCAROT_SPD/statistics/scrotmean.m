function [Mu,V,Lambda,combinedData] = scrotmean(Array) 


[p,~,n]= size(Array);
% initialvalues
Mu = matd(mean(vecd(Array),2));
[V, Lambda]=pickaversion(Mu);
ArrayU = zeros(p,p,n);
diagDvec = zeros(p,n);
TOL = 1e-9;
cnt = 0;
Muarray = zeros(p,p,50);
Muarray(:,:,1) = Mu; 

while true
    for i = 1:n
        [ArrayU(:,:,i), D]= optver(V,Lambda,Array(:,:,i));
        diagDvec(:,i) = diag(D);
    end
    LambdaNew = diag(geodmeanDiag(diagDvec));
    Vnew = geodmeanSO(ArrayU);
    newMu = Vnew * LambdaNew *Vnew';
    cnt = cnt+1;
    Muarray(:,:,cnt+1) = newMu;
    if norm(newMu - Mu) < TOL || cnt > 50 || norm(Vnew) < 1-eps;
        Mu = newMu;
        break;
    end
    Mu = newMu;
    Lambda = LambdaNew;
    V = Vnew; 
end



%% Now given the aligned data (ArrayU,diagDvec) and the mean (Lambda,V) (or Mu), do PCA
Udata = zeros(3,n);
for i = 1:n
    Udata(:,i) = offdiag3(logm(ArrayU(:,:,i)*V'));
end
Ddata = log( diagDvec./repmat(diag(Lambda),1,n) );



combinedData = [Udata ;
    Ddata] ;