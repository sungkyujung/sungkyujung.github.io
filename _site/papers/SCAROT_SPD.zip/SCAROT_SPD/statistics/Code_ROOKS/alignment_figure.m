%Alignment Figures%
rng(0);

n=200;
mean=[0 1 5];
cov=diag([0.10 0.20 0.20]);

sample=mvnrnd(mean,cov,n);
cross_prod_sample=zeros(n,3);
cross_prod_sample(:,1)=sample(:,1);

for i=1:n
    cross_prod_sample(i,2)=exp(sample(i,2));
    cross_prod_sample(i,3)=exp(sample(i,3));
end

scatter3(cross_prod_sample(:,2),cross_prod_sample(:,3),cross_prod_sample(:,1));
scatter3(sample(:,2),sample(:,3),sample(:,1));

SPD_mats=cell(n,1);
for i=1:n
    SPD_mats{i,1}=rot2Dmat(cross_prod_sample(i,1))*diag([cross_prod_sample(i,2) cross_prod_sample(i,3)])*rot2Dmat(cross_prod_sample(i,1))';
end

SPD_coords=zeros(n,3);
for i=1:n
    SPD_coords(i,1)=SPD_mats{i,1}(1,1);
    SPD_coords(i,2)=SPD_mats{i,1}(2,2);
    SPD_coords(i,3)=SPD_mats{i,1}(1,2);
end

scatter3(SPD_coords(:,1),SPD_coords(:,2),SPD_coords(:,3));

%Create 4 versions of the coordinates on the cross-product space.%
Perm=[1 0 0; 0 0 1; 0 1 0];
shift=[pi/2*ones(n,1) zeros(n,2)];

cross_prod_versions=cell(4,1);
cross_prod_versions{1}=zeros(n,3);
cross_prod_versions{2}=zeros(n,3);
cross_prod_versions{3}=zeros(n,3);
cross_prod_versions{4}=zeros(n,3);

for j=1:4
    cross_prod_versions{j}=cross_prod_sample*(Perm^(j-1))'+(j-1)*shift;
end

colors=cell(4,1);
colors{1}='k';
colors{2}='r';
colors{3}='b';
colors{4}='g';

%Determine location parameters for different versions of
%eigen-decompositions.
exp_mean=[0 exp(1) exp(5)];
version_loc_parms=zeros(4,3);
for j=1:4
    version_loc_parms(j,:)=exp_mean*(Perm^(j-1))'+[(pi/2)*(j-1) 0 0];
end

%Compute SPD matrix location parameter.
SPD_loc_parm_mat=rot2Dmat(exp_mean(1))*diag([exp_mean(2) exp_mean(3)])*rot2Dmat(exp_mean(1))';
SPD_loc_parm=[SPD_loc_parm_mat(1,1) SPD_loc_parm_mat(2,2) SPD_loc_parm_mat(1,2)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute the scaling rotation curves between each eigen-decomposition and
%the alignment point.

R_A=rot2Dmat(version_loc_parms(3,1));
D_A=diag([version_loc_parms(3,2) version_loc_parms(3,3)]);

R_1=rot2Dmat(cross_prod_versions{1}(1,1));
D_1=diag([cross_prod_versions{1}(1,2) cross_prod_versions{1}(1,3)]);

R_2=rot2Dmat(cross_prod_versions{2}(1,1));
D_2=diag([cross_prod_versions{2}(1,2) cross_prod_versions{2}(1,3)]);

R_3=rot2Dmat(cross_prod_versions{3}(1,1));
D_3=diag([cross_prod_versions{3}(1,2) cross_prod_versions{3}(1,3)]);

R_4=rot2Dmat(cross_prod_versions{4}(1,1));
D_4=diag([cross_prod_versions{4}(1,2) cross_prod_versions{4}(1,3)]);

t=linspace(0,1,1000);

SR_Curve_Rot1=cell(length(t),1);
SR_Curve_Scale1=cell(length(t),1);
SR_Curve_Rot2=cell(length(t),1);
SR_Curve_Scale2=cell(length(t),1);
SR_Curve_Rot3=cell(length(t),1);
SR_Curve_Scale3=cell(length(t),1);
SR_Curve_Rot4=cell(length(t),1);
SR_Curve_Scale4=cell(length(t),1);
for i=1:length(t)
    SR_Curve_Rot1{i}=expm(t(i)*logm(R_A*R_1'))*R_1;
    SR_Curve_Scale1{i}=expm(t(i)*logm(D_A/D_1))*D_1;
    
    SR_Curve_Rot2{i}=expm(t(i)*logm(R_A*R_2'))*R_2;
    SR_Curve_Scale2{i}=expm(t(i)*logm(D_A/D_2))*D_2;
    
    SR_Curve_Rot3{i}=expm(t(i)*logm(R_A*R_3'))*R_3;
    SR_Curve_Scale3{i}=expm(t(i)*logm(D_A/D_3))*D_3;
    
    SR_Curve_Rot4{i}=expm(t(i)*logm(R_A*R_4'))*R_4;
    SR_Curve_Scale4{i}=expm(t(i)*logm(D_A/D_4))*D_4;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:4
    scatter3(cross_prod_versions{j}(1,2),cross_prod_versions{j}(1,3),cross_prod_versions{j}(1,1),colors{j},'filled')
    hold on
end
title('Diag^+(2) \times SO(2)')
xlabel('\lambda_1')
ylabel('\lambda_2')
zlabel('Rotation Angle')
hold on

scatter3(version_loc_parms(3,2),version_loc_parms(3,3),version_loc_parms(3,1),72,'m','filled');
align_txt='(D_A,U_A)';
text(version_loc_parms(3,2),version_loc_parms(3,3),version_loc_parms(3,1),align_txt);

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\Alignment_Plot.pdf')