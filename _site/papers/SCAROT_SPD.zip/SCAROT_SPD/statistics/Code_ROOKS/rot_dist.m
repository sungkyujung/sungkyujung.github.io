function output=rot_dist(U1,U2)
%Calculates distance between rotation matrices U1 and U2 using the usual
%Riemannian metric for SO(p).
output=sqrt(0.5*trace(rotlogm(U2*U1')*rotlogm(U2*U1')'));
end