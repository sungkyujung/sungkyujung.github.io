function output=rot2Dmat(theta)
%Produces 2x2 rotation matrix corresponding to counterclockwise rotation by
%angle theta in the plane.
output=[cos(theta) -sin(theta); sin(theta) cos(theta)];
end