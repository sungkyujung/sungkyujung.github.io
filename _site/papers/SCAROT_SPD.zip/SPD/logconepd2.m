function logconepd2(range,evalpt)
% Draw log cone struncture of 2x2 p.d. matrix
if nargin == 1;
    evalpt = 20;
end


range = abs(range);
evalpt = round(abs(evalpt));

aa = exp(linspace(log(1/range),log(range),evalpt));
bb = exp(linspace(log(1/range),log(range),evalpt));
[X,Y] = meshgrid(aa,bb);
[la lb] = size(X);
Z1 = sqrt(X.*Y)*0.9;
Xi = X;Yi =Y;Z1i = Z1;
for i=1:la;
    for j=1:lb; 
        aaa = [X(i,j) Z1(i,j); Z1(i,j) Y(i,j)];
        bbb = logm(aaa);
        Xi(i,j) = bbb(1,1);
        Yi(i,j) = bbb(2,2);
        Z1i(i,j) = bbb(1,2);
    end
end

h1 = surf(Xi,Yi,Z1i);set(h1,'facealpha',0.6,'EdgeColor','none')
hold on;

Z2 = -sqrt(X.*Y)*0.9;
Xi = X;Yi =Y;Z1i = Z1;
for i=1:la;
    for j=1:lb; 
        aaa = [X(i,j) Z2(i,j); Z2(i,j) Y(i,j)];
        bbb = logm(aaa);
        Xi(i,j) = bbb(1,1);
        Yi(i,j) = bbb(2,2);
        Z1i(i,j) = bbb(1,2);
    end
end
h2 = surf(Xi,Yi,Z1i);set(h2,'facealpha',0.6,'EdgeColor','none')
axis equal;
xlabel('diagonal 1');
ylabel('diagonal 2');
zlabel('off-diagonal');
title(' 2x2 p.d. matrices: inside of surface')