function output=weighted_minscrot_mean(sample,weights,initial_guess)
%Function for computing weighted location estimator using the Procrustes type
%alignment estimation procedure.  The input dataset should be an nx1 cell
%containing SPD matrices.  Initial guess should be an SPD matrix.

%Pre-processing%
[nrow1,ncol1]=size(sample{1});

if nrow1~=ncol1
    disp('Input matrices must be square.');
    return;
end

if nrow1>3
    disp('Only p=2 or p=3 is allowed.');
    return;
end
n=length(sample);
p=nrow1;
Adj=eye(p);
Adj(p,p)=-1;

%Obtain initial eigen-decompositions of the sample SPD matrices.%
sample_iso=zeros(n,1);
eigen_decomps=cell(n,2);
for i=1:n
    [eigen_decomps{i,1},eigen_decomps{i,2}]=eig(sample{i});
    if det(eigen_decomps{i,1})<0
        eigen_decomps{i,1}=eigen_decomps{i,1}*Adj;
    end
    if abs(max(diag(eigen_decomps{i,2}))-min(diag(eigen_decomps{i,2})))<10^(-16);
        sample_iso(i)=1;
    end
end

%Create a cell containing all possible eigen-decompositions of each sample
%SPD matrix.%
Perms=perm_mats(p);
Sign_changes=sign_change_mats(p);
num_versions=length(Perms)*length(Sign_changes);

sample_versions=cell(n,2,num_versions);
for i=1:n
    count=0;
    for j=1:length(Perms)
        for k=1:length(Sign_changes)
            count=count+1;
            sample_versions{i,1,count}=eigen_decomps{i,1}*Sign_changes{k}*Perms{j}';
            sample_versions{i,2,count}=Perms{j}*eigen_decomps{i,2}*Perms{j}';
        end
    end
end

%Pick an initial solution for the weighted MSR mean.%
[U,D]=eig(initial_guess);
if det(U)<0
    U=U*Adj;
end

initial_sol=cell(1,2);
%initial_sol{1,1}=eigen_decomps{2,1};
%initial_sol{1,2}=eigen_decomps{2,2};
initial_sol{1,1}=U;
initial_sol{1,2}=D;

%Create initial set of aligned eigen-decompositions that are aligned with
%the initial solution eigen-decomposition.
aligned_eigen_decomps=cell(n,2);
old_MSR_variance=0;
for i=1:n
    if sample_iso==1
        aligned_eigen_decomps{i,1}=initial_sol{i,1};
        aligned_eigen_decomps{i,2}=eigen_decomps{i,2};
        MSR_dist=diagplus_dist(eigen_decomps{i,2},initial_sol{1,2});
    else
        dists=zeros(num_versions,1);
        for j=1:num_versions
            dists(j)=scale_rot_dist(sample_versions{i,1,j},sample_versions{i,2,j},initial_sol{1,1},initial_sol{1,2},1);
        end
        [MSR_dist,ind]=min(dists);
        aligned_eigen_decomps{i,1}=sample_versions{i,1,ind};
        aligned_eigen_decomps{i,2}=sample_versions{i,2,ind};
    end
    old_MSR_variance=old_MSR_variance+weights(i)*MSR_dist^2;
end

new_MSR_variance=old_MSR_variance;
diff=1;
tol=10^-7;

while diff>tol
    old_MSR_variance=new_MSR_variance;
    %Compute the intrinsic sample means for the eigenvalues and rotation
    %matrix.
    
    new_sol=cell(1,2);
    %Mean rotation%
    initial_weighted_rot_mean=zeros(p,p);
    for i=1:n
        initial_weighted_rot_mean=initial_weighted_rot_mean+weights(i)*aligned_eigen_decomps{i,1};
    end
    %Project this mean onto SO(p).
    [U,~,V]=svd(initial_weighted_rot_mean);
    initial_weighted_rot_mean=U*V';
    
    new_sol{1,1}=weighted_rot_sample_mean(aligned_eigen_decomps(:,1),weights,initial_weighted_rot_mean);
    %Mean eigenvalues%
    log_eval_mean=zeros(p,p);
    for i=1:n
        log_eval_mean=log_eval_mean+weights(i)*logm(aligned_eigen_decomps{i,2});
    end
    new_sol{1,2}=expm(log_eval_mean);
    
    %Create set of aligned eigen-decompositions that are aligned with
    %the new solution eigen-decomposition.
    aligned_eigen_decomps=cell(n,2);
    new_MSR_variance=0;
    for i=1:n
        if sample_iso==1
            aligned_eigen_decomps{i,1}=new_sol{i,1};
            aligned_eigen_decomps{i,2}=eigen_decomps{i,2};
            MSR_dist=diagplus_dist(eigen_decomps{i,2},new_sol{1,2});
        else
            dists=zeros(num_versions,1);
            for j=1:num_versions
                dists(j)=scale_rot_dist(sample_versions{i,1,j},sample_versions{i,2,j},new_sol{1,1},new_sol{1,2},1);
            end
            [MSR_dist,ind]=min(dists);
            aligned_eigen_decomps{i,1}=sample_versions{i,1,ind};
            aligned_eigen_decomps{i,2}=sample_versions{i,2,ind};
        end
        new_MSR_variance=new_MSR_variance+weights(i)*MSR_dist^2;
    end
    
    new_SPD=new_sol{1,1}*new_sol{1,2}*new_sol{1,1}';
    diff=abs(old_MSR_variance-new_MSR_variance);
end
output=new_SPD;
end