cd 'C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials';
%Using the EM Algorithm to perform one-sample likelihood ratio test of
%location parameter for p=2.

%Using the EM Algorithm to estimate parameters%

p=2;
%Population parameters%
evals_mean=[10 0; 0 2];
evecs_mean=rot2Dmat(pi/6);

eval_conc_parm=2;
evecs_conc_parm=5;

%Sample sizes%
n=[30;50;100];

%Number of simulations%
num_sim=500;

%Preallocate cells for parameter estimates%
eval_mean_ests=cell(length(n),num_sim);
evec_mean_ests=cell(length(n),num_sim);
SPD_mean_ests=cell(length(n),num_sim);
eval_conc_parm_ests=zeros(length(n),num_sim);
evecs_conc_parm_ests=zeros(length(n),num_sim);

K=1;
A=[1 0; 0 -1];

%Create set of signed permutation matrices%
perms=perm_mats(p);
sign_changes=sign_change_mats(p);
size=2^(p-1)*factorial(p);

signed_perms=cell(size,1);
ind=0;

for i=1:length(perms)
    for j=1:length(sign_changes)
        ind=ind+1;
        signed_perms{ind}=perms{i}*sign_changes{j};
    end
end

%Specify truncated normal for simulating rotation angles%
pd=makedist('Normal','mu',0,'sigma',sqrt(1/evecs_conc_parm));
t=truncate(pd,-pi,pi);

%Set tolerance.
tol=10^-10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

null_log_lik=zeros(length(n),num_sim);
alt_log_lik=zeros(length(n),num_sim);
LRT_stats=zeros(length(n),num_sim);

rng(1033)
count=0;
for i=1:length(n)
    for j=1:num_sim
        count=count+1
        %Simulate data: Eigenvalues follow log-normal dist and eigenvectors
        %angle follows truncated normal dist.
        log_evals=mvnrnd(zeros(1,p),(1/eval_conc_parm)*eye(p),n(i));
        angles=random(t,n(i),1);
        %Map the simulated data to SPD matrices.
        SPD_mats=cell(n(i),1);
        for a=1:n(i)
            SPD_mats{a}=(rot2Dmat(angles(a))*evecs_mean)*(expm(diag(log_evals(a,:)))*evals_mean)*(rot2Dmat(angles(a))*evecs_mean)';
        end
        %Obtain observed eigen-decompositions.
        observed_eigen_decomps=cell(n(i),2);
        unif=rand(n(i),1);
        version_num=ceil(size*unif);
        
        for a=1:n(i)
            [observed_eigen_decomps{a,2},observed_eigen_decomps{a,1}]=eig(SPD_mats{a});
            if det(observed_eigen_decomps{a,2})<0
                observed_eigen_decomps{a,2}=observed_eigen_decomps{a,2}*A;
            end
            
            observed_eigen_decomps{a,1}=signed_perms{version_num(a)}*observed_eigen_decomps{a,1}*signed_perms{version_num(a)}';
            observed_eigen_decomps{a,2}=observed_eigen_decomps{a,2}*signed_perms{version_num(a)}';
        end
        
        %Create shifted observed eigenvector matrices for computing
        %weighted eigenvector matrix mean.
        ind=0;
        shifted_rot_mats=cell(n(i)*size,1);
        for a=1:n(i)
            for b=1:size
                ind=ind+1;
                shifted_rot_mats{ind}=observed_eigen_decomps{a,2}*signed_perms{b};
            end
        end
        
        %Set initial values for model parameters.
        probs=ones(size,1)/size;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %Maximize log-likelihood under alternative hypothesis.
        
        %Initial estimates for eigenvalue and eigenvector matrix mean will
        %come from eigen-decomposition of Log-Euclidean mean of SPD_mats.
        LE_mean=log_euclidean_mean(SPD_mats);
        [old_evecs_mean,old_evals_mean]=eig(LE_mean);
        
        if det(old_evecs_mean)<0
            old_evecs_mean=old_evecs_mean*A;
        end
        
        new_evals_mean=old_evals_mean;
        new_evecs_mean=old_evecs_mean;
        
        %Initial values for concentration parameters.
        old_eval_conc_parm=eval_conc_parm;
        old_evecs_conc_parm=evecs_conc_parm;
        
        new_eval_conc_parm=old_eval_conc_parm;
        new_evecs_conc_parm=old_evecs_conc_parm;
        
        %Initialize density functions for the initial expectation step.
        densities=zeros(n(i),size);
        N_fun=sqrt(2*pi/old_evecs_conc_parm)*erf(pi*sqrt(old_evecs_conc_parm/2));
        for a=1:n(i)
            for b=1:size
                densities(a,b)=(old_eval_conc_parm/(2*pi*N_fun*det(observed_eigen_decomps{a,1})))*exp(-(old_eval_conc_parm/2)*(diagplus_dist(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b},old_evals_mean))^2-(old_evecs_conc_parm/2)*(rot_dist(observed_eigen_decomps{a,2}*signed_perms{b},old_evecs_mean))^2);
            end
        end
        
        %Initialize observed log-likelihood.
        old_log_lik=ones(n(i),1)'*log(densities*probs);
        new_log_lik=old_log_lik;
        
        diff=1;
        num_loops=0;
        while diff>tol && num_loops<100
            num_loops=num_loops+1;
            old_log_lik=new_log_lik;
            %Expectation Step
            version_indicators=diag(densities*probs)\densities*diag(probs);
            %Maximization Step
            %Updated Estimate for Eigenvalue Matrix Mean
            new_evals_mean=zeros(p,p);
            for a=1:n(i)
                for b=1:size
                    new_evals_mean=new_evals_mean+(version_indicators(a,b)/n(i))*logm(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b});
                end
            end
            new_evals_mean=expm(new_evals_mean);
            
            %Updated Estimate for eigenvalues concentration parameter.
            %MLE for evals concentration parameter.
            weighted_evals_var=0;
            for a=1:n(i)
                for b=1:size
                    weighted_evals_var=weighted_evals_var+(version_indicators(a,b)/n(i))*(diagplus_dist(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b},new_evals_mean))^2;
                end
            end
            new_eval_conc_parm=p/weighted_evals_var;
            
            %Updated Estimate for Eigenvector Matrix Mean
            weights=zeros(n(i)*size,1);
            ind=0;
            for a=1:n(i)
                for b=1:size
                    ind=ind+1;
                    weights(ind)=version_indicators(a,b)/n(i);
                end
            end
    
            new_evecs_mean=weighted_rot_sample_mean(shifted_rot_mats,weights,old_evecs_mean);
            
            %Updated Estimate for Eigenvector Matrix Concentration
            %Parameter.
            weighted_angle_var=0;
            for a=1:n(i)
                for b=1:size
                    weighted_angle_var=weighted_angle_var+(version_indicators(a,b)/n(i))*(rot_dist(observed_eigen_decomps{a,2}*signed_perms{b},new_evecs_mean))^2;
                end
            end
    
            new_evecs_conc_parm=invmodV_fun(K*weighted_angle_var,K);
            
            %Compute density functions using updated parameter estimates.
            densities=zeros(n(i),size);
            N_fun=sqrt(2*pi/new_evecs_conc_parm)*erf(pi*sqrt(new_evecs_conc_parm/2));
            for a=1:n(i)
                for b=1:size
                    densities(a,b)=(new_eval_conc_parm/(2*pi*N_fun*det(observed_eigen_decomps{a,1})))*exp(-(new_eval_conc_parm/2)*(diagplus_dist(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b},new_evals_mean))^2-(new_evecs_conc_parm/2)*(rot_dist(observed_eigen_decomps{a,2}*signed_perms{b},new_evecs_mean))^2);
                end
            end
            
            %Compute log-likelihood using updated parameter estimates.
            new_log_lik=ones(n(i),1)'*log(densities*probs);
    
            diff=abs(new_log_lik-old_log_lik);
        end
        %SPD_mean_ests{i,j}=new_evecs_mean*new_evals_mean*new_evecs_mean';
        %eval_conc_parm_ests(i,j)=new_eval_conc_parm;
        %evecs_conc_parm_ests(i,j)=new_evecs_conc_parm;
        alt_log_lik(i,j)=new_log_lik;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %Maximize observed log-likelihood under null hypothesis (estimate for
        %location parameter is fixed to population value during likelihood
        %maximization).
        
        %Initial estimates for eigenvalue and eigenvector matrix mean will
        %come from eigen-decomposition of Log-Euclidean mean of SPD_mats.
        
        old_evals_mean=evals_mean;
        old_evecs_mean=evecs_mean;
        
        new_evals_mean=old_evals_mean;
        new_evecs_mean=old_evecs_mean;
        
        %Initial values for concentration parameters.
        old_eval_conc_parm=eval_conc_parm;
        old_evecs_conc_parm=evecs_conc_parm;
        
        new_eval_conc_parm=old_eval_conc_parm;
        new_evecs_conc_parm=old_evecs_conc_parm;
        
        %Initialize density functions for the initial expectation step.
        densities=zeros(n(i),size);
        N_fun=sqrt(2*pi/old_evecs_conc_parm)*erf(pi*sqrt(old_evecs_conc_parm/2));
        for a=1:n(i)
            for b=1:size
                densities(a,b)=(old_eval_conc_parm/(2*pi*N_fun*det(observed_eigen_decomps{a,1})))*exp(-(old_eval_conc_parm/2)*(diagplus_dist(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b},old_evals_mean))^2-(old_evecs_conc_parm/2)*(rot_dist(observed_eigen_decomps{a,2}*signed_perms{b},old_evecs_mean))^2);
            end
        end
        
        %Initialize observed log-likelihood.
        old_log_lik=ones(n(i),1)'*log(densities*probs);
        new_log_lik=old_log_lik;
        
        diff=1;
        num_loops=0;
        while diff>tol && num_loops<100
            num_loops=num_loops+1;
            old_log_lik=new_log_lik;
            %Expectation Step
            version_indicators=diag(densities*probs)\densities*diag(probs);
            %Maximization Step
            
            %Updated Estimate for eigenvalues concentration parameter.
            %MLE for evals concentration parameter.
            weighted_evals_var=0;
            for a=1:n(i)
                for b=1:size
                    weighted_evals_var=weighted_evals_var+(version_indicators(a,b)/n(i))*(diagplus_dist(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b},new_evals_mean))^2;
                end
            end
            new_eval_conc_parm=p/weighted_evals_var;
            
            %Updated Estimate for Eigenvector Matrix Concentration
            %Parameter.
            weighted_angle_var=0;
            for a=1:n(i)
                for b=1:size
                    weighted_angle_var=weighted_angle_var+(version_indicators(a,b)/n(i))*(rot_dist(observed_eigen_decomps{a,2}*signed_perms{b},new_evecs_mean))^2;
                end
            end
    
            new_evecs_conc_parm=invmodV_fun(K*weighted_angle_var,K);
            
            %Compute density functions using updated parameter estimates.
            densities=zeros(n(i),size);
            N_fun=sqrt(2*pi/new_evecs_conc_parm)*erf(pi*sqrt(new_evecs_conc_parm/2));
            for a=1:n(i)
                for b=1:size
                    densities(a,b)=(new_eval_conc_parm/(2*pi*N_fun*det(observed_eigen_decomps{a,1})))*exp(-(new_eval_conc_parm/2)*(diagplus_dist(signed_perms{b}'*observed_eigen_decomps{a,1}*signed_perms{b},new_evals_mean))^2-(new_evecs_conc_parm/2)*(rot_dist(observed_eigen_decomps{a,2}*signed_perms{b},new_evecs_mean))^2);
                end
            end
            
            %Compute log-likelihood using updated parameter estimates.
            new_log_lik=ones(n(i),1)'*log(densities*probs);
    
            diff=abs(new_log_lik-old_log_lik);
        end
        %SPD_mean_ests{i,j}=new_evecs_mean*new_evals_mean*new_evecs_mean';
        %eval_conc_parm_ests(i,j)=new_eval_conc_parm;
        %evecs_conc_parm_ests(i,j)=new_evecs_conc_parm;
        null_log_lik(i,j)=new_log_lik;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %Compute likelihood ratio test statistics.
        LRT_stats(i,j)=2*(alt_log_lik(i,j)-null_log_lik(i,j));
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
prob_list=linspace(0,1,num_sim);
chi2_quantiles=chi2inv(prob_list,p+0.5*p*(p-1));

for i=1:length(n)
    subplot(1,length(n),i)
    qqplot(LRT_stats(i,:),chi2_quantiles)
    title(['n=' num2str(n(i))])
    xlabel('Quantiles of LRT Statistics')
    ylabel('Quantiles of $$\chi^2(3)$$','interpreter','latex')
    axis square;
end

%Compute empirical type I error rates.
reject_yn=zeros(length(n),num_sim);
alpha=0.10;
for i=1:length(n)
    for j=1:num_sim
        if LRT_stats(i,j)>chi2inv(1-alpha,p+0.5*p*(p-1))
            reject_yn(i,j)=1;
        end
    end
end

typeI_error_probs=(1/num_sim)*reject_yn*ones(num_sim,1)
