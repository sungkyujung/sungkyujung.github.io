function output=log_euclidean_mean(sample)
%Computes the log-Euclidean mean of a sample of symmetric positive-definite
%matrices.  Assuming that sample is a cell containing 
n=length(sample);
p=length(sample{1});
output=zeros(p,p);
for i=1:n
    output=output+(1/n)*logm(sample{i});
end
output=expm(output);
end