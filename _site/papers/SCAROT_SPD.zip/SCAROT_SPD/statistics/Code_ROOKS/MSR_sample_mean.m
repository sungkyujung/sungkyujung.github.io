function output=MSR_sample_mean(sample)
%Function for computing location estimator using the Procrustes type
%alignment estimation procedure.  The input dataset should be an nx1 cell
%containing SPD matrices.

%Pre-processing%
[nrow1,ncol1]=size(sample{1});

if nrow1~=ncol1
    disp('Input matrices must be square.');
    return;
end

if nrow1>3
    disp('Only p=2 or p=3 is allowed.');
    return;
end
n=length(sample);
p=nrow1;
Adj=eye(p);
Adj(p,p)=-1;

%Pick initial guess for MSR sample mean.
old_sol=sample{1};
old_sol_eigen=cell(1,2);
[old_sol_eigen{1,1},old_sol_eigen{1,2}]=eig(sample{1});

if det(old_sol_eigen{1,1})<0
    old_sol_eigen{1,1}=old_sol_eigen{1,1}*Adj;
end

new_sol=old_sol;
new_sol_eigen=cell(1,2);
new_sol_eigen{1,1}=old_sol_eigen{1,1};
new_sol_eigen{1,2}=old_sol_eigen{1,2};

diff=1;
tol=10^-7;

while diff>tol
    old_sol=new_sol;
    old_sol_eigen{1,1}=new_sol_eigen{1,1};
    old_sol_eigen{1,2}=new_sol_eigen{1,2};
    
    aligned_eigen_decomps=cell(n,2);
    %Generate sample of aligned eigen-decompositions.
    old_MSR_variance=0;
    for i=1:n
        [aligned_eigen_decomps{i,1},aligned_eigen_decomps{i,2}]=align_eigen(sample{i},old_sol_eigen{1,2},old_sol_eigen{1,1});
        old_MSR_variance=old_MSR_variance+(1/n)*(scale_rot_dist(aligned_eigen_decomps{i,1},aligned_eigen_decomps{i,2},old_sol_eigen{1,1},old_sol_eigen{1,2},1))^2;
    end
    
    %Compute rotation and scaling means using the aligned
    %eigen-decompositions.
    %Rotation mean.
    new_sol_eigen{1,1}=rot_sample_mean(aligned_eigen_decomps(:,1));
    %Scaling mean.
    new_sol_eigen{1,2}=zeros(p,p);
    for i=1:n
        new_sol_eigen{1,2}=new_sol_eigen{1,2}+(1/n)*logm(aligned_eigen_decomps{i,2});
    end
    new_sol_eigen{1,2}=expm(new_sol_eigen{1,2});
    
    new_sol=new_sol_eigen{1,1}*new_sol_eigen{1,2}*new_sol_eigen{1,1}';
    
    %Compute the sample MSR variance using the new MSR mean solution.
    new_MSR_variance=0;
    aligned_eigen_decomps=cell(n,2);
    for i=1:n
        [aligned_eigen_decomps{i,1},aligned_eigen_decomps{i,2}]=align_eigen(sample{i},new_sol_eigen{1,2},new_sol_eigen{1,1});
        new_MSR_variance=new_MSR_variance+(1/n)*(scale_rot_dist(aligned_eigen_decomps{i,1},aligned_eigen_decomps{i,2},new_sol_eigen{1,1},new_sol_eigen{1,2},1))^2;
    end
    diff=abs(old_MSR_variance-new_MSR_variance);
end
output=new_sol;
end