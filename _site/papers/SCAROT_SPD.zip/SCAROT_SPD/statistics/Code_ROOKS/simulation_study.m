warning('off','all')

%Simulation Study for Non-parametric Mean Estimation%
num_sim=1000;
n=[20 50];
%Sigma=[4 2; 2 10];
Sigma=rot3Dmat(pi/6,[1; 1; 1])*diag([10 4 2])*rot3Dmat(pi/6,[1; 1; 1])';
p=length(Sigma);
q_sym=0.5*p*(p+1);
q_asym=0.5*p*(p-1);
df=50; %Degrees of freedom for Wishart distribution%
%Eigen-decomposition of Sigma.%
[Sigma_evecs,Sigma_evals]=eig(Sigma);
A=eye(p);
A(p,p)=-1;
if det(Sigma_evecs)<0
    Sigma_evecs=Sigma_evecs*A;
end

log_Sigma=logm(Sigma);
%Vectorize log_Sigma%
log_Sigma_vec=zeros(q_sym,1);
coord=0;
for j=1:p
    for i=j:p
        coord=coord+1;
        log_Sigma_vec(coord)=log_Sigma(i,j);
    end
end

chol_Sigma=chol(Sigma)';
chol_Sigma_vec=zeros(q_sym,1);
coord=0;
for j=1:p
    for i=j:p
        coord=coord+1;
        chol_Sigma_vec(coord)=chol_Sigma(i,j);
    end
end

sd=0.10;

euclidean_means=cell(num_sim,length(n),4);
log_euclidean_means=cell(num_sim,length(n),4);
AI_means=cell(num_sim,length(n),4);
procrustes_means=cell(num_sim,length(n),4);
MSR_means=cell(num_sim,length(n),4);
MSR_mean_times=cell(num_sim,length(n),4);

rng(10);

for i=1:num_sim
    for type=1:4
        for j=1:length(n)
            if type==1 %Wishart data generation%
                sample_mats=cell(n(j),1);
                for k1=1:n(j)
                    sample=mvnrnd(zeros(1,p),Sigma,df);
                    sample_mats{k1}=sample'*sample/df;
                end
                %Euclidean mean
                euclidean_means{i,j,type}=zeros(p,p);
                for a=1:n(j)
                    euclidean_means{i,j,type}=euclidean_means{i,j,type}+sample_mats{a}/n(j);
                end
                %Log-Euclidean mean
                log_euclidean_means{i,j,type}=zeros(p,p);
                for b=1:n(j)
                    log_euclidean_means{i,j,type}=log_euclidean_means{i,j,type}+logm(sample_mats{b})/n(j);
                end
                log_euclidean_means{i,j,type}=expm(log_euclidean_means{i,j,type});
                %Affine-Invariant mean
                AI_means{i,j,type}=AImean(sample_mats);
                %Procrustes Size and Shape mean
                procrustes_means{i,j,type}=procrustesSS_mean(sample_mats);
                %Minimal Scaling-Rotation mean
                tic;
                MSR_means{i,j,type}=minscrot_mean(sample_mats);
                %MSR_means{i,j,type}=MSR_sample_mean(sample_mats);
                MSR_mean_times{i,j,type}=toc;
                
            elseif type==2 %Log-Euclidean data generation%
                sample_mats=cell(n(j),1);
                sample_mats_coords=mvnrnd(log_Sigma_vec',sd^2*eye(q_sym),n(j));
                for k2=1:n(j)
                    sample_mats{k2}=zeros(p,p);
                    coord=0;
                    for b=1:p
                        for a=b:p
                            coord=coord+1;
                            if a==b
                                sample_mats{k2}(a,b)=0.5*sample_mats_coords(k2,coord);
                            else
                                sample_mats{k2}(a,b)=sample_mats_coords(k2,coord);
                            end
                        end
                    end
                    sample_mats{k2}=sample_mats{k2}+sample_mats{k2}';
                    sample_mats{k2}=expm(sample_mats{k2});
                end
                %Euclidean mean
                euclidean_means{i,j,type}=zeros(p,p);
                for a=1:n(j)
                    euclidean_means{i,j,type}=euclidean_means{i,j,type}+sample_mats{a}/n(j);
                end
                %Log-Euclidean mean
                log_euclidean_means{i,j,type}=zeros(p,p);
                for b=1:n(j)
                    log_euclidean_means{i,j,type}=log_euclidean_means{i,j,type}+logm(sample_mats{b})/n(j);
                end
                log_euclidean_means{i,j,type}=expm(log_euclidean_means{i,j,type});
                %Affine-Invariant mean
                AI_means{i,j,type}=AImean(sample_mats);
                %Procrustes Size and Shape mean
                procrustes_means{i,j,type}=procrustesSS_mean(sample_mats);
                %Minimal Scaling-Rotation mean
                tic;
                MSR_means{i,j,type}=minscrot_mean(sample_mats);
                %MSR_means{i,j,type}=MSR_sample_mean(sample_mats);
                MSR_mean_times{i,j,type}=toc;
                
            elseif type==3 %Scaling Rotation data generation%
                sample_mats=cell(n(j),1);
                rotation_mats=cell(n(j),1);
                rotation_coords=mvnrnd(zeros(1,q_asym),sd^2*eye(q_asym),n(j));
                
                scale_mats=cell(n(j),1);
                scale_coords=mvnrnd(diag(logm(Sigma_evals))',sd^2*eye(p),n(j));
                for k3=1:n(j)
                    rotation_mats{k3}=zeros(p,p);
                    coord=0;
                    for b=1:p
                        for a=b+1:p
                            rotation_mats{k3}(a,b)=rotation_coords(k3,q_asym-coord)*(-1)^(q_asym-coord+1);
                            coord=coord+1;
                        end
                    end
                    rotation_mats{k3}=rotation_mats{k3}-rotation_mats{k3}';
                    rotation_mats{k3}=expm(rotation_mats{k3})*Sigma_evecs;
                    
                    scale_mats{k3}=expm(diag(scale_coords(k3,:)));
                    
                    sample_mats{k3}=rotation_mats{k3}*scale_mats{k3}*rotation_mats{k3}';
                end
                %Euclidean mean
                euclidean_means{i,j,type}=zeros(p,p);
                for a=1:n(j)
                    euclidean_means{i,j,type}=euclidean_means{i,j,type}+sample_mats{a}/n(j);
                end
                %Log-Euclidean mean
                log_euclidean_means{i,j,type}=zeros(p,p);
                for b=1:n(j)
                    log_euclidean_means{i,j,type}=log_euclidean_means{i,j,type}+logm(sample_mats{b})/n(j);
                end
                log_euclidean_means{i,j,type}=expm(log_euclidean_means{i,j,type});
                %Affine-Invariant mean
                AI_means{i,j,type}=AImean(sample_mats);
                %Procrustes Size and Shape mean
                procrustes_means{i,j,type}=procrustesSS_mean(sample_mats);
                %Minimal Scaling-Rotation mean
                tic;
                MSR_means{i,j,type}=minscrot_mean(sample_mats);
                %MSR_means{i,j,type}=MSR_sample_mean(sample_mats);
                MSR_mean_times{i,j,type}=toc;
 
            else %Cholesky data generation%
                sample_mats=cell(n(j),1);
                sqroot_coords=mvnrnd(zeros(1,q_sym),sd^2*eye(q_sym),n(j));
                for k4=1:n(j)
                    sample_mats{k4}=zeros(p,p);
                    coord=0;
                    for b=1:p
                        for a=b:p
                            coord=coord+1;
                            sample_mats{k4}(a,b)=sqroot_coords(k4,coord);
                        end
                    end
                    sample_mats{k4}=(sample_mats{k4}+chol_Sigma)*(sample_mats{k4}+chol_Sigma)';
                end
                %Euclidean mean
                euclidean_means{i,j,type}=zeros(p,p);
                for a=1:n(j)
                    euclidean_means{i,j,type}=euclidean_means{i,j,type}+sample_mats{a}/n(j);
                end
                %Log-Euclidean mean
                log_euclidean_means{i,j,type}=zeros(p,p);
                for b=1:n(j)
                    log_euclidean_means{i,j,type}=log_euclidean_means{i,j,type}+logm(sample_mats{b})/n(j);
                end
                log_euclidean_means{i,j,type}=expm(log_euclidean_means{i,j,type});
                %Affine-Invariant mean
                AI_means{i,j,type}=AImean(sample_mats);
                %Procrustes Size and Shape mean
                procrustes_means{i,j,type}=procrustesSS_mean(sample_mats);
                %Minimal Scaling-Rotation mean
                tic;
                MSR_means{i,j,type}=minscrot_mean(sample_mats);
                %MSR_means{i,j,type}=MSR_sample_mean(sample_mats);
                MSR_mean_times{i,j,type}=toc;
            end
        end
    end
    disp(i);
end

save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\euclidean_means_sim1','euclidean_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\log_euclidean_means_sim1','log_euclidean_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\AI_means_sim1','AI_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\MSR_means_sim1','MSR_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\procrustes_means_sim1','procrustes_means')

save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\MSR_mean_times_sim1','MSR_mean_times')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('euclidean_means_sim1')
load('log_euclidean_means_sim1')
load('AI_means_sim1')
load('MSR_means_sim1')
load('procrustes_means_sim1')
load('MSR_mean_times_sim1')
%Compute MSE for each type of estimator.
%1st dim = type of MSE, 2nd dim = sample size, 3rd dim = data gen type
euclidean_means_MSEs=zeros(4,2,4);
log_euclidean_means_MSEs=zeros(4,2,4);
AI_means_MSEs=zeros(4,2,4);
procrustes_means_MSEs=zeros(4,2,4);
MSR_means_MSEs=zeros(4,2,4);

for type=1:4
    for i=1:4
        for j=1:2
            for k=1:num_sim
                if i==1 %Euclidean MSE%
                    euclidean_means_MSEs(i,j,type)=euclidean_means_MSEs(i,j,type)+trace((euclidean_means{k,j,type}-Sigma)'*(euclidean_means{k,j,type}-Sigma))/num_sim;
                    AI_means_MSEs(i,j,type)=AI_means_MSEs(i,j,type)+trace((AI_means{k,j,type}-Sigma)'*(AI_means{k,j,type}-Sigma))/num_sim;
                    log_euclidean_means_MSEs(i,j,type)=log_euclidean_means_MSEs(i,j,type)+trace((log_euclidean_means{k,j,type}-Sigma)'*(log_euclidean_means{k,j,type}-Sigma))/num_sim;
                    procrustes_means_MSEs(i,j,type)=procrustes_means_MSEs(i,j,type)+trace((procrustes_means{k,j,type}-Sigma)'*(procrustes_means{k,j,type}-Sigma))/num_sim;
                    MSR_means_MSEs(i,j,type)=MSR_means_MSEs(i,j,type)+trace((MSR_means{k,j,type}-Sigma)'*(MSR_means{k,j,type}-Sigma))/num_sim;
                    
                elseif i==2 %Log-Euclidean MSE%
                    euclidean_means_MSEs(i,j,type)=euclidean_means_MSEs(i,j,type)+trace((logm(euclidean_means{k,j,type})-logm(Sigma))'*(logm(euclidean_means{k,j,type})-logm(Sigma)))/num_sim;
                    AI_means_MSEs(i,j,type)=AI_means_MSEs(i,j,type)+trace((logm(AI_means{k,j,type})-logm(Sigma))'*(logm(AI_means{k,j,type})-logm(Sigma)))/num_sim;
                    log_euclidean_means_MSEs(i,j,type)=log_euclidean_means_MSEs(i,j,type)+trace((logm(log_euclidean_means{k,j,type})-logm(Sigma))'*(logm(log_euclidean_means{k,j,type})-logm(Sigma)))/num_sim;
                    procrustes_means_MSEs(i,j,type)=procrustes_means_MSEs(i,j,type)+trace((logm(procrustes_means{k,j,type})-logm(Sigma))'*(logm(procrustes_means{k,j,type})-logm(Sigma)))/num_sim;
                    MSR_means_MSEs(i,j,type)=MSR_means_MSEs(i,j,type)+trace((logm(MSR_means{k,j,type})-logm(Sigma))'*(logm(MSR_means{k,j,type})-logm(Sigma)))/num_sim;
                       
                elseif i==3 %MSR MSE%
                    euclidean_means_MSEs(i,j,type)=euclidean_means_MSEs(i,j,type)+(minscrotdist(euclidean_means{k,j,type},Sigma))^2/num_sim;
                    AI_means_MSEs(i,j,type)=AI_means_MSEs(i,j,type)+(minscrotdist(AI_means{k,j,type},Sigma))^2/num_sim;
                    log_euclidean_means_MSEs(i,j,type)=log_euclidean_means_MSEs(i,j,type)+(minscrotdist(log_euclidean_means{k,j,type},Sigma))^2/num_sim;
                    procrustes_means_MSEs(i,j,type)=procrustes_means_MSEs(i,j,type)+(minscrotdist(procrustes_means{k,j,type},Sigma))^2/num_sim;
                    MSR_means_MSEs(i,j,type)=MSR_means_MSEs(i,j,type)+(minscrotdist(MSR_means{k,j,type},Sigma))^2/num_sim;
                    
                else %Procrustes SS MSE%
                    euclidean_means_MSEs(i,j,type)=euclidean_means_MSEs(i,j,type)+(procrustesSS_dist(euclidean_means{k,j,type},Sigma))^2/num_sim;
                    AI_means_MSEs(i,j,type)=AI_means_MSEs(i,j,type)+(procrustesSS_dist(AI_means{k,j,type},Sigma))^2/num_sim;
                    log_euclidean_means_MSEs(i,j,type)=log_euclidean_means_MSEs(i,j,type)+(procrustesSS_dist(log_euclidean_means{k,j,type},Sigma))^2/num_sim;
                    procrustes_means_MSEs(i,j,type)=procrustes_means_MSEs(i,j,type)+(procrustesSS_dist(procrustes_means{k,j,type},Sigma))^2/num_sim;
                    MSR_means_MSEs(i,j,type)=MSR_means_MSEs(i,j,type)+(procrustesSS_dist(MSR_means{k,j,type},Sigma))^2/num_sim;
                end
            end
        end
    end
end
