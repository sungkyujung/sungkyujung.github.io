function output=min_scale_rot_dist(X,Y,k)
%Calculate the length of the minimal length scaling-rotation curve
%connecting eigen-decompositions of SPD matrices X and Y.
[Ux,Dx,Uy,Dy]=min_eigen_pair(X,Y);
output=scale_rot_dist(Ux,Dx,Uy,Dy,k);
end