warning('off','all')
cd 'C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials';

%Simulation Study for Non-parametric Mean Estimation%
num_sim=1000;
n=[20 50];
Sigma=rot2Dmat(pi/6)*diag([10 2])*rot2Dmat(pi/6)';
%Sigma=rot3Dmat(pi/6,[1; 1; 1])*diag([10 4 2])*rot3Dmat(pi/6,[1; 1; 1])';
p=length(Sigma);
q_sym=0.5*p*(p+1);
q_asym=0.5*p*(p-1);
%Eigen-decomposition of Sigma.%
[Sigma_evecs,Sigma_evals]=eig(Sigma);
A=eye(p);
A(p,p)=-1;
if det(Sigma_evecs)<0
    Sigma_evecs=Sigma_evecs*A;
end

%Create covariance matrix for rotation and scaling coordinates on the
%log-scale.
%Isotropic covariance structure on the tangent space.
tangent_covs=cell(5,1);
%tangent_covs{1,1}=0.10*eye(q_asym+p);
tangent_covs{1,1}=diag([0.10 0.40 0.40]);

%Independent rotation and scaling components, dependent scaling components (weak correlation).
rotation_log_sd=0.10;
scale_log_sd=[0.40 0.40];
scale_log_corr_weak=[1 0.15; 0.15 1];
tangent_corr1=[1 zeros(1,2); zeros(2,1) scale_log_corr_weak];
tangent_covs{2,1}=diag([rotation_log_sd scale_log_sd])*tangent_corr1*diag([rotation_log_sd scale_log_sd]);

%Independent rotation and scaling components, dependent scaling components (strong correlation).
rotation_log_sd=0.10;
scale_log_sd=[0.40 0.40];
scale_log_corr_strong=[1 0.75; 0.75 1];
tangent_corr1=[1 zeros(1,2); zeros(2,1) scale_log_corr_strong];
tangent_covs{3,1}=diag([rotation_log_sd scale_log_sd])*tangent_corr1*diag([rotation_log_sd scale_log_sd]);

%Allow for dependence between rotation and scaling components (weak correlation) and dependence among scaling components (weak correlation).
scale_rot_cross_corr_weak=[0.10 0.10];
tangent_corr2=[1 scale_rot_cross_corr_weak; scale_rot_cross_corr_weak' scale_log_corr_weak];
tangent_covs{4,1}=diag([rotation_log_sd scale_log_sd])*tangent_corr2*diag([rotation_log_sd scale_log_sd]);

%Allow for dependence between rotation and scaling components (strong correlation) and dependence among scaling components (strong correlation).
scale_rot_cross_corr_strong=[0.70 0.70];
tangent_corr3=[1 scale_rot_cross_corr_strong; scale_rot_cross_corr_strong' scale_log_corr_strong];
tangent_covs{5,1}=diag([rotation_log_sd scale_log_sd])*tangent_corr3*diag([rotation_log_sd scale_log_sd]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
euclidean_means=cell(num_sim,length(n),length(tangent_covs));
euclidean_mean_times=cell(num_sim,length(n),length(tangent_covs));
log_euclidean_means=cell(num_sim,length(n),length(tangent_covs));
log_euclidean_mean_times=cell(num_sim,length(n),length(tangent_covs));
AI_means=cell(num_sim,length(n),length(tangent_covs));
AI_mean_times=cell(num_sim,length(n),length(tangent_covs));
procrustes_means=cell(num_sim,length(n),length(tangent_covs));
procrustes_mean_times=cell(num_sim,length(n),length(tangent_covs));
MSR_means=cell(num_sim,length(n),length(tangent_covs));
MSR_mean_times=cell(num_sim,length(n),length(tangent_covs));

step=0;
rng(124)
for j=1:length(n)
    for cov_type=1:length(tangent_covs)
        for iter=1:num_sim
            step=step+1;
            disp(step);
            %Create random sample of SPD matrices.
            sample_mats=cell(n(j),1);
            tangent_coords=mvnrnd(zeros(1,q_asym+p),tangent_covs{cov_type,1},n(j));

            rotation_mats=cell(n(j),1);
            rotation_coords=zeros(n(j),q_asym);
            for i=1:n(j)
                rotation_coords(i,:)=tangent_coords(i,1:q_asym);
            end

            scale_mats=cell(n(j),1);
            scale_coords=zeros(n(j),p);
            for i=1:n(j)
                scale_coords(i,:)=tangent_coords(i,q_asym+1:q_asym+p)+diag(logm(Sigma_evals))';
            end

            for k=1:n(j)
                rotation_mats{k}=zeros(p,p);
                coord=0;
                for b=1:p
                    for a=b+1:p
                        rotation_mats{k}(a,b)=rotation_coords(k,q_asym-coord)*(-1)^(q_asym-coord+1);
                        coord=coord+1;
                    end
                end
                rotation_mats{k}=rotation_mats{k}-rotation_mats{k}';
                rotation_mats{k}=expm(rotation_mats{k})*Sigma_evecs;
                    
                scale_mats{k}=expm(diag(scale_coords(k,:)));
                    
                sample_mats{k}=rotation_mats{k}*scale_mats{k}*rotation_mats{k}';
            end
            %Compute Euclidean mean of sample.
            euclidean_means{iter,j,cov_type}=zeros(p,p);
            tic
            for obs=1:n(j)
                euclidean_means{iter,j,cov_type}=euclidean_means{iter,j,cov_type}+(1/n(j))*sample_mats{obs};
            end
            euclidean_mean_times{iter,j,cov_type}=toc;
            %Compute Log-Euclidean mean of sample.
            log_euclidean_means{iter,j,cov_type}=zeros(p,p);
            tic
            for obs=1:n(j)
                log_euclidean_means{iter,j,cov_type}=log_euclidean_means{iter,j,cov_type}+(1/n(j))*logm(sample_mats{obs});
            end
            log_euclidean_means{iter,j,cov_type}=expm(log_euclidean_means{iter,j,cov_type});
            log_euclidean_mean_times{iter,j,cov_type}=toc;
            %Compute Affine-invariant mean of sample.
            tic
            AI_means{iter,j,cov_type}=AImean(sample_mats,log_euclidean_means{iter,j,cov_type});
            AI_mean_times{iter,j,cov_type}=toc;
            %Compute Procrustes Size and Shape means.
            tic
            procrustes_means{iter,j,cov_type}=procrustesSS_mean(sample_mats);
            procrustes_mean_times{iter,j,cov_type}=toc;
            %Compute MSR means.
            tic
            MSR_means{iter,j,cov_type}=minscrot_mean(sample_mats,procrustes_means{iter,j,cov_type});
            MSR_mean_times{iter,j,cov_type}=toc;
        end
    end
end

save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\euclidean_means_sim2','euclidean_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\log_euclidean_means_sim2','log_euclidean_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\AI_means_sim2','AI_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\MSR_means_sim2','MSR_means')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\procrustes_means_sim2','procrustes_means')

save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\euclidean_mean_times_sim2','euclidean_mean_times')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\log_euclidean_mean_times_sim2','log_euclidean_mean_times')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\AI_mean_times_sim2','AI_mean_times')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\MSR_mean_times_sim2','MSR_mean_times')
save('C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\procrustes_mean_times_sim2','procrustes_mean_times')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('euclidean_means_sim2')
load('log_euclidean_means_sim2')
load('AI_means_sim2')
load('MSR_means_sim2')
load('procrustes_means_sim2')

load('euclidean_mean_times_sim2')
load('log_euclidean_mean_times_sim2')
load('AI_mean_times_sim2')
load('MSR_mean_times_sim2')
load('procrustes_mean_times_sim2')

%Compute MSE for each type of estimator.
%1st dim = type of MSE, 2nd dim = sample size, 3rd dim = covariance type
euclidean_means_MSEs=zeros(4,length(n),length(tangent_covs));
log_euclidean_means_MSEs=zeros(4,length(n),length(tangent_covs));
AI_means_MSEs=zeros(4,length(n),length(tangent_covs));
procrustes_means_MSEs=zeros(4,length(n),length(tangent_covs));
MSR_means_MSEs=zeros(4,length(n),length(tangent_covs));

for cov_type=1:length(tangent_covs)
    for i=1:4
        for j=1:length(n)
            for k=1:num_sim
                if i==1 %Euclidean MSE%
                    euclidean_means_MSEs(i,j,cov_type)=euclidean_means_MSEs(i,j,cov_type)+trace((euclidean_means{k,j,cov_type}-Sigma)'*(euclidean_means{k,j,cov_type}-Sigma))/num_sim;
                    log_euclidean_means_MSEs(i,j,cov_type)=log_euclidean_means_MSEs(i,j,cov_type)+trace((log_euclidean_means{k,j,cov_type}-Sigma)'*(log_euclidean_means{k,j,cov_type}-Sigma))/num_sim;
                    AI_means_MSEs(i,j,cov_type)=AI_means_MSEs(i,j,cov_type)+trace((AI_means{k,j,cov_type}-Sigma)'*(AI_means{k,j,cov_type}-Sigma))/num_sim;
                    procrustes_means_MSEs(i,j,cov_type)=procrustes_means_MSEs(i,j,cov_type)+trace((procrustes_means{k,j,cov_type}-Sigma)'*(procrustes_means{k,j,cov_type}-Sigma))/num_sim;
                    MSR_means_MSEs(i,j,cov_type)=MSR_means_MSEs(i,j,cov_type)+trace((MSR_means{k,j,cov_type}-Sigma)'*(MSR_means{k,j,cov_type}-Sigma))/num_sim;
                elseif i==2 %Log-Euclidean MSE%
                    euclidean_means_MSEs(i,j,cov_type)=euclidean_means_MSEs(i,j,cov_type)+trace((logm(euclidean_means{k,j,cov_type})-logm(Sigma))'*(logm(euclidean_means{k,j,cov_type})-logm(Sigma)))/num_sim;
                    log_euclidean_means_MSEs(i,j,cov_type)=log_euclidean_means_MSEs(i,j,cov_type)+trace((logm(log_euclidean_means{k,j,cov_type})-logm(Sigma))'*(logm(log_euclidean_means{k,j,cov_type})-logm(Sigma)))/num_sim;
                    AI_means_MSEs(i,j,cov_type)=AI_means_MSEs(i,j,cov_type)+trace((logm(AI_means{k,j,cov_type})-logm(Sigma))'*(logm(AI_means{k,j,cov_type})-logm(Sigma)))/num_sim;
                    procrustes_means_MSEs(i,j,cov_type)=procrustes_means_MSEs(i,j,cov_type)+trace((logm(procrustes_means{k,j,cov_type})-logm(Sigma))'*(logm(procrustes_means{k,j,cov_type})-logm(Sigma)))/num_sim;
                    MSR_means_MSEs(i,j,cov_type)=MSR_means_MSEs(i,j,cov_type)+trace((logm(MSR_means{k,j,cov_type})-logm(Sigma))'*(logm(MSR_means{k,j,cov_type})-logm(Sigma)))/num_sim;
                elseif i==3 %MSR MSE%
                    euclidean_means_MSEs(i,j,cov_type)=euclidean_means_MSEs(i,j,cov_type)+(min_scale_rot_dist(euclidean_means{k,j,cov_type},Sigma,1))^2/num_sim;
                    log_euclidean_means_MSEs(i,j,cov_type)=log_euclidean_means_MSEs(i,j,cov_type)+(min_scale_rot_dist(log_euclidean_means{k,j,cov_type},Sigma,1))^2/num_sim;
                    AI_means_MSEs(i,j,cov_type)=AI_means_MSEs(i,j,cov_type)+(min_scale_rot_dist(AI_means{k,j,cov_type},Sigma,1))^2/num_sim;
                    procrustes_means_MSEs(i,j,cov_type)=procrustes_means_MSEs(i,j,cov_type)+(min_scale_rot_dist(procrustes_means{k,j,cov_type},Sigma,1))^2/num_sim;
                    MSR_means_MSEs(i,j,cov_type)=MSR_means_MSEs(i,j,cov_type)+(min_scale_rot_dist(MSR_means{k,j,cov_type},Sigma,1))^2/num_sim;
                else %Procrustes SS MSE%
                    euclidean_means_MSEs(i,j,cov_type)=euclidean_means_MSEs(i,j,cov_type)+(procrustesSS_dist(euclidean_means{k,j,cov_type},Sigma))^2/num_sim;
                    log_euclidean_means_MSEs(i,j,cov_type)=log_euclidean_means_MSEs(i,j,cov_type)+(procrustesSS_dist(log_euclidean_means{k,j,cov_type},Sigma))^2/num_sim;
                    AI_means_MSEs(i,j,cov_type)=AI_means_MSEs(i,j,cov_type)+(procrustesSS_dist(AI_means{k,j,cov_type},Sigma))^2/num_sim;
                    procrustes_means_MSEs(i,j,cov_type)=procrustes_means_MSEs(i,j,cov_type)+(procrustesSS_dist(procrustes_means{k,j,cov_type},Sigma))^2/num_sim;
                    MSR_means_MSEs(i,j,cov_type)=MSR_means_MSEs(i,j,cov_type)+(procrustesSS_dist(MSR_means{k,j,cov_type},Sigma))^2/num_sim;
                end
            end
        end
    end
end



