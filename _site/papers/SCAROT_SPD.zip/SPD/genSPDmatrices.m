function Array = genSPDmatrices(p,n);
% GENSPDMATRICES A simple function to generate Symmetric Positive Definite
% (SPD) matrices of dimension p x p. 
% Array = genSPDmatrices(p,n) gives an p x p x n array of "n" SPD matrices.
% 
% Sungkyu Jung. 8/8/2012.

% p = 3;
% n = 10;

D = eye(p); % this is the mean of the data
B = D^(1/2);
% In T_D Sym+, simple compound symmetry covariance
sigma = 1;
b = 5;
d = (p^2-p) /2 + p;
Sigma = sigma * (ones(d) + b*eye(d));


%% First realization 
Y = Sigma^(1/2)*randn(d,n);
% in Sym+
Array = zeros(p,p,n);
Ymat = matd(Y,1);
for i=1:n
    Yi = Ymat(:,:,i);
    Ct = B* expm( B^(-1)*Yi*B'^(-1))*B' ;
    Array(:,:,i) = Ct;
end

end

function Array = matd(vecArray,option)
% inputs
%  Array: array of p x p pd matrices, with length n, Array = p x p x n;
%  option 0 or 1 (0 for multiplying \sqrt(2), 1 for not)
% output vectorized version : put diagonal first, then off-diagonal

if nargin == 1;
    option = 0;
end
if option == 0;
    tau = 1/sqrt(2);
else
    tau = 1;
end

sizeArray = size(vecArray);
p = (sqrt(sizeArray(1)*8+1) - 1) / 2;

for k = 1:sizeArray(2)
    Array(:,:,k) = diag(vecArray(1:p,k));
    ind = p+1;
    for i = 1:p-1
        for j = i+1:p
            Array(i,j,k) =  tau*vecArray(ind,k);
            Array(j,i,k) =  tau*vecArray(ind,k);
            ind = ind+1;
        end
    end
end

end