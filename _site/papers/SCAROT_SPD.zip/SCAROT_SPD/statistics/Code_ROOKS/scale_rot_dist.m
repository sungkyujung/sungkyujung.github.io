function output=scale_rot_dist(U1,D1,U2,D2,k)
%Scaling-rotation distance defined on Diag-plus(p)xSO(p).  D1 and D2 should
%be diagonal matrices with positive diagonal entries and U1 and U2 should
%be rotation matrices.
output=sqrt((diagplus_dist(D2,D1))^2+k*(rot_dist(U2,U1))^2);
end