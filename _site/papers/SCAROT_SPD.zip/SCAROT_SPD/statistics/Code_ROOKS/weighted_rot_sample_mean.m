function output=weighted_rot_sample_mean(sample,weights,initial_mean)
%Gradient descent algorithm for computing the weighted sample intrinsic
%mean of a sample of rotation matrices using the canonical Riemannian
%geodesic distance for rotation matrices.

%Input sample should be an nx1 cell of rotation matrices.%
n=length(sample);
%ind=randi(n);
new_mean=initial_mean;
p=length(initial_mean);

tol=10^-10;
norm=1;
tau=1;
while norm>tol
    norm_old=norm;
    A=zeros(p,p);
    initial_mean=new_mean;
    for i=1:n
        A=A+weights(i)*rotlogm(sample{i}*initial_mean');
    end
    new_mean=expm(tau*A)*initial_mean;
    norm=sqrt(trace(A*A'));
    if norm>norm_old
        tau=tau/2;
    end
end
output=new_mean;
end