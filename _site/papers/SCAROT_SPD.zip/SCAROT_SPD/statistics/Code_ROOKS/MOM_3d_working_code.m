mu=[3;3;1];
sigma=1;

alpha_1=ones(3,1)'*mu/3;
alpha_2=sigma^2+mu'*mu/3;
alpha_3=(mu(1)*mu(2)+mu(1)*mu(3)+mu(2)*mu(3))/3;
alpha_4=mu(1)*mu(2)*mu(3);

check_sigma_sq=alpha_2-(3*alpha_1^2-2*alpha_3);

%It appears that a_0 is always between -1 and 1.
a_0=-(alpha_4-alpha_1^3+3*alpha_1*(alpha_1^2-alpha_3))/(2*(alpha_1^2-alpha_3)^(3/2));

%Properties of a_0:
%a_0 only equals 1 or -1 when two of the elements of mu are equal.

%a_0=1;
B=zeros(6,6);
B(6,1)=1;
B(1,2)=1;
B(2,3)=1;
B(3,4)=1;
B(4,5)=1;
B(5,6)=1;
B(6,4)=-2*a_0*1i;

D=eig(B)

D(1)'*D(1)
D(2)'*D(2)
D(3)'*D(3)
D(4)'*D(4)
D(5)'*D(5)
D(6)'*D(6)

%Compute angles.
angles=angle(D)

%Plot angles with sin(3x) curve.
theta=linspace(-pi,pi,10000);
curve=sin(3*theta);
plot(theta,curve,'r')
refline(0,-a_0)
hold on
scatter(angles,sin(3*angles),'k')

%Compute c1 and c2%
ind=1;
c1=sqrt(3*(alpha_1^2-alpha_3))*(cos(angles(ind))+sin(angles(ind))/sqrt(3));
c2=sqrt(3*(alpha_1^2-alpha_3))*(-cos(angles(ind))+sin(angles(ind))/sqrt(3));

mu1_check=alpha_1+c1
mu2_check=alpha_1+c2
mu3_check=alpha_1-(c1+c2)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mu=[1;2;4];
sigma=1;
p=3;
cov=sigma^2*eye(3)+(mu'*(eye(p)-(1/p)*ones(p,1)*ones(p,1)')*mu/(p-1))*(eye(p)-(1/p)*ones(p,1)*ones(p,1)');

A=(eye(p)-(1/p)*ones(p,1)*ones(p,1)');
[U_A,D_A]=eig(A);

alpha1=ones(p,1)'*mu/p;

theta=linspace(-pi,pi,10000)';
alpha_dists=zeros(length(theta),1);
test_mu=zeros(length(theta),p);
test_mu_prod=zeros(length(theta),1);

r=sqrt(trace(cov)-p*min(eig(cov)));

for i=1:length(theta)
    test_mu(i,1)=alpha1+(r/sqrt(6))*(sqrt(3)*cos(theta(i))+sin(theta(i)));
    test_mu(i,2)=alpha1+(r/sqrt(6))*(-sqrt(3)*cos(theta(i))+sin(theta(i)));
    test_mu(i,3)=alpha1-2*r*sin(theta(i))/sqrt(6);
    
    test_mu_prod(i)=test_mu(i,1)*test_mu(i,2)*test_mu(i,3);
    %alpha_dists(i)=sqrt((test_mu(i,:)-alpha1*ones(1,p))*(test_mu(i,:)-alpha1*ones(1,p))');
end

alpha3=mu(1)*mu(2)*mu(3);

a_0=-3*sqrt(6)*(alpha3-alpha1*(alpha1^2-r^2/2))/r^3;

B=zeros(6,6);
B(6,1)=1;
B(1,2)=1;
B(2,3)=1;
B(3,4)=1;
B(4,5)=1;
B(5,6)=1;
B(6,4)=-2*a_0*1i;

D=eig(B)

D(1)'*D(1)
D(2)'*D(2)
D(3)'*D(3)
D(4)'*D(4)
D(5)'*D(5)
D(6)'*D(6)

%Compute angles.
angles=angle(D)

%Plot angles with sin(3x) curve.
theta=linspace(-pi,pi,10000);
curve=sin(3*theta);
plot(theta,curve,'r')
refline(0,-a_0)
hold on
scatter(angles,sin(3*angles),'k')

%Compute c1 and c2.
ind=1;
c1=(r/sqrt(6))*(sqrt(3)*cos(angles(ind))+sin(angles(ind)));
c2=(r/sqrt(6))*(-sqrt(3)*cos(angles(ind))+sin(angles(ind)));

mu1_check=alpha1+c1
mu2_check=alpha1+c2
mu3_check=alpha1-(c1+c2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



