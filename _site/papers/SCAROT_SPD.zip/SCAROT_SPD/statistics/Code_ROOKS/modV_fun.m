function output=modV_fun(input,K)
%Calculates the intrinsic variance of geodesic normal random variable with
%concentration parameter equal to "input" and scalar parameter K.
N_2=erf(pi*sqrt(K*input/2))/sqrt(K*input);
output=(N_2-sqrt(2/pi)*exp(-pi^2*K*input/2))/(input*N_2);
end