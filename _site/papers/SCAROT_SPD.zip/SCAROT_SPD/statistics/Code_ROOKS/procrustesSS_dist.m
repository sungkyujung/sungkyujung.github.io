function output=procrustesSS_dist(X,Y)
%Computes the Procrustes Size and Shape distance between two SPD matrices X
%and Y.
rootX=chol(X)';
rootY=chol(Y)';
[W,~,U]=svd(rootX*rootY');
R=U*W';
output=sqrt(trace((rootX-rootY*R)'*(rootX-rootY*R)));
end