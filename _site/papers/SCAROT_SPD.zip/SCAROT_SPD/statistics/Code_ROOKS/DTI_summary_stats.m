%%Computation of DTI summary statistics using different SPD frameworks.
t=linspace(0,1,200);
%X=diag([15 2 1]);
%Y=rot3Dmat(pi/4,[0;1;0])*diag([100 2 1])*rot3Dmat(pi/4,[0;1;0])'; %Scaling and rotation%
%Y=rot3Dmat(pi/4,[0;1;0])*diag([15 2 1])*rot3Dmat(pi/4,[0;1;0])'; %Pure rotation%
%Y=diag([100 2 1]); %Pure scaling%

%Example with smooth deformation from anisotropic diffusion tensor to
%isotropic diffusion tensor.
%X=rot3Dmat(pi/4,[0;1;0])*diag([16 4 1])*rot3Dmat(pi/4,[0;1;0])';
%Y=4*eye(3);

%Example showing the Cholesky framework's lack of invariance to change of
%coordinate system.
X=rot3Dmat(pi/2,[0;1;0])*diag([15 2 1])*rot3Dmat(pi/2,[0;1;0])';
Y=rot3Dmat(pi/4,[0;1;0])*rot3Dmat(pi/2,[0;1;0])*diag([15 2 1])*rot3Dmat(pi/2,[0;1;0])'*rot3Dmat(pi/4,[0;1;0])';

%Compute interpolation curves between X and Y under different geometric
%frameworks for SPD matrices.
Inter_E=cell(length(t),1);
Inter_L=cell(length(t),1);
Inter_AI=cell(length(t),1);
Inter_chol=cell(length(t),1);
Inter_H=cell(length(t),1);
Inter_S=cell(length(t),1);
Inter_SR=cell(length(t),1);

sqrtX=X^0.5;

chol_rootX = chol(X)';
chol_rootY = chol(Y)';

[evecsX,evalsX]=eig(X);
[evecsY,evalsY]=eig(Y);
SPD_rootX=evecsX*(evalsX^0.5)*evecsX';
SPD_rootY=evecsY*(evalsY^0.5)*evecsY';

rootX=chol(X)';
rootY=chol(Y)';
[W,Lambda,U]=svd(rootX'*rootY);
R_hat=U*W';

[Ux,Dx,Uy,Dy]=min_eigen_pair(X,Y);

%Principal axis of X%
[prinaxisX,~]=eigs(X,1);

for i=1:length(t)
    %Euclidean framework interpolation
    Inter_E{i,1}=(1-t(i))*X+t(i)*Y;
    %Log-Euclidean framework interpolation
    Inter_L{i,1}=expm((1-t(i))*logm(X)+t(i)*logm(Y));
    %Affine-invariant framework interpolation
    Inter_AI{i,1}=sqrtX*expm(t(i)*logm(sqrtX\Y/sqrtX))*sqrtX;
    %Cholesky framework interpolation
    Inter_chol{i,1}=(chol_rootX+t(i)*(chol_rootY-chol_rootX))*(chol_rootX+t(i)*(chol_rootY-chol_rootX))';
    %Euclidean-Root framework interpolation
    Inter_H{i,1}=(SPD_rootX+t(i)*(SPD_rootY-SPD_rootX))^2;
    %Procrustes Size and Shape framework interpolation
    Inter_S{i,1}=(rootX+t(i)*(rootY*R_hat-rootX))*(rootX+t(i)*(rootY*R_hat-rootX))';
    %Scaling-rotation framework interpolation
    Inter_SR{i,1}=(expm(logm(Uy*Ux')*t(i))*Ux)*(expm(logm(Dy/Dx)*t(i))*Dx)*(expm(logm(Uy*Ux')*t(i))*Ux)';
end

%%DTI summary statistics calculations
MD_E=zeros(length(t),1);
log_det_E=zeros(length(t),1);
FA_E=zeros(length(t),1);
PA_E=zeros(length(t),1);
rot_angle_E=zeros(length(t),1);

MD_L=zeros(length(t),1);
log_det_L=zeros(length(t),1);
FA_L=zeros(length(t),1);
PA_L=zeros(length(t),1);
rot_angle_L=zeros(length(t),1);

MD_AI=zeros(length(t),1);
log_det_AI=zeros(length(t),1);
FA_AI=zeros(length(t),1);
PA_AI=zeros(length(t),1);
rot_angle_AI=zeros(length(t),1);

MD_chol=zeros(length(t),1);
log_det_chol=zeros(length(t),1);
FA_chol=zeros(length(t),1);
PA_chol=zeros(length(t),1);
rot_angle_chol=zeros(length(t),1);

MD_H=zeros(length(t),1);
log_det_H=zeros(length(t),1);
FA_H=zeros(length(t),1);
PA_H=zeros(length(t),1);
rot_angle_H=zeros(length(t),1);

MD_S=zeros(length(t),1);
log_det_S=zeros(length(t),1);
FA_S=zeros(length(t),1);
PA_S=zeros(length(t),1);
rot_angle_S=zeros(length(t),1);

MD_SR=zeros(length(t),1);
log_det_SR=zeros(length(t),1);
FA_SR=zeros(length(t),1);
PA_SR=zeros(length(t),1);
rot_angle_SR=zeros(length(t),1);

for i=1:length(t)
    %Euclidean framework
    MD_E(i)=((1-t(i))*trace(X)+t(i)*trace(Y))/3;
    log_det_E(i)=log(det(Inter_E{i,1}));
    R=Inter_E{i,1}/trace(Inter_E{i,1});
    FA_E(i)=sqrt((3-1/trace(R^2))/2);
    R_sq=Inter_E{i,1}^0.5/trace(Inter_E{i,1}^0.5);
    PA_E(i)=sqrt((3-1/trace(R_sq^2))/2);
    [int_prinaxis_E,~]=eigs(Inter_E{i,1},1);
    rot_angle_E(i)=(180/pi)*acos(abs(int_prinaxis_E'*prinaxisX));
    
    %Log-Euclidean framework
    MD_L(i)=trace(Inter_L{i,1})/3;
    log_det_L(i)=log(det(Inter_L{i,1}));
    R=Inter_L{i,1}/trace(Inter_L{i,1});
    FA_L(i)=sqrt((3-1/trace(R^2))/2);
    R_sq=Inter_L{i,1}^0.5/trace(Inter_L{i,1}^0.5);
    PA_L(i)=sqrt((3-1/trace(R_sq^2))/2);
    [int_prinaxis_L,~]=eigs(Inter_L{i,1},1);
    rot_angle_L(i)=(180/pi)*acos(abs(int_prinaxis_L'*prinaxisX));
    
    %Affine-invariant Riemannian framework
    MD_AI(i)=trace(Inter_AI{i,1})/3;
    log_det_AI(i)=log(det(Inter_AI{i,1}));
    R=Inter_AI{i,1}/trace(Inter_AI{i,1});
    FA_AI(i)=sqrt((3-1/trace(R^2))/2);
    R_sq=Inter_AI{i,1}^0.5/trace(Inter_AI{i,1}^0.5);
    PA_AI(i)=sqrt((3-1/trace(R_sq^2))/2);
    [int_prinaxis_AI,~]=eigs(Inter_AI{i,1},1);
    rot_angle_AI(i)=(180/pi)*acos(abs(int_prinaxis_AI'*prinaxisX));
    
    %Cholesky framework
    MD_chol(i)=trace(Inter_chol{i,1})/3;
    log_det_chol(i)=log(det(Inter_chol{i,1}));
    R=Inter_chol{i,1}/trace(Inter_chol{i,1});
    FA_chol(i)=sqrt((3-1/trace(R^2))/2);
    R_sq=Inter_chol{i,1}^0.5/trace(Inter_chol{i,1}^0.5);
    PA_chol(i)=sqrt((3-1/trace(R_sq^2))/2);
    [int_prinaxis_chol,~]=eigs(Inter_chol{i,1},1);
    rot_angle_chol(i)=(180/pi)*acos(abs(int_prinaxis_chol'*prinaxisX));
    
    %Euclidean-root framework
    MD_H(i)=trace(Inter_H{i,1})/3;
    log_det_H(i)=log(det(Inter_H{i,1}));
    R=Inter_H{i,1}/trace(Inter_H{i,1});
    FA_H(i)=sqrt((3-1/trace(R^2))/2);
    R_sq=Inter_H{i,1}^0.5/trace(Inter_H{i,1}^0.5);
    PA_H(i)=sqrt((3-1/trace(R_sq^2))/2);
    [int_prinaxis_H,~]=eigs(Inter_H{i,1},1);
    rot_angle_H(i)=(180/pi)*acos(abs(int_prinaxis_H'*prinaxisX));
    
    %Procrustes Size and Shape framework
    MD_S(i)=trace(Inter_S{i,1})/3;
    log_det_S(i)=log(det(Inter_S{i,1}));
    R=Inter_S{i,1}/trace(Inter_S{i,1});
    FA_S(i)=sqrt((3-1/trace(R^2))/2);
    R_sq=Inter_S{i,1}^0.5/trace(Inter_S{i,1}^0.5);
    PA_S(i)=sqrt((3-1/trace(R_sq^2))/2);
    [int_prinaxis_S,~]=eigs(Inter_S{i,1},1);
    rot_angle_S(i)=(180/pi)*acos(abs(int_prinaxis_S'*prinaxisX));
    
    %Scaling-Rotation framework
    MD_SR(i)=trace(Inter_SR{i,1})/3;
    log_det_SR(i)=log(det(Inter_SR{i,1}));
    R=Inter_SR{i,1}/trace(Inter_SR{i,1});
    FA_SR(i)=sqrt((3-1/trace(R^2))/2);
    %[int_prinaxis_SR,~]=eigs(Inter_SR{i,1},1);
    %rot_angle_SR(i)=acos(abs(int_prinaxis_SR'*prinaxisX));
    R_sq=Inter_SR{i,1}^0.5/trace(Inter_SR{i,1}^0.5);
    PA_SR(i)=sqrt((3-1/trace(R_sq^2))/2);
    rot_angle_SR(i)=(180/pi)*t(i)*rot_dist(Ux,Uy);
end

%rot_angle_chol(200,1)=rot_angle_chol(199,1)+rot_angle_chol(199,1)-rot_angle_chol(198,1);

figure
subplot(2,3,2)
%Plots of Mean Diffusivity
plot(t,MD_SR,'red')
hold on
plot(t,MD_E,'blue')
hold on
plot(t,MD_L,'black','LineStyle','--')
hold on
plot(t,MD_AI,'black','LineStyle',':')
hold on
plot(t,MD_chol,'cyan')
hold on 
plot(t,MD_H,'Color',[1 0 1])
hold on
plot(t,MD_S,'Color',[0 100/255 0])
xlabel('t')
ylabel('MD')
%legend('Scaling-Rotation','Euclidean','Log-Euclidean','Affine-Invariant','Cholesky','Euclidean Root','Procrustes','Location','northwest')

subplot(2,3,3)
%Plots of Log-determinant
plot(t,log_det_SR,'red')
hold on
plot(t,log_det_E,'blue')
hold on
plot(t,log_det_L,'black','LineStyle','--')
hold on
plot(t,log_det_AI,'black','LineStyle',':')
hold on
plot(t,log_det_chol,'cyan')
hold on 
plot(t,log_det_H,'Color',[1 0 1])
hold on
plot(t,log_det_S,'Color',[0 100/255 0])
xlabel('t')
ylabel('Log Determinant')

subplot(2,3,4)
%Plots of Procrustes anisotropy
plot(t,PA_SR,'red')
hold on
plot(t,PA_E,'blue')
hold on
plot(t,PA_L,'black','LineStyle','--')
hold on
plot(t,PA_AI,'black','LineStyle',':')
hold on
plot(t,PA_chol,'cyan')
hold on 
plot(t,PA_H,'Color',[1 0 1])
hold on
plot(t,PA_S,'Color',[0 100/255 0])
xlabel('t')
ylabel('PA')

subplot(2,3,5)
%Plots of fractional anisotropy
plot(t,FA_SR,'red')
hold on
plot(t,FA_E,'blue')
hold on
plot(t,FA_L,'black','LineStyle','--')
hold on
plot(t,FA_AI,'black','LineStyle',':')
hold on
plot(t,FA_chol,'cyan')
hold on 
plot(t,FA_H,'Color',[1 0 1])
hold on
plot(t,FA_S,'Color',[0 100/255 0])
xlabel('t')
ylabel('FA')

subplot(2,3,6)
%Plots of rotation angle.
plot(t,rot_angle_SR,'red')
hold on
plot(t,rot_angle_E,'blue')
hold on
plot(t,rot_angle_L,'black','LineStyle','--')
hold on
plot(t,rot_angle_AI,'black','LineStyle',':')
hold on
plot(t,rot_angle_chol,'cyan')
hold on
plot(t,rot_angle_H,'Color',[1 0 1])
hold on
plot(t,rot_angle_S,'Color',[0 100/255 0])
xlabel('t')
ylabel('Rotation Angle')

subplot(2,3,1)
h1=plot(t,rot_angle_SR,'red');
set(h1,'Visible','Off')
hold on
h2=plot(t,rot_angle_E,'blue');
set(h2,'Visible','Off')
hold on
h3=plot(t,rot_angle_L,'black','LineStyle','--');
set(h3,'Visible','Off')
hold on
h4=plot(t,rot_angle_AI,'black','LineStyle',':');
set(h4,'Visible','Off')
hold on
h5=plot(t,rot_angle_chol,'cyan');
set(h5,'Visible','Off')
hold on
h6=plot(t,rot_angle_H,'Color',[1 0 1]);
set(h6,'Visible','Off')
hold on
h7=plot(t,rot_angle_S,'Color',[0 100/255 0]);
set(h7,'Visible','Off')
axis off
legend('Scaling-Rotation','Euclidean','Log-Euclidean','Affine-Invariant','Cholesky','Root Euclidean','Procrustes','Location','east')

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
%print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\DTImeasures1.pdf') %Scaling and rotation%
%print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\DTImeasures2.pdf') %Pure rotation%
%print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\DTImeasures3.pdf') %Pure scaling%
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\DTImeasures4.pdf') %Anisotropic to isotropic%