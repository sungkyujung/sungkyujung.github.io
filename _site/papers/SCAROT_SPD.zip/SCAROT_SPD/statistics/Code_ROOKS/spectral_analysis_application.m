%Simulation of a bivariate AR(1) Process%
n=200;
noise=mvnrnd(zeros(1,2),0.1*eye(2),n+100)';
A=rot2Dmat(pi/4)*diag([0.75 0.20])*rot2Dmat(pi/4)';

ar_series=zeros(2,length(noise));
ar_series(:,1)=noise(:,1);

for i=2:length(noise)
    ar_series(:,i)=A*ar_series(:,i-1)+noise(:,i);
end

x=ar_series(:,101:length(noise));
t=linspace(1,n,n);

plot(t,x(1,:));
figure
plot(t,x(2,:));

%Compute discrete Fourier transform of time series X%
fourier_mat=zeros(n,n);
for k=1:n
    fourier_mat(k,:)=n^(-1/2)*exp(-2*pi*((k-1)/n)*t*1i);
end

d=fourier_mat*x';
%d2=zeros(2,n);
%d2(1,:)=n^(-1/2)*fft(x(1,:));
%d2(2,:)=n^(-1/2)*fft(x(2,:));

%Compute cell containing all periodograms%
Y=cell(n,1);
for j=1:n
    Y{j}=d(j,:)'*d(j,:);
end

power_spec1=zeros(1,n);
power_spec2=zeros(1,n);
for j=1:n
    power_spec1(j)=real(Y{j}(1,1));
    power_spec2(j)=real(Y{j}(2,2));
end

freq=(t-1)/n;

plot(freq,power_spec1)
figure
plot(freq,power_spec2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Perform a simple moving average on the periodograms%
maY=cell(n,1);
for j=2:n-1
    maY{j}=(Y{j-1}+Y{j}+Y{j+1})/3;
end

power_spec1=zeros(1,n-2);
power_spec2=zeros(1,n-2);
for j=2:n-2
    power_spec1(j)=real(maY{j}(1,1));
    power_spec2(j)=real(maY{j}(2,2));
end

freq=(t-1)/n;
freq=freq(2:n-1);

plot(freq,power_spec1)
figure
plot(freq,power_spec2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Perform smoothing on the moving average smoothed periodograms%



