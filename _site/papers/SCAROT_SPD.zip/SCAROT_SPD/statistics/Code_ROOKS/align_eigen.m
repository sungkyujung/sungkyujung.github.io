function [Ux,Dx]=align_eigen(X,D,U)
%Assuming that X is a pxp SPD matrix with no repeated eigenvalues, choose
%the eigen-decomposition of X that has minimal scaling-rotation distance
%from the point (D,U) on Diag-plus(p)xSO(p).
p=length(X);
Adj=eye(p);
Adj(p,p)=-1;

%Ensure that rotation matrix for X has determinant equal to 1.
[Ux_rep,Dx_rep]=eig(X);
if det(Ux_rep)<0
    Ux_rep=Ux_rep*Adj;
end

%Generate all eigen-decompositions of X.
all_perms=perm_mats(p);
all_sign_changes=sign_change_mats(p);
count=0;

eig_decompsX=cell(length(all_perms)*length(all_sign_changes),2);
for i=1:length(all_perms)
    for j=1:length(all_sign_changes)
        count=count+1;
        eig_decompsX{count,1}=Ux_rep*all_sign_changes{j,1}*all_perms{i,1}';
        eig_decompsX{count,2}=all_perms{i,1}*Dx_rep*all_perms{i,1}';
    end
end

%Compute all scaling rotation distances.
num_versions=factorial(p)*(2^(p-1));
dists=zeros(num_versions,1);
for i=1:num_versions
    dists(i)=scale_rot_dist(U,D,eig_decompsX{i,1},eig_decompsX{i,2},1);
end

[~,ind]=min(dists);
Ux=eig_decompsX{ind,1};
Dx=eig_decompsX{ind,2};
end



