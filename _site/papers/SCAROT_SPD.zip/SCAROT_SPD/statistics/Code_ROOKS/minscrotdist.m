function [output,minUx,minDx,minUy,minDy]=minscrotdist(X,Y,tolerance,k)
%Calculates the minimal scaling rotation distance between SPD matrices X
%and Y for dimensions 2 and 3.  Still need to add code for computing the
%minimal scaling rotation pair for the "non-trivial" cases mentioned in
%Groisser's 2016 paper.  The algorithm for computing minimal scaling
%rotation curves is given on pg. 54 of Groisser (2016).

%Pre-processing%
[nrowx,ncolx]=size(X);
[nrowy,ncoly]=size(Y);

if nrowx~=ncolx || nrowy~=ncoly
    disp('Input matrices must be square.');
    return;
end

if nrowx~=nrowy || ncolx~=ncoly
    disp('Input matrices must have the same dimensions.');
    return;
end

if nrowx>3
    disp('Only p=2 or p=3 is allowed.');
    return;
end

tol=1e-14;
if nargin > 2
    tol=tolerance;
end

K=1; 
if nargin > 3
    K=k;
end

%Obtain eigen-decompositions for X and Y.
[Ux,Dx]=eig(X);
if det(Ux)<0
    Ux(:,ncolx)=-1*Ux(:,ncolx);
end

[Uy,Dy]=eig(Y);
if det(Uy)<0
    Uy(:,ncoly)=-1*Uy(:,ncoly);
end

%Generate all permutation matrices.
all_perms=perm_mats(nrowx);
all_sign_changes=sign_change_mats(nrowx);

switch nrowx
    case 2
        %X and Y both have distinct eigenvalues.%
        if abs(Dx(1,1)-Dx(2,2))>tol && abs(Dy(1,1)-Dy(2,2))>tol
            count=0;
            %Generate all eigen-decompositions of Y.
            eig_decompsY=cell(length(all_perms)*length(all_sign_changes),2);
            for i=1:length(all_perms)
                for j=1:length(all_sign_changes)
                    count=count+1;
                    eig_decompsY{count,1}=Uy*all_sign_changes{j,1}*all_perms{i,1}';
                    eig_decompsY{count,2}=all_perms{i,1}*Dy*all_perms{i,1}';
                end
            end
            %Calculate distance between eigen-decomposition of X and all
            %eigen-decompositions of Y.
            num_versions=factorial(nrowx)*(2^(nrowx-1));
            XY_dists=zeros(num_versions,1);
            for i=1:num_versions
                XY_dists(i)=scale_rot_dist(Ux,Dx,eig_decompsY{i,1},eig_decompsY{i,2},K);
            end
            [output,ind]=min(XY_dists);
            minUx=Ux;
            minDx=Dx;
            minUy=eig_decompsY{ind,1};
            minDy=eig_decompsY{ind,2};
        %X has equal eigenvalues and Y does not.
        elseif abs(Dx(1,1)-Dx(2,2))<tol && abs(Dy(1,1)-Dy(2,2))>tol
            minUx=Uy;
            minDx=Dx;
            minUy=Uy;
            minDy=Dy;
            output=diagplus_dist(Dx,Dy);
        %Y has equal eigenvalues and X does not.    
        else
            minUx=Ux;
            minDx=Dx;
            minUy=Ux;
            minDy=Dy;
            output=diagplus_dist(Dx,Dy);
        end
    case 3
        maxevalx=max(diag(Dx));
        minevalx=min(diag(Dx));
        maxevaly=max(diag(Dy));
        minevaly=min(diag(Dy));
        %X and Y both have all distinct eigenvalues.%
        if abs(Dx(1,1)-Dx(2,2))>tol && abs(Dx(1,1)-Dx(3,3))>tol && abs(Dx(2,2)-Dx(3,3))>tol && abs(Dy(1,1)-Dy(2,2))>tol && abs(Dy(1,1)-Dy(3,3))>tol && abs(Dy(2,2)-Dy(3,3))>tol
            count=0;
            %Generate all eigen-decompositions of Y.
            eig_decompsY=cell(length(all_perms)*length(all_sign_changes),2);
            for i=1:length(all_perms)
                for j=1:length(all_sign_changes)
                    count=count+1;
                    eig_decompsY{count,1}=Uy*all_sign_changes{j,1}*all_perms{i,1}';
                    eig_decompsY{count,2}=all_perms{i,1}*Dy*all_perms{i,1}';
                end
            end
            %Calculate distance between eigen-decomposition of X and all
            %eigen-decompositions of Y.
            num_versions=factorial(nrowx)*(2^(nrowx-1));
            XY_dists=zeros(num_versions,1);
            for i=1:num_versions
                XY_dists(i)=scale_rot_dist(Ux,Dx,eig_decompsY{i,1},eig_decompsY{i,2},K);
            end
            [output,ind]=min(XY_dists);
            minUx=Ux;
            minDx=Dx;
            minUy=eig_decompsY{ind,1};
            minDy=eig_decompsY{ind,2};
        %X is isotropic and Y is not.%
        elseif abs(maxevalx-minevalx)<tol
            minUx=Uy;
            minDx=Dx;
            minUy=Uy;
            minDy=Dy;
            output=diagplus_dist(Dx,Dy);
        %Y is isotropic and X is not.%    
        elseif abs(maxevaly-minevaly)<tol
            minUx=Ux;
            minDx=Dx;
            minUy=Ux;
            minDy=Dy;
            output=diagplus_dist(Dx,Dy);
        %X only has two distinct eigenvalues and Y has three distinct eigenvalues: Case I%    
        elseif (abs(Dx(1,1)-Dx(2,2))<tol || abs(Dx(1,1)-Dx(3,3))<tol || abs(Dx(2,2)-Dx(3,3))<tol) && (abs(Dy(1,1)-Dy(2,2))>tol && abs(Dy(1,1)-Dy(3,3))>tol && abs(Dy(2,2)-Dy(3,3))>tol)
            Perm13=[0 0 -1; 0 1 0; 1 0 0];
            Perm12=[0 1 0; 1 0 0; 0 0 -1];
            if abs(Dx(1,1)-Dx(2,2))<tol
                Dx=Perm13*Dx*Perm13';
                Ux=Ux*Perm13';
            elseif abs(Dx(1,1)-Dx(3,3))<tol
                Dx=Perm12*Dx*Perm12';
                Ux=Ux*Perm12';
            end
            R=Ux'*Uy;
            %Check if R=Ux'Uy is an involution (i.e. check symmetry of R).%
            Rsymcheck=issymmetric(R);
            if Rsymcheck==1
                const=rot_dist(R,eye(3));
                comps=zeros(3,1);
                for i=1:3
                    comps(i)=rot_dist(R*all_sign_changes{i+1},eye(3))-const;
                end
                [~,ind]=min(comps);
                Uy=Uy*all_sign_changes{ind+1};
                R=R*all_sign_changes{ind+1};
            end
            %Compute angle and axis of rotation for Ux'Uy%
            theta=acos(0.5*(trace(R)-1));
            if theta==0
                axis=zeros(3,1);
            else
                axis=(1/(2*sin(theta)))*[R(3,2)-R(2,3); R(1,3)-R(3,1); R(2,1)-R(1,2)];
            end
            Rquat=[cos(theta/2) sin(theta/2)*axis'];
            z=complex(Rquat(1),Rquat(2));
            w=complex(Rquat(3),Rquat(4));
            phi=acos(max([sqrt(conj(z)*z) sqrt(conj(w)*w)]));
            beta=acos(sqrt((1+2*abs(real(conj(z)*w)))/2));
            beta_prime=acos(sqrt((1+2*abs(imag(conj(z)*w)))/2));
            
            l_id=sqrt(4*K*phi^2+(diagplus_dist(Dx,Dy))^2);
            l_13=sqrt(4*K*beta^2+(diagplus_dist(Dx,Perm13*Dy*Perm13'))^2);
            l_12=sqrt(4*K*beta_prime^2+(diagplus_dist(Dx,Perm12*Dy*Perm12'))^2);
            output=min([l_id l_13 l_12]);
            %Determine the minimal pair for X and Y for the
            %scaling-rotation curve.
            
        %X has three distinct eigenvalues and Y only has two distinct eigenvalues: Case II.%    
        elseif (abs(Dx(1,1)-Dx(2,2))>tol && abs(Dx(1,1)-Dx(3,3))>tol && (abs(Dx(2,2)-Dx(3,3))>tol) && (abs(Dy(1,1)-Dy(2,2))<tol || abs(Dy(1,1)-Dy(3,3))<tol || abs(Dy(2,2)-Dy(3,3))<tol))
            Perm13=[0 0 -1; 0 1 0; 1 0 0];
            Perm12=[0 1 0; 1 0 0; 0 0 -1];
            if abs(Dy(1,1)-Dy(2,2))<tol
                Dy=Perm13*Dy*Perm13';
                Uy=Uy*Perm13';
            elseif abs(Dy(1,1)-Dy(3,3))<tol
                Dy=Perm12*Dy*Perm12';
                Uy=Uy*Perm12';
            end
            R=Ux'*Uy;
            %Check if R=Ux'Uy is an involution (i.e. check symmetry of R).%
            Rsymcheck=issymmetric(R);
            if Rsymcheck==1
                const=rot_dist(R,eye(3));
                comps=zeros(3,1);
                for i=1:3
                    comps(i)=rot_dist(R*all_sign_changes{i+1},eye(3))-const;
                end
                [~,ind]=min(comps);
                Uy=Uy*all_sign_changes{ind+1};
                R=R*all_sign_changes{ind+1};
            end
            %Compute angle and axis of rotation for Ux'Uy%
            theta=acos(0.5*(trace(R)-1));
            if theta==0
                axis=zeros(3,1);
            else
                axis=(1/(2*sin(theta)))*[R(3,2)-R(2,3); R(1,3)-R(3,1); R(2,1)-R(1,2)];
            end
            Rquat=[cos(theta/2) sin(theta/2)*axis'];
            z=complex(Rquat(1),Rquat(2));
            w=complex(Rquat(3),Rquat(4));
            phi=acos(max([sqrt(conj(z)*z) sqrt(conj(w)*w)]));
            beta=acos(sqrt((1+2*abs(real(conj(z)*w)))/2));
            beta_prime=acos(sqrt((1+2*abs(imag(conj(z)*w)))/2));
            
            l_id=sqrt(4*K*phi^2+(diagplus_dist(Dy,Dx))^2);
            l_13=sqrt(4*K*beta^2+(diagplus_dist(Dy,Perm13*Dx*Perm13'))^2);
            l_12=sqrt(4*K*beta_prime^2+(diagplus_dist(Dy,Perm12*Dx*Perm12'))^2);
            output=min([l_id l_13 l_12]);
            %Determine the minimal pair for X and Y for the
            %scaling-rotation curve.
        
        %X and Y both have only two distinct eigenvalues.%    
        elseif (abs(Dx(1,1)-Dx(2,2))<tol || abs(Dx(1,1)-Dx(3,3))<tol || abs(Dx(2,2)-Dx(3,3))<tol) && (abs(Dy(1,1)-Dy(2,2))<tol || abs(Dy(1,1)-Dy(3,3))<tol || abs(Dy(2,2)-Dy(3,3))<tol)
            Perm13=[0 0 -1; 0 1 0; 1 0 0];
            Perm12=[0 1 0; 1 0 0; 0 0 -1];
            if abs(Dx(1,1)-Dx(2,2))<tol
                Dx=Perm13*Dx*Perm13';
                Ux=Ux*Perm13';
            elseif abs(Dx(1,1)-Dx(3,3))<tol
                Dx=Perm12*Dx*Perm12';
                Ux=Ux*Perm12';
            end
            if abs(Dy(1,1)-Dy(2,2))<tol
                Dy=Perm13*Dy*Perm13';
                Uy=Uy*Perm13';
            elseif abs(Dy(1,1)-Dy(3,3))<tol
                Dy=Perm12*Dy*Perm12';
                Uy=Uy*Perm12';
            end
            R=Ux'*Uy;
            %Check if R=Ux'Uy is an involution (i.e. check symmetry of R).%
            Rsymcheck=issymmetric(R);
            if Rsymcheck==1
                const=rot_dist(R,eye(3));
                comps=zeros(3,1);
                for i=1:3
                    comps(i)=rot_dist(R*all_sign_changes{i+1},eye(3))-const;
                end
                [~,ind]=min(comps);
                Uy=Uy*all_sign_changes{ind+1};
                R=R*all_sign_changes{ind+1};
            end
            %Compute angle and axis of rotation for Ux'Uy%
            theta=acos(0.5*(trace(R)-1));
            if theta==0
                axis=zeros(3,1);
            else
                axis=(1/(2*sin(theta)))*[R(3,2)-R(2,3); R(1,3)-R(3,1); R(2,1)-R(1,2)];
            end
            Rquat=[cos(theta/2) sin(theta/2)*axis'];
            z=complex(Rquat(1),Rquat(2));
            w=complex(Rquat(3),Rquat(4));
            phi=acos(max([sqrt(conj(z)*z) sqrt(conj(w)*w)]));
            
            l_id=sqrt(4*K*phi^2+(diagplus_dist(Dx,Dy))^2);
            l_13=sqrt(4*K*(pi/4-phi)^2+(diagplus_dist(Dx,Perm13*Dy*Perm13')));
            output=min([l_id l_13]);
        end
end
            
            
            
        