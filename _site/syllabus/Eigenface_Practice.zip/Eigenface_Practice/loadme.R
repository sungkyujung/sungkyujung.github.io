
# source("loadme.R")

## 1. 자료 처리, .jpeg 파일을 읽기, 이미지로 그리기 등을 위해 다음이 필요. 

req.packages <- c("tidyverse","GGally","jpeg","countcolors")

for (i in req.packages ){ 
  if( ! require( i , character.only = TRUE ) ){
  #  If package was not able to be loaded then re-install
  install.packages( i , dependencies = TRUE )
  #  Load package after installing
  require( i , character.only = TRUE )
  }
}


## 2. 이미지 자료를 다루기 위해 메모리 용량이 많이 필요하므로, 메모리 청소.
rm(list=ls())

## 3. 얼굴 (이미지)를 그리기 위한 함수
drawface <- function(imgvector, main = "", dim = c(120,100,3)){ 
  imgvector[imgvector > 1] = 1
  imgvector[imgvector < 0] = 0
  img2 <- array(imgvector, dim = dim)
  plotArrayAsImage(img2, main = main)
}


## 4. 큰 사이즈의 얼굴 파일을 작게 자르기 위한 함수 
imagecrop <- function(img) {
  imgg <- array(dim = c(120,100,3))
  for ( k in 1:3){
    imgg[,,k] <- img[61:180,76:175,k]
  }
  imgg
}

