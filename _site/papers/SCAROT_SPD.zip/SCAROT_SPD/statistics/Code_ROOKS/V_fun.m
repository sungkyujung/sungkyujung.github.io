function output=V_fun(input)
%Calculates the intrinsic variance of geodesic normal random variable with
%concentration parameter equal to "input."
output=(1/input)*(1-(2*pi/(sqrt(2*pi/input)*erf(pi*sqrt(input/2))))*exp(-input*pi^2/2));
end