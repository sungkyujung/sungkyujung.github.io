function output=VMF_conc_parm(input,p)
%This function is used for solving for MLE for the concentration parameter
%from the Von Mises Fisher distribution on S^(p-1), the sphere in
%p-dimensional Euclidean space.

initial=input*(p-input^2)/(1-input^2);
update=initial;

tol=10^(-15);
diff=1;
while diff>tol
    initial=update;
    A=besseli(p/2,initial)/besseli(p/2-1,initial);
    update=initial-(A-input)/(1-A^2-((p-1)*A/initial));
    diff=abs(A-input);
end
output=update;
end