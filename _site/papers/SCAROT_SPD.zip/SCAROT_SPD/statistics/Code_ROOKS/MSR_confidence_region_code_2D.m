cd 'C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials';

%Write code for generating bootstrap confidence ellipsoids for population
%location parameter on the tangent space.

p=2;
n=[30 50 100];
evals_conc_parms=[1/0.5 1/1 1/2];
angle_conc_parms=[1/(0.1^2) 1/(0.25^2) 1/(0.5^2)];

evals_mean=5*eye(p);
rot_mean=rot2Dmat(pi/6);

num_sim=500;

K=1;
A=[1 0; 0 -1];

perms=perm_mats(p);
sign_changes=sign_change_mats(p);
size=2^(p-1)*factorial(p);

signed_perms=cell(size,1);
ind=0;

for i=1:length(perms)
    for j=1:length(sign_changes)
        ind=ind+1;
        signed_perms{ind}=perms{i}*sign_changes{j};
    end
end

MSR_sample_means=cell(length(n),length(evals_conc_parms),num_sim);
bootstrap_cov_mats=cell(length(n),length(evals_conc_parms),num_sim);

rng(123)
count=0;

num_boot=50;

for a=1:length(n)
    for b=1:length(evals_conc_parms)
        pd=makedist('Normal','mu',0,'sigma',sqrt(1/angle_conc_parms(b)));
        t=truncate(pd,-pi,pi);
        for c=1:num_sim
            count=count+1
            %Generate data
            log_evals=mvnrnd([0 0],(1/evals_conc_parms(b))*eye(p),n(a));
            angles=random(t,n(a),1);
            SPD_mats=cell(n(a),1);
            for i=1:n(a)
                SPD_mats{i}=(rot2Dmat(angles(i))*rot_mean)*(expm(diag(log_evals(i,:)))*evals_mean)*(rot2Dmat(angles(i))*rot_mean)';
            end
            
            %Compute MSR sample mean
            initial_guess=log_euclidean_mean(SPD_mats);
            MSR_sample_means{a,b,c}=minscrot_mean(SPD_mats,initial_guess,K);
            
            [MSR_mean_U,MSR_mean_D]=eig(MSR_sample_means{a,b,c});
            
            if det(MSR_mean_U)<0
                MSR_mean_U=MSR_mean_U*A;
            end
            
            %Compute a bootstrap covariance estimate for covariance of MSR
            %sampling distribution covariance matrix.
            bootstrap_means=cell(num_boot,1);
            bootstrap_MSR_Log_vec=zeros(num_boot,0.5*p*(p+1));
            for i_boot=1:num_boot
                boot_sample=datasample(SPD_mats,length(SPD_mats));
                initial_guess=log_euclidean_mean(boot_sample);
                bootstrap_means{i_boot,1}=minscrot_mean(boot_sample,initial_guess,K);
                [bootstrap_MSR_D,bootstrap_MSR_U]=rho_min_eigen_decomp(bootstrap_means{i_boot},MSR_mean_D,MSR_mean_U,K);
                bootstrap_MSR_Log=cell(1,2);
                bootstrap_MSR_Log{1,1}=logm(bootstrap_MSR_D)-logm(MSR_mean_D);
                bootstrap_MSR_Log{1,2}=rotlogm(bootstrap_MSR_U*MSR_mean_U');
                bootstrap_MSR_Log_vec(i_boot,:)=[diag(bootstrap_MSR_Log{1,1})' bootstrap_MSR_Log{1,2}(2,1)];
            end
            bootstrap_cov_mats{a,b,c}=(1/num_boot)*bootstrap_MSR_Log_vec'*(eye(num_boot)-(1/num_boot)*ones(num_boot,1)*ones(num_boot,1)')*bootstrap_MSR_Log_vec;
        end
    end
end

%Determine if population eigenvalue mean lies in confidence ellipsoids.
mean_in_CE=zeros(length(n),length(evals_conc_parms),num_sim);
pop_mean_quad_forms=zeros(length(n),length(evals_conc_parms),num_sim);
mean_diffs=zeros(length(n),length(evals_conc_parms),num_sim);
alpha=0.05;
d=0.5*p*(p+1);
for a=1:length(n)
    cutoff=(d/(n(a)-d))*finv(1-alpha,d,n(a)-d);
    for b=1:length(evals_conc_parms)
        for c=1:num_sim
            MSR_mean_D=diag(eig(MSR_sample_means{a,b,c}));
            pop_mean_log_vec=[diag(logm(evals_mean)-logm(MSR_mean_D))' 0]';
            
            pop_mean_quad_forms(a,b,c)=pop_mean_log_vec'*inv(bootstrap_cov_mats{a,b,c})*pop_mean_log_vec;
            
            if pop_mean_quad_forms(a,b,c) <= cutoff
                mean_in_CE(a,b,c)=1;
            end
            
            mean_diffs(a,b,c)=minscrotdist(MSR_sample_means{a,b,c},evals_mean);
        end
    end
end

%Check consistency of sample MSR means and compute coverage rate of population mean%
mean_cov_rates=zeros(length(n),length(evals_conc_parms));
avg_mean_diffs=zeros(length(n),length(evals_conc_parms));
for a=1:length(n)
    for b=1:length(evals_conc_parms)
        mean_cov_rates(a,b)=(1/num_sim)*ones(num_sim,1)'*squeeze(mean_in_CE(a,b,:));
        avg_mean_diffs(a,b)=(1/num_sim)*ones(num_sim,1)'*squeeze(mean_diffs(a,b,:));
    end
end

histogram(squeeze(mean_diffs(2,1,:)))


