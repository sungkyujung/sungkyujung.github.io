function [D, cnt] = geodmeanpd(Array)
% input is either a array of p.d. matrices (p x p x n)
% finds geodesic mean of all inputs
% returns D (geodmean), cnt (count of loops)
%
% array example:
% D = [5 2;
%      2 3]; % this is the mean of the data
%
% B = D^(1/2);
%
% n = 30;
% % In T_D Sym+
% Sigma = [3 1 0.0005;
%          1 2 0;
%          0.0005 0 0.001];
% Y = Sigma^(1/2)*randn(3,n);
% % in Sym+
% Array = zeros(2,2,n);
% for i=1:n
%     Yi =[ Y(1,i) Y(3,i);
%          Y(3,i) Y(2,i)];
%     Zi = B* expm( B^(-1)*Yi*B'^(-1))*B' ;
%      Array(:,:,i) = Zi;
% end


[p p n] = size(Array);

tau = 1;
epsilon = 1e-15;

cnt = 0;

D = mean(Array,3); %initial D
Fold = funobj(D);
% nested function
    function var = funobj(D)
        var = 0;
        for j = 1:n
            var = var + geoddistpd(D,Array(:,:,j))/n;
        end
    end

while true
    Xnow = zeros(p); % allocate space for mean update
    for i = 1:n;
        Xnow = Xnow + LogD(D,Array(:,:,i))/n;
    end
    newD = ExpD(D,tau*Xnow);
    Fnow = funobj(newD);
    fundiff = Fold - Fnow;
    if fundiff <= -1e-5;
        tau = tau/2;
    elseif fundiff < epsilon;
        break;
    else
        Fold = Fnow;
        D = newD;
    end
    
    cnt = cnt+1;
    if cnt >= 100
        disp(['count ' num2str(cnt) ',fundiff ' num2str(fundiff) ',tau ' num2str(tau)])
        break;
    end
end
end