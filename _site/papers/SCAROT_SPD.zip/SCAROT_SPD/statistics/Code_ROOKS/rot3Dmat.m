function output=rot3Dmat(angle,axis)
%Generates 3D rotation matrix using Rodrigues' Rotation Formula%
%Angle can be any number and axis should be a 3-dimensional column vector%
a=axis/sqrt(axis'*axis);
a_cross=[0 -a(3) a(2); a(3) 0 -a(1); -a(2) a(1) 0];
output=eye(3)+sin(angle)*a_cross+(1-cos(angle))*(a_cross)^2;
end