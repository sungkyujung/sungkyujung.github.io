function X=LE_normrnd(mean,cov,n)
%Generate a random sample of SPD matrices that follow a log-Euclidean
%normal distribution.

%Generate data from Log-Euclidean normal distribution
p=length(mean);
q=p*(p-1)/2;

%G=cov^(1/2)*diag([ones(1,p) sqrt(2)*ones(1,q)]);
[U_cov,D_cov]=eig(cov);
G=U_cov*(D_cov^(1/2));
diags=mvnrnd(zeros(1,p),eye(p),n);
%offdiags=mvnrnd(zeros(1,q),0.5*eye(q),n);
offdiags=mvnrnd(zeros(1,q),eye(q),n);

vec=horzcat(diags,offdiags);
vec=vec*G';
%Put the entries of the vector into a 2x2 SPD matrix.
Z=cell(n,1);
X=cell(n,1);

for num=1:n
    Z{num}=zeros(p,p);
    count=0;
    for j=1:p
        for i=1:j
            if i==j
                Z{num}(i,j)=vec(num,j);
            else
                count=count+1;
                Z{num}(i,j)=vec(num,p+count);
                Z{num}(j,i)=vec(num,p+count);
            end
        end
    end
    X{num}=Z{num}+logm(mean);
    X{num}=expm(X{num});
end
end


