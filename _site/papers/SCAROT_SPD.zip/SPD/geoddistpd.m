function dist = geoddistpd(D,X)
% d(D,X), D,X in Sym+
% 
if abs(det(D)) > 1e+10 || min(eig(D)) < 1e-10 || isnan(det(D)) ||isinf(det(X))
    %disp('Message from geoddistpd.m: Check if 1st input is right p.d. matrix');
    Bi = X^(-1/2);
    dist = sqrt(trace(logm(Bi*D*Bi')^2));
    return;
end
%if abs(det(X)) > 1e+10 || min(eig(X)) < 1e-10 || isnan(det(D)) ||isinf(det(X))
%    disp('Message from geoddistpd.m: Check if 2nd input is right p.d. matrix');
%end
Bi = D^(-1/2);
dist = sqrt(trace(logm(Bi*X*Bi')^2));