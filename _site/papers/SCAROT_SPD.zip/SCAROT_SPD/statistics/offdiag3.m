function offdiag = offdiag3(sopMat)

    
    offdiag = [];
    for i = 1:2
        for j = i+1:3
            offdiag = [offdiag ; sopMat(i,j)];
        end
    end    
