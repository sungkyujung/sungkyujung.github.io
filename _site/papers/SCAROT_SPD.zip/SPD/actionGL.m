function phiG = actionGL(G,D)

% G in GL(m) , D in Sym(m)
% action of G to D

phiG = G*D*G';