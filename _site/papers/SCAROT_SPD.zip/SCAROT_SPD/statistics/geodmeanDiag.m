
function meanD = geodmeanDiag(diagDvec);
meanD = geomean(diagDvec,2);
end
