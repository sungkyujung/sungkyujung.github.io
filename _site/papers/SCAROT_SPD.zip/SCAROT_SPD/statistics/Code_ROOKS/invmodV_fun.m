function output=invmodV_fun(input,K)
%Computes the concentration parameter corresponding to a given intrinsic
%variance from the geodesic normal distribution on the circle.

%Want to find gamma such that V(gamma)-input=0.
initial_guess=1/input;
tol=10^-10;

if modV_fun(initial_guess,K)-input==0
    output=initial_guess;
    
else
    if modV_fun(initial_guess,K)-input>0
    %Choose initial values for a and b.
        a=initial_guess;
        b=a;
        diff=1;
        while diff>0
            b=b+1;
            diff=modV_fun(b,K)-input;
        end
    
    else
        b=initial_guess;
        a=b;
        diff=-1;
        while diff<0
            a=a/2;
            diff=modV_fun(a,K)-input;
        end
    end
    
    error=1;
    while error>tol
        c=(a+b)/2;
        if modV_fun(c,K)-input>0
            a=c;
        elseif modV_fun(c,K)-input<0
            b=c;
        else
            a=c;
            b=c;
        end
        error=(b-a)/2;
    end
    output=c;
end    
end