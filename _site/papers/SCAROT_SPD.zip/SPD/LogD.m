function logdx = LogD(D,X)
% Log_D (X)
% D,X \in Sym+

B = chol(D, 'lower');

logdx = actionGL(B,logm(actionGL(B^(-1),X)));

