function PP = SPmatrix(p,odd)
% SPMATRIX signed permutation matrices for dimension p = 2,3,4,... , 
%
% P = permutematrix(p) is a cell array of pxp matrices, where each cell is
% an even signed-permutation matrix with determinant 1. 
% The length of the cell array P is 2^(p-1)p!, which equals the number of 
% all even signed-permutation matrix.
%
% P = permutematrix(p,1) is a cell array of pxp matrices, where each cell is
% a signed-permutation matrix with determinant either 1 or -1.
%
% June 9, 2015 Sungkyu Jung.


ievenmatrix = true; 
if nargin > 1 
  ievenmatrix = ~odd;
end
nperm = factorial(p);
allperm=perms(p:-1:1);

nsignchange = 2^p;
allsignchange = ones(nsignchange,p);
for i = 1:p 
    blocki = [ones(2^(i-1),1); -ones(2^(i-1),1)];
    allsignchange(:,i) =  repmat(blocki,2^(p-i),1);
end

if ievenmatrix;
    counter = 1;
    PP = cell(nperm*nsignchange/2,1);
    
    for i = 1:nperm
        pi = allperm(i,:);
        pIndex = sub2ind([p p],1:p, pi);
        for j = 1:nsignchange
            s = allsignchange(j,:);
            
            A = zeros(p);
            A(pIndex) =  s ;
            
            if det(A)>0
                PP{counter} = A;
                counter = counter + 1;
            end
        end
    end
else % then give all even and odd signed permutation matrices
    counter = 1;
    PP = cell(nperm*nsignchange,1);
    
    for i = 1:nperm
        pi = allperm(i,:);
        pIndex = sub2ind([p p],1:p, pi);
        for j = 1:nsignchange
            s = allsignchange(j,:);
            
            A = zeros(p);
            A(pIndex) =  s ;
            
            PP{counter} = A;
            counter = counter + 1;
        end
    end
    
end