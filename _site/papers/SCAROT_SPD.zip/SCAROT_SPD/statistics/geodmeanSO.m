
function meanU = geodmeanSO(ArrayU,initialValue);


cnt = 0;
TOL = 1e-9;
[p,~,n] = size(ArrayU);


if nargin == 1 
     initialValue = eye(p); 
end
meanUnow = initialValue;
while true
    grad = zeros(p,p);
    for i = 1:n
        grad = grad+logm(ArrayU(:,:,i)*meanUnow');
    end
    meanU = expm(real(grad)/n)*meanUnow;
    cnt = cnt+1; 
    if norm(meanUnow-meanU) < TOL || cnt > 50
        break;
    end
    meanUnow = meanU;
end

end
