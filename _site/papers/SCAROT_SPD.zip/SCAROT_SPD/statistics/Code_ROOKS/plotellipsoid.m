function plotellipsoid(D,U,viewpoint,C)
%Function for plotting a 3D ellipsoid corresponding to a matrix with
%eigen-decomposition (D,U), where D is a diagonal matrix of eigenvalues and
%U is the matrix containing their respective eigenvectors.  The viewpoint
%is the position of the camera for viewing the ellipsoid.
root_D=diag(D^0.5);
[x,y,z]=ellipsoid(0,0,0,root_D(1),root_D(2),root_D(3));
xx = U(1,1)*x+U(1,2)*y+U(1,3)*z;
yy = U(2,1)*x+U(2,2)*y+U(2,3)*z;
zz = U(3,1)*x+U(3,2)*y+U(3,3)*z;
if nargin==3
    surf(xx,yy,zz,'FaceColor','r','EdgeColor','none')
else
    surf(xx,yy,zz,'FaceColor',C*[1 0 0]+(1-C)*[1 1 0],'EdgeColor','none')
end
axis equal 
view(viewpoint)
camlight
end