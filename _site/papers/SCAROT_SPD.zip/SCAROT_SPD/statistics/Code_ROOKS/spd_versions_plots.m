%Create random sample of 2x2 SPD matrices and then create its 4
%corresponding samples in the cross-product space.
rng(0);

n=200;
mean=[0 1 5];
cov=diag([0.10 0.20 0.20]);

sample=mvnrnd(mean,cov,n);
cross_prod_sample=zeros(n,3);
cross_prod_sample(:,1)=sample(:,1);

for i=1:n
    cross_prod_sample(i,2)=exp(sample(i,2));
    cross_prod_sample(i,3)=exp(sample(i,3));
end

scatter3(cross_prod_sample(:,2),cross_prod_sample(:,3),cross_prod_sample(:,1));
scatter3(sample(:,2),sample(:,3),sample(:,1));

SPD_mats=cell(n,1);
for i=1:n
    SPD_mats{i,1}=rot2Dmat(cross_prod_sample(i,1))*diag([cross_prod_sample(i,2) cross_prod_sample(i,3)])*rot2Dmat(cross_prod_sample(i,1))';
end

SPD_coords=zeros(n,3);
for i=1:n
    SPD_coords(i,1)=SPD_mats{i,1}(1,1);
    SPD_coords(i,2)=SPD_mats{i,1}(2,2);
    SPD_coords(i,3)=SPD_mats{i,1}(1,2);
end

scatter3(SPD_coords(:,1),SPD_coords(:,2),SPD_coords(:,3));

%Create 4 versions of the coordinates on the cross-product space.%
Perm=[1 0 0; 0 0 1; 0 1 0];
shift=[pi/2*ones(n,1) zeros(n,2)];

cross_prod_versions=cell(4,1);
cross_prod_versions{1}=zeros(n,3);
cross_prod_versions{2}=zeros(n,3);
cross_prod_versions{3}=zeros(n,3);
cross_prod_versions{4}=zeros(n,3);

for j=1:4
    cross_prod_versions{j}=cross_prod_sample*(Perm^(j-1))'+(j-1)*shift;
end

colors=cell(4,1);
colors{1}='k';
colors{2}='r';
colors{3}='b';
colors{4}='g';

subplot(1,2,1)
%Plot all 4 versions in the cross-product space on the same set of axes.%
for j=1:4
    scatter3(cross_prod_versions{j}(:,2),cross_prod_versions{j}(:,3),cross_prod_versions{j}(:,1),colors{j},'.')
    hold on
end
title('Diag^+(2) \times SO(2)')
xlabel('\lambda_1')
ylabel('\lambda_2')
zlabel('Rotation Angle')

subplot(1,2,2)
scatter3(SPD_coords(:,1),SPD_coords(:,2),SPD_coords(:,3),'.');
title('Sym^+(2)')
xlabel('\Sigma_{11}')
ylabel('\Sigma_{22}')
zlabel('\Sigma_{12}')

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\SPDVersionsPlots.pdf')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plot "observed" eigen-decompositions along with sample of SPD matrices.
A=[1 0;0 -1];
eig_decomps=cell(n,2);
for i=1:n
    [eig_decomps{i,2},eig_decomps{i,1}]=eig(SPD_mats{i});
    if det(eig_decomps{i,2})<0
        eig_decomps{i,2}=eig_decomps{i,2}*A;
    end
end

%Determine version of each eigen-decomposition.
version_ind=zeros(n,1);
for i=1:n
    dists=zeros(4,1);
    for j=1:4
        dists(j)=scale_rot_dist(rot2Dmat(cross_prod_versions{j}(i,1)),diag([cross_prod_versions{j}(i,2:3)]),eig_decomps{i,2},eig_decomps{i,1},1);
    end
    [~,version_ind(i)]=min(dists);
end

%Determine color of each version.
obs_version_colors=zeros(n,3);
for i=1:n
    if version_ind(i)==1
        obs_version_colors(i,:)=[0 0 0];
    elseif version_ind(i)==2
        obs_version_colors(i,:)=[1 0 0];
    elseif version_ind(i)==3
        obs_version_colors(i,:)=[0 0 1];
    else
        obs_version_colors(i,:)=[0 1 0];
    end 
end

%Obtain coordinates for each observed eigen-decomposition.
obs_version_coords=zeros(n,3);
for i=1:n
    obs_version_coords(i,:)=cross_prod_versions{version_ind(i)}(i,:);
end

subplot(1,2,1)
scatter3(obs_version_coords(:,2),obs_version_coords(:,3),obs_version_coords(:,1),36,obs_version_colors,'.');
title('Diag^+(2) \times SO(2)')
xlabel('\lambda_1')
ylabel('\lambda_2')
zlabel('Rotation Angle')
axis([0 600 0 1000 -2 6])

subplot(1,2,2)
scatter3(SPD_coords(:,1),SPD_coords(:,2),SPD_coords(:,3),'.');
title('Sym^+(2)')
xlabel('\Sigma_{11}')
ylabel('\Sigma_{22}')
zlabel('\Sigma_{12}')

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\Observed_Eigen_Decomp_Plots.pdf')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Determine location parameters for different versions of
%eigen-decompositions.
exp_mean=[0 exp(1) exp(5)];
version_loc_parms=zeros(4,3);
for j=1:4
    version_loc_parms(j,:)=exp_mean*(Perm^(j-1))'+[(pi/2)*(j-1) 0 0];
end

%Compute SPD matrix location parameter.
SPD_loc_parm_mat=rot2Dmat(exp_mean(1))*diag([exp_mean(2) exp_mean(3)])*rot2Dmat(exp_mean(1))';
SPD_loc_parm=[SPD_loc_parm_mat(1,1) SPD_loc_parm_mat(2,2) SPD_loc_parm_mat(1,2)];

subplot(1,2,1)
for j=1:4
    scatter3(cross_prod_versions{j}(:,2),cross_prod_versions{j}(:,3),cross_prod_versions{j}(:,1),colors{j},'.')
    hold on
end
title('Diag^+(2) \times SO(2)')
xlabel('\lambda_1')
ylabel('\lambda_2')
zlabel('Rotation Angle')
hold on

scatter3(version_loc_parms(:,2),version_loc_parms(:,3),version_loc_parms(:,1),72,'y','filled');

subplot(1,2,2)
scatter3(SPD_coords(:,1),SPD_coords(:,2),SPD_coords(:,3),'.');
title('Sym^+(2)')
xlabel('\Sigma_{11}')
ylabel('\Sigma_{22}')
zlabel('\Sigma_{12}')
hold on

scatter3(SPD_loc_parm(:,1),SPD_loc_parm(:,2),SPD_loc_parm(:,3),72,'y','filled')

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\SPDVersions_with_means.pdf')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute minimal scaling-rotation mean of sample%
minscrot_sample_mean=minscrot_mean(SPD_mats);
minscrot_sample_mean_coords=[minscrot_sample_mean(1,1) minscrot_sample_mean(2,2) minscrot_sample_mean(1,2)];

%Calculate the Euclidean mean of the sample%
euclid_mean=zeros(2,2);
log_mean=zeros(2,2);
for i=1:n
    euclid_mean=euclid_mean+(1/n)*SPD_mats{i};
    log_mean=log_mean+(1/n)*logm(SPD_mats{i});
end
log_euclid_mean=expm(log_mean);

euclid_mean_coords=[euclid_mean(1,1) euclid_mean(2,2) euclid_mean(1,2)];
log_euclid_mean_coords=[log_euclid_mean(1,1) log_euclid_mean(2,2) log_euclid_mean(1,2)];

%Compare distance between estimated means and "population mean".
pop_SPD_mean=[exp(1) 0; 0 exp(5)];
%Minimal scaling-rotation distance loss function%
dist11=minscrotdist(minscrot_sample_mean,pop_SPD_mean);
dist12=minscrotdist(euclid_mean,pop_SPD_mean);
dist13=minscrotdist(log_euclid_mean,pop_SPD_mean);

%Euclidean distance loss function%
dist21=sqrt(trace((minscrot_sample_mean-pop_SPD_mean)'*(minscrot_sample_mean-pop_SPD_mean)));
dist22=sqrt(trace((euclid_mean-pop_SPD_mean)'*(euclid_mean-pop_SPD_mean)));
dist23=sqrt(trace((log_euclid_mean-pop_SPD_mean)'*(log_euclid_mean-pop_SPD_mean)));

%Log-Euclidean distance loss function%
dist31=sqrt(trace((logm(minscrot_sample_mean)-logm(pop_SPD_mean))'*(logm(minscrot_sample_mean)-logm(pop_SPD_mean))));
dist32=sqrt(trace((logm(euclid_mean)-logm(pop_SPD_mean))'*(logm(euclid_mean)-logm(pop_SPD_mean))));
dist33=sqrt(trace((logm(log_euclid_mean)-logm(pop_SPD_mean))'*(logm(log_euclid_mean)-logm(pop_SPD_mean))));

%Stein Loss%
dist41=trace(minscrot_sample_mean/pop_SPD_mean)-log(det(minscrot_sample_mean/pop_SPD_mean))-2;
dist42=trace(euclid_mean/pop_SPD_mean)-log(det(euclid_mean/pop_SPD_mean))-2;
dist43=trace(log_euclid_mean/pop_SPD_mean)-log(det(log_euclid_mean/pop_SPD_mean))-2;

scatter3(SPD_coords(:,1),SPD_coords(:,2),SPD_coords(:,3),'.','b');
hold on
scatter3(minscrot_sample_mean_coords(:,1),minscrot_sample_mean_coords(:,2),minscrot_sample_mean_coords(:,3),'r','filled')
hold on
scatter3(euclid_mean_coords(:,1),euclid_mean_coords(:,2),euclid_mean_coords(:,3),'g','filled')
hold on
scatter3(log_euclid_mean_coords(:,1),log_euclid_mean_coords(:,2),log_euclid_mean_coords(:,3),'c','filled')
zoom(1.4)
view([15,4])
xlabel('Coord (1,1)')
ylabel('Coord (2,2)')
zlabel('Coord (1,2)')

fig=gcf;
fig.PaperPositionMode='auto';
fig_pos=fig.PaperPosition;
fig.PaperSize=[fig_pos(3) fig_pos(4)];
print(fig,'-dpdf','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\SPDMeanEsts.pdf')

