function conepd2(range,evalpt)
% Draw cone structure of 2 x 2 p.d. matrix

if nargin == 1;
    evalpt = 20;
end

range = abs(range);
evalpt = round(abs(evalpt));

aa = linspace(0,range,evalpt);
bb = linspace(0,range,evalpt);
[X,Y] = meshgrid(aa,bb);
Z1 = sqrt(2)*sqrt(X.*Y);
h1 = surf(X,Y,Z1);set(h1,'facealpha',0.6,'EdgeColor','none')
hold on;
Z2 = -sqrt(2)*sqrt(X.*Y);
h2 = surf(X,Y,Z2);set(h2,'facealpha',0.6,'EdgeColor','none')
axis equal;
xlabel('diagonal 1');
ylabel('diagonal 2');
zlabel('off-diagonal');
title(' 2x2 p.d. matrices: inside of surface')