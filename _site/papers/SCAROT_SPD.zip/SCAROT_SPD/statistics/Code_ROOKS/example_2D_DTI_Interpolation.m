%2 dimensional interpolation of 4 diffusion tensors using weighted mean
%estimation.

cd 'C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials';
grid_size=5;

%Create a 5-by-5 grid of equally spaced points%
grid_coords=cell(grid_size,grid_size);
for i=1:grid_size
    for j=1:grid_size
        grid_coords{i,j}=[i; j];
    end
end

%Compute weights at each grid coordinate using equation 22 from Dryden's
%2015 paper on weighted Procrustes averaging.
A=1/2;
B=0.01;

sample_coords=cell(4,1);
sample_coords{1}=grid_coords{1,1};
sample_coords{2}=grid_coords{1,grid_size};
sample_coords{3}=grid_coords{grid_size,1};
sample_coords{4}=grid_coords{grid_size,grid_size};

weights=cell(grid_size,grid_size);

for i=1:grid_size
    for j=1:grid_size
        if i==1 && j==1
            weights{i,j}=[1; 0; 0; 0];
        elseif i==1 && j==grid_size
            weights{i,j}=[0; 1; 0; 0];
        elseif i==grid_size && j==1
            weights{i,j}=[0; 0; 1; 0];
        elseif i==grid_size && j==grid_size
            weights{i,j}=[0; 0; 0; 1];
        else
            weights{i,j}=zeros(4,1);
            for k=1:4
                %weights{i,j}(k)=exp(-A*(sample_coords{k}-grid_coords{i,j})'*(sample_coords{k}-grid_coords{i,j}))+B;
                weights{i,j}(k)=1/sqrt(((sample_coords{k}-grid_coords{i,j})'*(sample_coords{k}-grid_coords{i,j})));
            end
            weights{i,j}=weights{i,j}/(weights{i,j}'*ones(4,1));
        end   
    end
end

%Create diffusion tensors%
tensors=cell(4,2);
tensors{1,1}=4*eye(3);
tensors{2,1}=rot3Dmat(-pi/4,[0; 1; 0])*diag([16 4 1])*rot3Dmat(-pi/4,[0; 1; 0])';
tensors{3,1}=diag([16 4 1]);
tensors{4,1}=rot3Dmat(pi/4,[0; 1; 0])*diag([16 4 1])*rot3Dmat(pi/4,[0; 1; 0])';
tensors{1,2}=0.5*eye(3);
tensors{2,2}=rot3Dmat(-pi/4,[0; 1; 0])*diag([10 1 8])*rot3Dmat(-pi/4,[0; 1; 0])';
tensors{3,2}=diag([16 4 1]);
tensors{4,2}=rot3Dmat(pi/4,[0; 1; 0])*diag([16 4 1])*rot3Dmat(pi/4,[0; 1; 0])';

%Euclidean interpolants%
euclidean_w_means=cell(grid_size,grid_size,2);
for h=1:2
    for i=1:grid_size
        for j=1:grid_size
            euclidean_w_means{i,j,h}=zeros(3,3);
            for k=1:4
                euclidean_w_means{i,j,h}=euclidean_w_means{i,j,h}+weights{i,j}(k)*tensors{k,h};
            end
        end
    end
end

for h=1:2
    num=0;
    for i=1:grid_size
        for j=1:grid_size
            num=num+1;
            [U,D]=eig(euclidean_w_means{i,j,h});
            if det(U)<0
                U=U*diag([1 1 -1]);
            end
            R=euclidean_w_means{i,j,h}/trace(euclidean_w_means{i,j,h});
            FA=sqrt(0.5*(3-1/trace(R^2)));
            subplot(grid_size,grid_size,num)
            plotellipsoid(D,U,[0 1 0],FA)
            axis([-4 4 -4 4 -4 4])
            axis off
            zoom(1.2)
        end
    end
    suptitle('Euclidean 2D Interpolation')
    fig=gcf;
    if h==1
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\Euclidean_2D_Interpolation_Version1.png')
        close(gcf)
    else
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\Euclidean_2D_Interpolation_Version2.png')
        close(gcf)
    end
end

%Log-Euclidean interpolants%
log_euclidean_w_means=cell(grid_size,grid_size,2);
for h=1:2
    for i=1:grid_size
        for j=1:grid_size
            log_euclidean_w_means{i,j,h}=zeros(3,3);
            for k=1:4
                log_euclidean_w_means{i,j,h}=log_euclidean_w_means{i,j,h}+weights{i,j}(k)*logm(tensors{k,h});
            end
            log_euclidean_w_means{i,j,h}=expm(log_euclidean_w_means{i,j,h});
        end
    end
end

for h=1:2
    num=0;
    for i=1:grid_size
        for j=1:grid_size
            num=num+1;
            [U,D]=eig(log_euclidean_w_means{i,j,h});
            if det(U)<0
                U=U*diag([1 1 -1]);
            end
            R=log_euclidean_w_means{i,j,h}/trace(log_euclidean_w_means{i,j,h});
            FA=sqrt(0.5*(3-1/trace(R^2)));
            subplot(grid_size,grid_size,num)
            plotellipsoid(D,U,[0 1 0],FA)
            axis([-4 4 -4 4 -4 4])
            axis off
            zoom(1.2)
        end
    end
    suptitle('Log-Euclidean 2D Interpolation')
    fig=gcf;
    if h==1
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\Log-Euclidean_2D_Interpolation_Version1.png')
        close(gcf)
    else
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\Log-Euclidean_2D_Interpolation_Version2.png')
        close(gcf)
    end
end

%Procrustes Size and Shape interpolants%
procrustes_w_means=cell(grid_size,grid_size,2);
for h=1:2
    for i=1:grid_size
        for j=1:grid_size
            procrustes_w_means{i,j,h}=weighted_procrustesSS_mean(tensors(:,h),weights{i,j});
        end
    end
end

for h=1:2
    num=0;
    for i=1:grid_size
        for j=1:grid_size
            num=num+1;
            [U,D]=eig(procrustes_w_means{i,j,h});
            if det(U)<0
                U=U*diag([1 1 -1]);
            end
            R=procrustes_w_means{i,j,h}/trace(procrustes_w_means{i,j,h});
            FA=sqrt(0.5*(3-1/trace(R^2)));
            subplot(grid_size,grid_size,num)
            plotellipsoid(D,U,[0 1 0],FA)
            axis([-4 4 -4 4 -4 4])
            axis off
            zoom(1.2)
        end
    end
    suptitle('Procrustes Size and Shape 2D Interpolation')
    fig=gcf;
    if h==1
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\Procrustes_2D_Interpolation_Version1.png')
        close(gcf)
    else
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\Procrustes_2D_Interpolation_Version2.png')
        close(gcf)
    end
end

%MSR interpolants%
msr_w_means=cell(grid_size,grid_size,2);
for h=1:2
    for i=1:grid_size
        for j=1:grid_size
            msr_w_means{i,j,h}=weighted_minscrot_mean(tensors(:,h),weights{i,j},procrustes_w_means{i,j,h});
        end
    end
end

for h=1:2
    num=0;
    for i=1:grid_size
        for j=1:grid_size
            num=num+1;
            [U,D]=eig(msr_w_means{i,j,h});
            if det(U)<0
                U=U*diag([1 1 -1]);
            end
            R=msr_w_means{i,j,h}/trace(msr_w_means{i,j,h});
            FA=sqrt(0.5*(3-1/trace(R^2)));
            subplot(grid_size,grid_size,num)
            plotellipsoid(D,U,[0 1 0],FA)
            axis([-4 4 -4 4 -4 4])
            axis off
            zoom(1.2)
        end
    end
    suptitle('Minimal Scaling-Rotation 2D Interpolation')
    fig=gcf;
    if h==1
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\MSR_2D_Interpolation_Version1.png')
        close(gcf)
    else
        print(fig,'-dpng','-r0','C:\Users\Brian\Documents\School Files\Thesis Research\Matlab Code\Thesis Materials\MSR_2D_Interpolation_Version2.png')
        close(gcf)
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot('Position',[0 0.5 0.5 0.5])
imshow('Euclidean_2D_Interpolation_Version1.png')
subplot('Position',[0.5 0.5 0.5 0.5])
imshow('Log-Euclidean_2D_Interpolation_Version1.png')
subplot('Position',[0 0 0.5 0.5])
imshow('Procrustes_2D_Interpolation_Version1.png')
subplot('Position',[0.5 0 0.5 0.5])
imshow('MSR_2D_Interpolation_Version1.png')

fig=gcf;
print(fig,'-dpng','-r1000','C:\Users\Brian\Documents\School Files\Thesis Research\Dissertation\2D_Interpolation_Comparisons_Version1.png')
close(gcf)

figure
subplot('Position',[0 0.5 0.5 0.5])
imshow('Euclidean_2D_Interpolation_Version2.png')
subplot('Position',[0.5 0.5 0.5 0.5])
imshow('Log-Euclidean_2D_Interpolation_Version2.png')
subplot('Position',[0 0 0.5 0.5])
imshow('Procrustes_2D_Interpolation_Version2.png')
subplot('Position',[0.5 0 0.5 0.5])
imshow('MSR_2D_Interpolation_Version2.png')

fig=gcf;
print(fig,'-dpng','-r1000','C:\Users\Brian\Documents\School Files\Thesis Research\Dissertation\2D_Interpolation_Comparisons_Version2.png')
close(gcf)



