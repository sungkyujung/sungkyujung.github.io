function d =Mdist(U1,D1,U2,D2,k)
% The geodesic distance function on M(p) = SO(p) x Diag-plus(p).
% returns the distance from (U1,D1) from (U2,D2), with the weighting factor k>0.
 
A = rotlogm(U1*U2');
L = logm(D1/D2);
d = sqrt(k/2* trace(A*A') + trace (L*L'));
                     
end