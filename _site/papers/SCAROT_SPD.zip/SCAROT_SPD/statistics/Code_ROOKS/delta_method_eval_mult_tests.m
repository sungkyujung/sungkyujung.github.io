%Simulation for Testing Eigenvalue Mutliplicity Pattern
p=3;
%mu=5*ones(p,1);
evals_var=0.75;
alt_mu=[exp(2+sqrt(evals_var)); exp(2-sqrt(evals_var))];
mu=alt_mu;

mu=2*ones(p,1);


%Determine asymptotic variance of test statistic
log_mu=log(mu);
pop_alpha_1=(1/p)*ones(p,1)'*log_mu;
pop_alpha_2=evals_var+(1/p)*(log_mu'*log_mu);
%pop_alpha_3=log_mu(1)*log_mu(2);
pop_alpha_3=(log_mu(1)*log_mu(2)+log_mu(1)*log_mu(3)+log_mu(2)*log_mu(3))/3;

%pop_cov=[pop_alpha_2-pop_alpha_1^2 pop_alpha_1*(pop_alpha_2-pop_alpha_3); pop_alpha_1*(pop_alpha_2-pop_alpha_3) pop_alpha_2^2-pop_alpha_3^2];
pop_cov=[pop_alpha_2-pop_alpha_1^2 evals_var*pop_alpha_1; evals_var*pop_alpha_1 evals_var*(evals_var+p^2*pop_alpha_1^2-p*pop_alpha_3)];
pop_grad=[2*pop_alpha_1; -1];

%asym_test_stat_var=pop_grad'*pop_cov*pop_grad;
asym_test_stat_var=4*pop_alpha_1^2*(pop_alpha_2-pop_alpha_1^2-evals_var/2)+pop_alpha_2^2-pop_alpha_3^2-2*pop_alpha_1^2*evals_var;

angle_var=0.3^2;

num_sim=1000;

num_boot=100;

n=[50;100;500];

test_stats=zeros(length(n),num_sim);
null_var=zeros(length(n),num_sim);
reject_yn=zeros(length(n),num_sim);

mu_desc_ests=zeros(num_sim,2,length(n));

perms=perm_mats(p);

count=0;
rng(123);
for i=1:length(n)
    for j=1:num_sim
        count=count+1
        %Generate data
        evals=mvnrnd(log(mu)',evals_var*eye(p),n(i));
        %angles=normrnd(pi/3,sqrt(angle_var),n(i),1);
        
        eval_mats=cell(n(i),1);
        
        for a=1:n(i)
            unif=randi(factorial(p));
            eval_mats{a}=perms{unif}*diag(exp(evals(a,:)))*perms{unif}';
        end
        
        %Bootstrap estimate of variance of test statistic.
        %boot_test_stats=zeros(num_boot,1);
        %for i_boot=1:num_boot
        %    boot_inds=randsample(n(i),n(i),true);
        %    est_comps=zeros(n(i),2);
        %    alpha_2=0;
        %    for a=1:n(i)
        %        est_comps(boot_inds(a),1)=log(eval_mats{boot_inds(a)}(1,1));
        %        est_comps(boot_inds(a),2)=log(eval_mats{boot_inds(a)}(1,1))*log(eval_mats{boot_inds(a)}(2,2));
        %        alpha_2=alpha_2+(1/n(i))*log(eval_mats{boot_inds(a)}(1,1))^2;
        %    end
        
        %    alpha_1=(1/n(i))*ones(n(i),1)'*est_comps*[1;0];
        %    alpha_3=(1/n(i))*ones(n(i),1)'*est_comps*[0;1];
        %    boot_test_stats(i_boot)=sqrt(n(i))*(alpha_1^2-alpha_3);
        %    bootstrap_var=var(boot_test_stats);
        %end
        
        %Computation of test statistic.
        est_comps=zeros(n(i),2);
        alpha_2=0;
        for a=1:n(i)
            %est_comps(a,1)=log(eval_mats{a}(1,1));
            est_comps(a,1)=trace(logm(eval_mats{a}))/p;
            %est_comps(a,2)=log(eval_mats{a}(1,1))*log(eval_mats{a}(2,2));
            est_comps(a,2)=(log(eval_mats{a}(1,1))*log(eval_mats{a}(2,2))+log(eval_mats{a}(1,1))*log(eval_mats{a}(3,3))+log(eval_mats{a}(3,3))*log(eval_mats{a}(2,2)))/3;
            alpha_2=alpha_2+(1/n(i))*log(eval_mats{a}(1,1))^2;
        end
        
        alpha_1=(1/n(i))*ones(n(i),1)'*est_comps*[1;0];
        alpha_3=(1/n(i))*ones(n(i),1)'*est_comps*[0;1];
        
        %cov=(1/n(i))*(est_comps'*est_comps);
        cov=(1/n(i))*est_comps'*(eye(n(i))-(1/n(i))*ones(n(i),1)*ones(n(i),1)')*est_comps;
        
        grad=[2*alpha_1; -1];
        
        null_var(i,j)=alpha_2^2-alpha_3^2;
        
        %test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3)/sqrt(asym_test_stat_var);
        %test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3)/bootstrap_var;
        %test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3);
        test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3)/sqrt(grad'*cov*grad);
        %test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3)/sqrt(cov(2,2));
        %test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3)/sqrt(abs(null_var(i,j)));
        %test_stats(i,j)=sqrt(n(i))*(alpha_1^2-alpha_3)/sqrt(cov(1,1)^2+2*cov(1,1)*alpha_1^2);
        
        %Compute estimator for permuted version of mu.
        if test_stats(i,j)>=0
            mu_desc_ests(j,:,i)=[alpha_1+sqrt(alpha_1^2-alpha_3) alpha_1-sqrt(alpha_1^2-alpha_3)];
        else
            mu_desc_ests(j,:,i)=[alpha_1 alpha_1];
        end
        
    end
end

%Empirical Type I error rates
reject_yn=zeros(length(n),num_sim);
alpha=0.10;
for i=1:length(n)
    for j=1:num_sim
        if test_stats(i,j)>norminv(1-alpha)
            reject_yn(i,j)=1;
        end
    end
end

typeI_error_probs=(1/num_sim)*reject_yn*ones(num_sim,1)

figure
for i=1:length(n)
    subplot(2,length(n),i)
    histogram(test_stats(i,:))
    title(['n=' num2str(n(i))])
    xlabel('Test Statistics')
    
    subplot(2,length(n),length(n)+i)
    qqplot(test_stats(i,:))
    title(['n=' num2str(n(i))])
    ylabel('Test Statistic Quantiles')
    axis square
end

%Plots illustrating consistency of MOM estimator when mu has 1 unique
%entry.

for i=1:length(n)
    subplot(1,length(n),i)
    scatter(mu_desc_ests(:,1,i),mu_desc_ests(:,2,i))
    xlim([0 2])
    xlabel('$\hat{\mu}_{(1)}$','interpreter','latex')
    ylim([0 1])
    ylabel('$\hat{\mu}_{(2)}$','interpreter','latex')
    hold on
    scatter(log_mu(1),log_mu(2),30,'r','filled')
    title(['n=' num2str(n(i))])
    axis square
end

%Compute empirical MSE of MOM estimator for mu.
mu_MOM_est_MSEs=zeros(length(n),1);
for i=1:length(n)
    mu_MOM_est_MSEs(i)=trace((mu_desc_ests(:,:,i)-kron(log_mu',ones(num_sim,1)))'*(mu_desc_ests(:,:,i)-kron(log_mu',ones(num_sim,1))))/num_sim;
end

%Plots illustrating consistency of MOM estimator when mu has 2 unique
%entry.
for i=1:length(n)
    subplot(1,length(n),i)
    scatter(mu_desc_ests(:,1,i),mu_desc_ests(:,2,i))
    xlim([1 5])
    xlabel('$\hat{\mu}_{(1)}$','interpreter','latex')
    ylim([0.5 2.5])
    ylabel('$\hat{\mu}_{(2)}$','interpreter','latex')
    hold on
    scatter(log_mu(1),log_mu(2),30,'r','filled')
    title(['n=' num2str(n(i))])
    axis square
end

%Compute empirical MSE of MOM estimator for mu.
mu_MOM_est_MSEs=zeros(length(n),1);
for i=1:length(n)
    mu_MOM_est_MSEs(i)=trace((mu_desc_ests(:,:,i)-kron(log_mu',ones(num_sim,1)))'*(mu_desc_ests(:,:,i)-kron(log_mu',ones(num_sim,1))))/num_sim;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Testing for 2 unique eigenvalues (p >= 3)%

%Simulation for Testing Eigenvalue Mutliplicity Pattern
p=3;
evals_var=0.75;
mult=2;

%mu=[exp(2+mult*sqrt(evals_var));exp(2-mult*sqrt(evals_var));exp(2)];
mu=[exp(2+mult*sqrt(evals_var));exp(2+mult*sqrt(evals_var));exp(2)];
%mu=[exp(2-mult*sqrt(evals_var));exp(2-mult*sqrt(evals_var));exp(2)];
%mu=exp(2)*ones(p,1);
log_mu=log(mu);

pop_alpha1=ones(p,1)'*log_mu/p;
pop_alpha2=evals_var+log_mu'*log_mu/p;
pop_alpha3=(log_mu(1)*log_mu(2)+log_mu(1)*log_mu(3)+log_mu(2)*log_mu(3))/3;
pop_alpha4=log_mu(1)*log_mu(2)*log_mu(3);

h1=pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3);
h2=2*(pop_alpha1^2-pop_alpha3)^(3/2);

pop_a_0=h1/h2;

%Compute mu_perm.%
if pop_alpha1^2-pop_alpha3==0
    perm_log_mu=log_mu;
elseif pop_a_0<=-1
    perm_log_mu=[pop_alpha1-2*sqrt(pop_alpha1^2-pop_alpha3); pop_alpha1+sqrt(pop_alpha1^2-pop_alpha3); pop_alpha1+sqrt(pop_alpha1^2-pop_alpha3)];
elseif pop_a_0>=1
    perm_log_mu=[pop_alpha1-sqrt(pop_alpha1^2-pop_alpha3); pop_alpha1+2*sqrt(pop_alpha1^2-pop_alpha3); pop_alpha1-sqrt(pop_alpha1^2-pop_alpha3)];
else
    theta=asin(pop_a_0)/3;
    perm_log_mu=zeros(3,1);
    perm_log_mu(1)=pop_alpha1+sqrt(3*(pop_alpha1^2-pop_alpha3))*(-cos(theta)+sin(theta)/sqrt(3));
    perm_log_mu(2)=pop_alpha1+sqrt(3*(pop_alpha1^2-pop_alpha3))*(cos(theta)+sin(theta)/sqrt(3));
    perm_log_mu(3)=pop_alpha1-2*sqrt(pop_alpha1^2-pop_alpha3)*sin(theta);
end

perm_log_mu=real(perm_log_mu);
g=h1^2-h2^2;

grad=zeros(3,1);
grad(1)=2*(pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3))*(6*pop_alpha1^2-3*pop_alpha3)-24*pop_alpha1*(pop_alpha1^2-pop_alpha3)^2;
grad(2)=12*(pop_alpha1^2-pop_alpha3)^2-6*pop_alpha1*(pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3));
grad(3)=2*(pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3));

%Compute asymptotic covariance of moment estimators.
mom_ests_asym_cov=zeros(3,3);
mom_ests_asym_cov(1,1)=pop_alpha2-pop_alpha1^2;
mom_ests_asym_cov(2,2)=((evals_var+log_mu(1)^2)*(evals_var+log_mu(2)^2)+(evals_var+log_mu(1)^2)*(evals_var+log_mu(3)^2)+(evals_var+log_mu(2)^2)*(evals_var+log_mu(3)^2))/3 - pop_alpha3^2;
mom_ests_asym_cov(3,3)=(evals_var+log_mu(1)^2)*(evals_var+log_mu(2)^2)*(evals_var+log_mu(3)^2)-pop_alpha4^2;
mom_ests_asym_cov(1,2)=((evals_var+log_mu(1)^2)*log_mu(2)+(evals_var+log_mu(1)^2)*log_mu(3)+(evals_var+log_mu(2)^2)*log_mu(1)+(evals_var+log_mu(2)^2)*log_mu(3)+(evals_var+log_mu(3)^2)*log_mu(1)+(evals_var+log_mu(3)^2)*log_mu(2))/6-pop_alpha1*pop_alpha3;
mom_ests_asym_cov(2,1)=((evals_var+log_mu(1)^2)*log_mu(2)+(evals_var+log_mu(1)^2)*log_mu(3)+(evals_var+log_mu(2)^2)*log_mu(1)+(evals_var+log_mu(2)^2)*log_mu(3)+(evals_var+log_mu(3)^2)*log_mu(1)+(evals_var+log_mu(3)^2)*log_mu(2))/6-pop_alpha1*pop_alpha3;
mom_ests_asym_cov(1,3)=((evals_var+log_mu(1)^2)*log_mu(2)*log_mu(3)+(evals_var+log_mu(2)^2)*log_mu(1)*log_mu(3)+(evals_var+log_mu(3)^2)*log_mu(1)*log_mu(2))/3-pop_alpha1*pop_alpha4;
mom_ests_asym_cov(3,1)=((evals_var+log_mu(1)^2)*log_mu(2)*log_mu(3)+(evals_var+log_mu(2)^2)*log_mu(1)*log_mu(3)+(evals_var+log_mu(3)^2)*log_mu(1)*log_mu(2))/3-pop_alpha1*pop_alpha4;
mom_ests_asym_cov(2,3)=((evals_var+log_mu(1)^2)*(evals_var+log_mu(2)^2)*log_mu(3)+(evals_var+log_mu(1)^2)*(evals_var+log_mu(3)^2)*log_mu(2)+(evals_var+log_mu(2)^2)*(evals_var+log_mu(3)^2)*log_mu(1))/3-pop_alpha3*pop_alpha4;
mom_ests_asym_cov(3,2)=((evals_var+log_mu(1)^2)*(evals_var+log_mu(2)^2)*log_mu(3)+(evals_var+log_mu(1)^2)*(evals_var+log_mu(3)^2)*log_mu(2)+(evals_var+log_mu(2)^2)*(evals_var+log_mu(3)^2)*log_mu(1))/3-pop_alpha3*pop_alpha4;

%Compute Hessian of g function.
g_hessian=zeros(3,3);
g_hessian(1,1)=18*(pop_alpha1^2+pop_alpha1^2-pop_alpha3)^2+12*pop_alpha1*(pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3));
g_hessian(2,2)=18*pop_alpha1^2-24*(pop_alpha1^2-pop_alpha3);
g_hessian(3,3)=2;
g_hessian(1,2)=48*pop_alpha1*(pop_alpha1^2-pop_alpha3)-18*pop_alpha1*(pop_alpha1^2+pop_alpha1^2-pop_alpha3)-6*(pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3));
g_hessian(2,1)=48*pop_alpha1*(pop_alpha1^2-pop_alpha3)-18*pop_alpha1*(pop_alpha1^2+pop_alpha1^2-pop_alpha3)-6*(pop_alpha4-pop_alpha1^3+3*pop_alpha1*(pop_alpha1^2-pop_alpha3));
g_hessian(1,3)=6*(pop_alpha1^2+pop_alpha1^2-pop_alpha3);
g_hessian(3,1)=6*(pop_alpha1^2+pop_alpha1^2-pop_alpha3);
g_hessian(2,3)=-6*pop_alpha1;
g_hessian(3,2)=-6*pop_alpha1;

det(g_hessian)
eig(g_hessian)


angle_var=0.3^2;

num_sim=1000;

num_boot=100;

n=[50;100;500];

test_stats=zeros(length(n),num_sim);
test_stats_linear_comps=zeros(length(n),num_sim);
g_fun=zeros(length(n),num_sim);

null_var=zeros(length(n),num_sim);
perms=perm_mats(p);

count=0;
%rng(1204);
rng(1033);

mu_perm_ests=zeros(num_sim,3,length(n));

for i=1:length(n)
    for j=1:num_sim
        
        
        count=count+1
        %Generate data
        evals=mvnrnd(log(mu)',evals_var*eye(p),n(i));
        %evals=mvnrnd([2+(b-1)*sqrt(evals_var) 2+(b-1)*sqrt(evals_var) 2],evals_var*eye(p),n(i));
        eval_mats=cell(n(i),1);
        
        for a=1:n(i)
            unif=randi(factorial(p));
            eval_mats{a}=perms{unif}*diag(exp(evals(a,:)))*perms{unif}';
        end
        
        %Computation of test statistic.
        est_comps=zeros(n(i),3);
        for a=1:n(i)
            est_comps(a,1)=(log(eval_mats{a}(1,1))+log(eval_mats{a}(2,2))+log(eval_mats{a}(3,3)))/3;
            %est_comps(a,1)=log(eval_mats{a}(1,1));
            est_comps(a,2)=(log(eval_mats{a}(1,1))*log(eval_mats{a}(2,2))+log(eval_mats{a}(1,1))*log(eval_mats{a}(3,3))+log(eval_mats{a}(2,2))*log(eval_mats{a}(3,3)))/3;
            %est_comps(a,2)=log(eval_mats{a}(1,1))*log(eval_mats{a}(2,2));
            est_comps(a,3)=log(eval_mats{a}(1,1))*log(eval_mats{a}(2,2))*log(eval_mats{a}(3,3));
            %g_fun(i,j)=g_fun(i,j)+(1/n(i))*4*(est_comps(a,1)^2-est_comps(a,2))^3-(1/n(i))*(est_comps(a,3)-est_comps(a,1)^3+3*est_comps(a,1)*(est_comps(a,1)^2-est_comps(a,2)));
            %g_fun(i,j)=g_fun(i,j)+(1/n(i))*(est_comps(a,3)-est_comps(a,1)^3+3*est_comps(a,1)*(est_comps(a,1)^2-est_comps(a,2)))/(2*(est_comps(a,1)^2-est_comps(a,2))^(3/2));
        end
        
        alpha_1=(1/n(i))*ones(n(i),1)'*est_comps*[1;0;0];
        alpha_3=(1/n(i))*ones(n(i),1)'*est_comps*[0;1;0];
        alpha_4=(1/n(i))*ones(n(i),1)'*est_comps*[0;0;1];
        
        cov=(1/n(i))*est_comps'*(eye(n(i))-(1/n(i))*ones(n(i),1)*ones(n(i),1)')*est_comps;
        
        grad=zeros(3,1);
        grad(1)=24*alpha_1*(alpha_1^2-alpha_3)^2-2*(alpha_4-alpha_1^3+3*alpha_1*(alpha_1^2-alpha_3))*(6*alpha_1^2-3*alpha_3);
        grad(2)=6*alpha_1*(alpha_4-alpha_1^3+3*alpha_1*(alpha_1^2-alpha_3))-12*(alpha_1^2-alpha_3)^2;
        grad(3)=-2*(alpha_4-alpha_1^3+3*alpha_1*(alpha_1^2-alpha_3));
        
        %Compute observed evals sample covariance matrix.
        %avg=zeros(3,1);
        %sample_cov=zeros(3,3);
        %for a=1:n(i)
        %    avg=avg+(1/n(i))*diag(logm(eval_mats{a}));
        %    sample_cov=sample_cov+(1/n(i))*diag(logm(eval_mats{a}))*diag(logm(eval_mats{a}))';
        %end
        
        %sample_cov=sample_cov-avg*avg';
        
        %g_fun(i,j)=((alpha_4+2*alpha_1^3-3*alpha_1*alpha_3)^2/(4*(alpha_1^2-alpha_3)^3));
        %g_fun(i,j)=(alpha_4-alpha_1^3+3*alpha_1*(alpha_1^2-alpha_3))/(2*(alpha_1^2-alpha_3)^(3/2));
        
        %max(eig(sample_cov))-min(eig(sample_cov))
        
        %test_stats(i,j)=(alpha_4-alpha_1^3+3*alpha_1*(max(eig(sample_cov))-min(eig(sample_cov)))/(2*(max(eig(sample_cov))-min(eig(sample_cov)))^(3/2)));
        test_stats(i,j)=sqrt(n(i))*(-1)*((alpha_4-alpha_1^3+alpha_1*3*(alpha_1^2-alpha_3))^2-4*(alpha_1^2-alpha_3)^3)/sqrt(grad'*cov*grad);
        %test_stats(b,j)=sqrt(n(i))*(-1)*((alpha_4-alpha_1^3+alpha_1*3*(alpha_1^2-alpha_3))^2-4*(alpha_1^2-alpha_3)^3);
        %test_stats(i,j)=(alpha_4-alpha_1^3+alpha_1*3*(max(eig(sample_cov))-min(eig(sample_cov))))^2-4*(max(eig(sample_cov))-min(eig(sample_cov)))^3;
        %test_stats(i,j)=sqrt(n(i))*(alpha_4-alpha_1^3+alpha_1*3*(alpha_1^2-alpha_3))/(2*(alpha_1^2-alpha_3)^(3/2));
        %test_stats_linear_comps(i,j)=2*n(i)*((alpha_4-alpha_1^3+alpha_1*3*(alpha_1^2-alpha_3)-h1)-(2*(alpha_1^2-alpha_3)^(3/2)-h2));
        
        mu_perm_ests(j,1,i)=0;
        mu_perm_ests(j,2,i)=0;
        mu_perm_ests(j,3,i)=0;
        
        a_0=(alpha_4-alpha_1^3+3*alpha_1*(alpha_1^2-alpha_3))/(2*(alpha_1^2-alpha_3)^(3/2));
        
        if alpha_1^2-alpha_3<0
            mu_perm_ests(j,1,i)=alpha_1;
            mu_perm_ests(j,2,i)=alpha_1;
            mu_perm_ests(j,3,i)=alpha_1;
        elseif alpha_1^2-alpha_3>=0 && a_0<-1
            mu_perm_ests(j,1,i)=alpha_1-2*sqrt(alpha_1^2-alpha_3);
            mu_perm_ests(j,2,i)=alpha_1+sqrt(alpha_1^2-alpha_3);
            mu_perm_ests(j,3,i)=alpha_1+sqrt(alpha_1^2-alpha_3);
        elseif alpha_1^2-alpha_3>=0 && a_0>1
            mu_perm_ests(j,1,i)=alpha_1-sqrt(alpha_1^2-alpha_3);
            mu_perm_ests(j,2,i)=alpha_1+2*sqrt(alpha_1^2-alpha_3);
            mu_perm_ests(j,3,i)=alpha_1-sqrt(alpha_1^2-alpha_3);
        else
            theta=asin(a_0)/3;
            mu_perm_ests(j,1,i)=alpha_1+sqrt(3*(alpha_1^2-alpha_3))*(-cos(theta)+sin(theta)/sqrt(3));
            mu_perm_ests(j,2,i)=alpha_1+sqrt(3*(alpha_1^2-alpha_3))*(cos(theta)+sin(theta)/sqrt(3));
            mu_perm_ests(j,3,i)=alpha_1-2*sqrt(alpha_1^2-alpha_3)*sin(theta);
        end
            
        
        %grad=zeros(3,1);
        %grad(1)=(6*alpha_1^2-3*alpha_3)/(2*(alpha_1^2-alpha_3)^(3/2))-(6*alpha_1*(alpha_4+2*alpha_1^3-3*alpha_1*alpha_3)/((alpha_1^2-alpha_3)^(5/2)));
        %grad(2)=-3*alpha_1/(2*(alpha_1^2-alpha_3)^(3/2))+3*(alpha_4+2*alpha_1^3-3*alpha_1*alpha_3)/((alpha_1^2-alpha_3)^(5/2));
        %grad(3)=1/(2*(alpha_1^2-alpha_3)^(3/2));
        
        %grad=2*sqrt(g_fun)*grad;
        
        %test_stats(i,j)=sqrt(n(i))*(g_fun-1)/sqrt(grad'*cov*grad);
        %test_stats(i,j)=sqrt(n(i))*(g_fun-1);
    end
end

reject_yn=zeros(length(n),num_sim);
alpha=0.10;
for i=1:length(n)
    for j=1:num_sim
        if test_stats(i,j)>norminv(1-alpha)
            reject_yn(i,j)=1;
        end
    end
end
typeI_error_probs=(1/num_sim)*reject_yn*ones(num_sim,1)

%Estimate variance of test statistics.
%test_stats_vars=var(test_stats,0,2)/2;

figure
for i=1:length(n)
    subplot(2,length(n),i)
    histogram(test_stats(i,:))
    title(['n=' num2str(n(i))])
    xlabel('Test Statistics')
    
    subplot(2,length(n),length(n)+i)
    qqplot(test_stats(i,:))
    title(['n=' num2str(n(i))])
    ylabel('Test Statistic Quantiles')
    axis square
end

figure
for i=1:length(n)
    subplot(1,length(n),i)
    histogram(test_stats(i,:))
    title(['n=' num2str(n(i))])
    xlabel('Test Statistics')
end


%Compute empirical MSE of MOM estimator for mu.
mu_MOM_est_MSEs=zeros(length(n),1);
for i=1:length(n)
    mu_MOM_est_MSEs(i)=trace((mu_perm_ests(:,:,i)-kron(perm_log_mu',ones(num_sim,1)))'*(mu_perm_ests(:,:,i)-kron(perm_log_mu',ones(num_sim,1))))/num_sim;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%For showing effect of mean value differences on convergence to normality.
figure
subplot(1,3,1)
histogram(test_stats(1,:))
title('$\mu_{(1)}-\mu_{(2)}=0$','interpreter','latex')
xlabel('$\sqrt{n}h(\hat{\alpha}_1,\hat{\alpha}_3,\hat{\alpha}_4)$','interpreter','latex')

subplot(1,3,2)
histogram(test_stats(2,:))
title('$\mu_{(1)}-\mu_{(2)}=\sigma$','interpreter','latex')
xlabel('$\sqrt{n}h(\hat{\alpha}_1,\hat{\alpha}_3,\hat{\alpha}_4)$','interpreter','latex')

subplot(1,3,3)
histogram(test_stats(3,:))
title('$\mu_{(1)}-\mu_{(2)}=2\sigma$','interpreter','latex')
xlabel('$\sqrt{n}h(\hat{\alpha}_1,\hat{\alpha}_3,\hat{\alpha}_4)$','interpreter','latex')

%mean(test_stats,2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Compute empirical type I error rate.
alpha=0.05;
for i=1:length(n)
    for j=1:num_sim
        if test_stats(i,j)/sqrt(test_stats_vars(i)) > chi2inv(1-alpha,1)
            reject_yn(i,j)=1;
        end
    end
end

mean(reject_yn,2)

synth_test_stats=zeros(1,num_sim);
synth_normal_part=mvnrnd([0 0 0],mom_ests_asym_cov,num_sim);
for i=1:num_sim
    %synth_test_stats(i)=(synth_normal_part(i,3)-synth_normal_part(i,1)^3+3*synth_normal_part(i,1)*(synth_normal_part(i,1)^2-synth_normal_part(i,2)))^2-4*(synth_normal_part(i,1)^2-synth_normal_part(i,2))^3;
    synth_test_stats(i)=synth_normal_part(i,:)*grad+(1/2)*synth_normal_part(i,:)*g_hessian*synth_normal_part(i,:)';
end

figure
histogram(synth_test_stats)
figure
qqplot(synth_test_stats,test_stats(4,:))

eig(mom_ests_asym_cov^(0.5)*g_hessian*mom_ests_asym_cov^(0.5))

grad'*mom_ests_asym_cov^(0.5)

mom_ests_asym_cov^(0.5)*grad

