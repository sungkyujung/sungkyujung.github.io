function [quat, theta, w] = rot2quat(U,all)
% ROT2QUAT converts 3 x 3 rotation matrix U to a quaternion
% quat = rot2quat(U) returns a quaternion in R^4, with the first element >=
% 0. This routine uses axis-angle representation of U, for angle in [0, pi].
% quat = rot2quat(U,1) returns two quaternions in R^4, corresponding to U.
%
iallquat = 0;
if nargin > 1
    iallquat = all;
end
tol = 1e-14;
theta = acos((trace(U) - 1) / 2) ;
if abs(theta) < tol
    w = [0,0,0]';
elseif abs((abs(theta) - pi)) < tol % the case theta == pi
    % then there is no principal logarithm
    A = (U+eye(3))/2;
    a = sqrt(diag(A));
    if A(1,2) < 0;
        a(2) = -a(2);
    end
    if A(1,3) < 0;
        a(3)  = -a(3);
    end
    if A(2,3) < 0 && a(2)*a(3)>0;
        a(3) = - a(3);
    end
    w = a;
else
    w = [U(3,2) - U(2,3)
        U(1,3) - U(3,1)
        U(2,1) - U(1,2)] / ( 2 * sin(theta) );
end

quat = [cos(theta/2)
    sin(theta/2)* w];
if iallquat
    quat = [quat; - quat];
end

