function output=diagplus_dist(D1,D2)
%Corresponds to Riemannian metric for Diag-plus(p), the space of pxp
%diagonal matrices with positive diagonal entries.
output=sqrt(trace(logm(D2/D1)*logm(D2/D1)'));
end