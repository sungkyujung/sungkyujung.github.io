%Mixture-Based Estimation on the Space of Eigen-Decompositions
p=2;

%Parameters of generating distribution on eigen-decomposition space.
eval_mean=diag([2 8]);
evals_var=1;
evec_mean=rot2Dmat(pi/8);
evec_conc_parm=5;

%Generate set of signed permutation matrices.
mod_perm_mats=perm_mats(p);
sign_changes=sign_change_mats(p);

signed_perms=cell(2^(p-1)*factorial(p),1);
count=0;
for i=1:length(mod_perm_mats)
    for j=1:length(sign_changes)
        count=count+1;
        signed_perms{count}=mod_perm_mats{i}*sign_changes{j};
    end
end

%Sample sizes
n=[30 50 100];

%Number of simulations
num_sim=500;

eval_mean_ests=cell(length(n),num_sim,length(mod_perm_mats));
alt_eval_mean_ests=cell(length(n),num_sim,length(mod_perm_mats));
eval_var_ests=zeros(length(n),num_sim);
check=zeros(length(n),num_sim);
evec_mean_ests=cell(length(n),num_sim,length(signed_perms));

Adj=eye(p);
Adj(p,p)=-1;

count=0;

for i=1:length(n)
    for j=1:num_sim
        count=count+1
        %Create sample of generating eigen-decompositions.
        log_eval_sample=mvnrnd(diag(logm(eval_mean))',evals_var*eye(p),n(i));
        angles=vmrand(0,evec_conc_parm,n(i),1);
        %Create sample of SPD mats.
        SPD_mats=cell(n(i),1);
        for a=1:n(i)
            SPD_mats{a}=(rot2Dmat(angles(a))*evec_mean)*expm(diag(log_eval_sample(a,:)))*(rot2Dmat(angles(a))*evec_mean)';
        end
        %Generate sample of observed eigen-decompositions.
        observed_eigen_decomps=cell(n(i),2);
        %version_num=unidrnd(length(signed_perms),n(i),1);
        for a=1:n(i)
            [observed_eigen_decomps{a,1},observed_eigen_decomps{a,2}]=eig(SPD_mats{a});
            if det(observed_eigen_decomps{a,1})<0
                observed_eigen_decomps{a,1}=observed_eigen_decomps{a,1}*Adj;
            end
            %Select an eigen-decomposition at random for each observation.
            version_num=unidrnd(length(signed_perms));
            observed_eigen_decomps{a,1}=observed_eigen_decomps{a,1}*signed_perms{version_num}';
            observed_eigen_decomps{a,2}=signed_perms{version_num}*observed_eigen_decomps{a,2}*signed_perms{version_num}';
        end
        %Compute estimators for the location parameters.
        %Estimators for eigenvalue means.
        alpha1_est=0;
        alpha2_est=0;
        alpha3_est=0;
        for a=1:n(i)
            alpha1_est=alpha1_est+(1/(2*n(i)))*trace(logm(observed_eigen_decomps{a,2}));
            alpha2_est=alpha2_est+(1/(2*n(i)))*trace((logm(observed_eigen_decomps{a,2}))^2);
            alpha3_est=alpha3_est+(1/n(i))*det(logm(observed_eigen_decomps{a,2}));
        end
        eval_var_ests(i,j)=alpha2_est-2*alpha1_est^2+alpha3_est;
        check(i,j)=alpha1_est^2-alpha3_est;
        
        eval_mean_ests{i,j,1}=[exp(alpha1_est+sqrt(abs(alpha1_est^2-alpha3_est))) exp(alpha1_est-sqrt(abs(alpha1_est^2-alpha3_est)))];
        eval_mean_ests{i,j,2}=[exp(alpha1_est-sqrt(abs(alpha1_est^2-alpha3_est))) exp(alpha1_est+sqrt(abs(alpha1_est^2-alpha3_est)))];
        %eval_mean_ests{i,j,1}=[exp(alpha1_est+sqrt(alpha1_est^2-alpha3_est)) exp(alpha1_est-sqrt(alpha1_est^2-alpha3_est))];
        
        %Alternative estimator for eigenvalue mean.
        evals_array=zeros(p,n(i));
        for a=1:n(i)
            evals_array(:,a)=diag(logm(observed_eigen_decomps{a,2}));
        end
        
        evals_sample_cov=(1/n(i))*evals_array*(eye(n(i))-(1/n(i))*ones(n(i),1)*ones(n(i),1)')*evals_array';
        
        alt_eval_mean_ests{i,j,1}=[exp(alpha1_est+sqrt(max(eig(evals_sample_cov))-min(eig(evals_sample_cov)))) exp(alpha1_est-sqrt(max(eig(evals_sample_cov))-min(eig(evals_sample_cov))))];
        alt_eval_mean_ests{i,j,2}=[exp(alpha1_est-sqrt(max(eig(evals_sample_cov))-min(eig(evals_sample_cov)))) exp(alpha1_est+sqrt(max(eig(evals_sample_cov))-min(eig(evals_sample_cov))))];
        
        %Estimators for eigenvector means.
        evec_4th_moment=zeros(p,p);
        for a=1:n(i)
            evec_4th_moment=evec_4th_moment+(1/n(i))*(observed_eigen_decomps{a,1})^4;
        end
        %[V,~,W]=svd(evec_4th_moment);
        %evec_4th_moment=V*W';
        evec_mean_angle=atan2(evec_4th_moment(2,1),evec_4th_moment(1,1))/4;
        for b=1:length(signed_perms)
            %evec_mean_ests{i,j,b}=(evec_4th_moment)^(1/4)*signed_perms{b}';
            evec_mean_ests{i,j,b}=rot2Dmat(evec_mean_angle)*signed_perms{b}';
        end
    end
end

eval_ests_array=zeros(length(n),num_sim,p);
evec_mean_ests_array=zeros(length(n),num_sim,p);
for i=1:length(n)
    for j=1:num_sim
        %eval_ests_array(i,j,:)=eval_mean_ests{i,j,1};
        eval_ests_array(i,j,:)=alt_eval_mean_ests{i,j,1};
        evec_mean_ests_array(i,j,:)=evec_mean_ests{i,j,1}(:,1)';
    end
end

for i=1:length(n)
    subplot(1,3,i)
    scatter(log(eval_ests_array(i,:,1)),log(eval_ests_array(i,:,2)))
    %scatter(eval_ests_array(i,:,1),eval_ests_array(i,:,2))
    hold on
    scatter(log(eval_ests_array(i,:,2)),log(eval_ests_array(i,:,1)))
    %scatter(eval_ests_array(i,:,2),eval_ests_array(i,:,1))
    axis square
    xlim([-3 3])
    ylim([-3 3])
    title(['n=' num2str(n(i))])
end
suptitle('Log-Eigenvalue Mean Estimates')

figure
for i=1:length(n)
    subplot(1,3,i)
    scatter(evec_mean_ests_array(i,:,1),evec_mean_ests_array(i,:,2))
    hold on
    scatter(-evec_mean_ests_array(i,:,1),-evec_mean_ests_array(i,:,2))
    hold on
    scatter(-evec_mean_ests_array(i,:,2),evec_mean_ests_array(i,:,1))
    hold on
    scatter(evec_mean_ests_array(i,:,2),-evec_mean_ests_array(i,:,1))
    axis square
    title(['n=' num2str(n(i))])
    line([-evec_mean(1,1) evec_mean(1,1)],[-evec_mean(2,1) evec_mean(2,1)])
    line([-evec_mean(1,2) evec_mean(1,2)],[-evec_mean(2,2) evec_mean(2,2)])
end
suptitle('Eigenvector Mean Direction Estimates')


