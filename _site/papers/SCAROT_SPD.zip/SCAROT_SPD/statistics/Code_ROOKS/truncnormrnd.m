function sample=truncnormrnd(mean,var,lower,upper,n)
%Efficient sampling from a truncated normal distribution using the
%Accept-Reject Algorithm proposed in C.P. Robert's "Simulation of Truncated
%Normal Random Variables."  The variables "mean" and "var" refer to the
%pre-truncation mean and variance, "lower" and "upper" set (lower,upper) as
%the interval of truncation, and "n" sets the sample size.
sample=zeros(n,1);
for i=1:n
    %Accept-Reject Algorithm%
    u=1;
    rho=0;
    while u>rho
        %Step 1%
        z=unifrnd(lower,upper);
        %Step 2%
        if lower<=0 && upper>=0
            rho=exp(-z^2/2);
        elseif upper<0
            rho=exp((upper^2-z^2)/2);
        elseif lower>0
            rho=exp((lower^2-z^2)/2);
        end
        %Step 3$
        u=unifrnd(0,1);
    end
    sample(i)=sqrt(var)*z+mean;
end
end
    