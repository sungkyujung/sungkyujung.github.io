%%Interpolation between 3x3 SPD matrices using different geometric
%%frameworks.

%X=diag([15 2 1]);
%Y=rot3Dmat(pi/4,[0;1;0])*diag([100 2 1])*rot3Dmat(pi/4,[0;1;0])'; %SPD Interpolation 1: Scaling and rotation%
%Y=rot3Dmat(pi/4,[0;1;0])*diag([15 2 1])*rot3Dmat(pi/4,[0;1;0])'; %SPD Interpolation 2: Pure rotation%
%Y=diag([100 2 1]); %SPD Interpolation 3: Pure scaling%

%SPD Interpolation 4: Example with smooth deformation from anisotropic diffusion tensor to
%isotropic diffusion tensor.
%X=rot3Dmat(pi/4,[0;1;0])*diag([16 4 1])*rot3Dmat(pi/4,[0;1;0])';
%Y=4*eye(3);

%SPD Interpolation 5: Example showing that Cholesky framework is not
%invariant to change of coordinate system.
X=rot3Dmat(pi/2,[0;1;0])*diag([15 2 1])*rot3Dmat(pi/2,[0;1;0])';
Y=rot3Dmat(pi/4,[0;1;0])*rot3Dmat(pi/2,[0;1;0])*diag([15 2 1])*rot3Dmat(pi/2,[0;1;0])'*rot3Dmat(pi/4,[0;1;0])';

t=linspace(0,1,11);

plot_title=cell(7,1);
plot_title{1,1}='Scaling-Rotation';
plot_title{2,1}='Euclidean';
plot_title{3,1}='Log-Euclidean';
plot_title{4,1}='Affine-Invariant';
plot_title{5,1}='Cholesky';
plot_title{6,1}='Root-Euclidean';
plot_title{7,1}='Procrustes';

Inter=cell(7,length(t));

%Scaling-Rotation Framework
[~,Ux,Dx,Uy,Dy]=minscrotdist(X,Y);
for i=1:length(t)
    Inter{1,i}=(expm(logm(Uy*Ux')*t(i))*Ux)*(expm(logm(Dy/Dx)*t(i))*Dx)*(expm(logm(Uy*Ux')*t(i))*Ux)';
end
%Euclidean Framework
for i=1:length(t)
    Inter{2,i}=(1-t(i))*X+t(i)*Y;
end
%Log-Euclidean Framework
for i=1:length(t)
    Inter{3,i}=expm((1-t(i))*logm(X)+t(i)*logm(Y));
end
%Affine-Invariant Framework
sqrtX=X^0.5;
for i=1:length(t)
    Inter{4,i}=sqrtX*expm(t(i)*logm(sqrtX\Y/sqrtX))*sqrtX;
end
%Cholesky Framework
chol_rootX = chol(X)';
chol_rootY = chol(Y)';
for i=1:length(t)
    Inter{5,i}=(chol_rootX+t(i)*(chol_rootY-chol_rootX))*(chol_rootX+t(i)*(chol_rootY-chol_rootX))';
end
%Root-Euclidean Framework
[evecsX,evalsX]=eig(X);
[evecsY,evalsY]=eig(Y);
SPD_rootX=evecsX*(evalsX^0.5)*evecsX';
SPD_rootY=evecsY*(evalsY^0.5)*evecsY';
for i=1:length(t)
    Inter{6,i}=(SPD_rootX+t(i)*(SPD_rootY-SPD_rootX))^2;
end
%Procrustes Size and Shape Framework
rootX=chol(X)';
rootY=chol(Y)';
[W,Lambda,U]=svd(rootX'*rootY);
R_hat=U*W';
for i=1:length(t)
    Inter{7,i}=(rootX+t(i)*(rootY*R_hat-rootX))*(rootX+t(i)*(rootY*R_hat-rootX))';
end

figure
count=0;
for i=1:7
    for j=1:length(t)
        count=count+1;
        [U,D]=eig(Inter{i,j});
        subplot(7,length(t),count)
        plotellipsoid(D,U,[0 1 0]);
        axis([-sqrt(15) sqrt(15) -sqrt(15) sqrt(15) -sqrt(15) sqrt(15)])
        %axis([-sqrt(100) sqrt(100) -sqrt(100) sqrt(100) -sqrt(100) sqrt(100)])
        axis off
        zoom(1.2)
        if mod(count,length(t))==1
            title(plot_title{i,1})
        end
    end
end

fig=gcf;
print(fig,'-dpng','-r600','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\SPDInterpolation1.png')%Scaling and rotation%
%print(fig,'-dpng','-r600','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\SPDInterpolation2.png') %Pure rotation%
%print(fig,'-dpng','-r600','C:\Users\Brian\Documents\School Files\Thesis Research\Thesis Proposal\SPDInterpolation3.png') %Pure scaling%
%print(fig,'-dpng','-r600','C:\Users\Brian\Documents\SchoolFiles\ThesisResearch\Thesis Proposal\SPDInterpolation4.png') 
