function [Ux,Dx] = Exp_scrot2(U,D,x,k)
% The Exp map from the tangent coordinate x at (U,D).
% p = 2. 

a = x(1)/sqrt(k);
A = [0 -a; a 0];
Ux = expm(A)*U;
Dx = diag(exp([x(2), x(3)]))*D;

end

